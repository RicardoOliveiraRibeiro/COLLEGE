#ifndef CLIENTE_H
#define CLIENTE_H

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct{
pid_t pid;
char nome[100];
int estado; //0 por atender 1 a ser atendido 2 finished
int prioridade;
char sintomas[100];
char fifo[100];
char esp_atribuida[100];
pid_t pidbalcao;
}cliente;


#endif