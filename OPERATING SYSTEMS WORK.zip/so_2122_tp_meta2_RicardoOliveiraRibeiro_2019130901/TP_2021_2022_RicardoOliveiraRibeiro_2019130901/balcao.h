
#ifndef BALCAO_H
#define BALCAO_H
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include "cliente.h"
#include "medico.h"

int maxCli=5;
int maxMed=5;

//ESTRUTURA DAS VARIAVEIS DO BALCAO  
typedef struct{
    //VARIAVEIS A INCREMENTAR SEMPRE QUE É ADICIONADO UM MEDICO OU CLIENTE
    int numClientes;
    int numMedicos;
   //CRIAR ARRAYS PARA ARMAZENAR CLIENTES E MEDICOS
    cliente* ArrayDeClientes;
    medico* ArrayDeMedicos;
    //ARRAY BI DE CHATS
    pid_t **chats;
    int n_chats;
    //PID DO BALCAO
    pid_t pid;
    //MUTEX
    pthread_mutex_t mutex;
    //MAX pessoas
    int MAXCLIENTES;
    int MAXMEDICOS;
    

}sBalcao;

#endif
