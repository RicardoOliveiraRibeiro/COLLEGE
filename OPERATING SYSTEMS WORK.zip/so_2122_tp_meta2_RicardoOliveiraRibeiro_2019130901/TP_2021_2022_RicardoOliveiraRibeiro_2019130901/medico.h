#ifndef MEDICO_H
#define MEDICO_H

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>

typedef struct{
char nome[100];
pid_t pid;
int estado;
char especialidade[100];
char fifo[100];
}medico;

#endif
