#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <sys/select.h>
#include "cliente.h"
#include "medico.h"

#define BALCAO_FIFO "BALCAO"
#define CLIENTE_FIFO "CLIENTE%d"
char CLIENTE_FIFO_FINAL[100];

void handler_sigusr2(){
    printf("\n Foi removido pelo Admin\n");
    unlink(CLIENTE_FIFO_FINAL);
    exit(1);
}

void handle_sigusr1(){
    printf("\nHospital cheio, volte mais tarde\n");
    unlink(CLIENTE_FIFO_FINAL);
    exit(1);
}

void handler_sprof(){
    printf("\n Ligacao a um medico estabelecida \n Pode Iniciar a conversa \n");
}

void handler_sint(){
    unlink(CLIENTE_FIFO_FINAL);
    exit(1);
}


void main(int argc, char* argv[]){
    
    cliente THIS_CLIENTE;
    
    if(argc==1){
        printf("\nIndique o seu nome\n");
        fgets(THIS_CLIENTE.nome,sizeof(THIS_CLIENTE.nome),stdin);
        fflush(stdin);
    }
    if(argc==2){
	strcpy(THIS_CLIENTE.nome,argv[2]);
    }
    
    printf("\nIndique os seus sintomas\n");
    fgets(THIS_CLIENTE.sintomas,sizeof(THIS_CLIENTE.sintomas),stdin);
    fflush(stdin);
    
    printf("\nSintomas inseridos: %s", THIS_CLIENTE.sintomas);

    THIS_CLIENTE.pid=getpid();
    THIS_CLIENTE.estado=0;
    sprintf(CLIENTE_FIFO_FINAL,CLIENTE_FIFO,getpid());
    strcpy(THIS_CLIENTE.fifo,CLIENTE_FIFO_FINAL);
    
    //CRIA FIFO DO CLIENTE
    if(mkfifo(CLIENTE_FIFO_FINAL,0666)==-1){
        if(errno==EEXIST){
            printf("\nfifo já existe\n");
        }
        printf("\n erro ao abrir fifo \n");
        exit(1);
    }
    printf("\nCriei o teu fifo\n");
    

  
    printf("\nvou criar os teu sinais\n");
    //CRIAÇÃO DOS SINAIS E DO SET DE SINAIS
        //SIGUSR1-DEMASIADOS CLIENTES NO HOSPITAL - SAI - NAO AVISA BALCAO QUE SAIU
    struct sigaction susr1 ={0};
    susr1.sa_flags=SA_RESTART;
    susr1.sa_handler=&handle_sigusr1;
    sigaction(SIGUSR1,&susr1,NULL);
        //SIGUSR2-REMOVIDO PELO ADMIN - SAI - NAO AVISA BALCAO QUE SAIU
    struct sigaction susr2={0};
    susr2.sa_flags=SA_RESTART;
    susr2.sa_handler=&handler_sigusr2;
    sigaction(SIGUSR2,&susr2,NULL);
        //SIGPROF-COMEÇA CONVERSA TENS O MEDICO NO PIPE
    struct sigaction sprof={0};
    sprof.sa_flags=SA_RESTART;
    sprof.sa_handler=&handler_sprof;
    sigaction(SIGPROF,&sprof,NULL);
        //SIGINT-TERMINA
    struct sigaction sint={0};
    sprof.sa_flags=SA_RESTART;
    sprof.sa_handler=&handler_sint;
    sigaction(SIGINT,&sint,NULL);
        //signal SET (SIGPROF)
    sigset_t sigCliente;
    sigemptyset(&sigCliente);
    sigaddset(&sigCliente,SIGPROF);

        //LE DO BALCAO O PID DO BALCAO
    pid_t pidBALCAO;
    int fd_recebe_pid_entrada;
    fd_recebe_pid_entrada=open("BALCAO",O_RDONLY);

    if(fd_recebe_pid_entrada==-1){
        printf("\nO hospital n ta aberto bro\n");
        unlink(CLIENTE_FIFO_FINAL);
        exit(1);
    }

    int size=read(fd_recebe_pid_entrada,&pidBALCAO,sizeof(pid_t));
    close(fd_recebe_pid_entrada);
    
    printf("\n PID DO BALCAO: %d", pidBALCAO);
    printf("\n Nom do cliente: %s", THIS_CLIENTE.nome);
    printf("\n Estado do cliente: %d",THIS_CLIENTE.estado);
    printf("\n FIFO do cliente: %s", THIS_CLIENTE.fifo);
    
    printf("\nVou enviar pro balcao a minha info\n");
    int fd_enviarSelf;
    fd_enviarSelf=open("BALCAO",O_WRONLY|O_NONBLOCK);
    int size3=write(fd_enviarSelf,&THIS_CLIENTE,sizeof(cliente));
    printf("\nEnviei para o balcao a sua informacao\n Aguarde...\n");
    close(fd_enviarSelf);
    
    printf("\nVou mandar o sinal ao balcao que tem o pid %d\n",pidBALCAO);
    sleep(20);
    kill(pidBALCAO,SIGUSR1);
    printf("Sinal enviado");
    printf("\nAvisei o balcao que tem la a sua informacao\n");
    
    printf("\n... wait ...\n");
    
    
    sigwait(&sigCliente,NULL);
    
    printf("\nLigacao estabelecida\n");
   
    
    
    //LE O MEDICO DO PIPE
    medico* MEDICO_CALL=malloc(sizeof(medico));
    int fd_read_medico=open("BALCAO",O_RDONLY);
    int size1=read(fd_read_medico,MEDICO_CALL,sizeof(medico));
    close(fd_read_medico);
    
    printf("\nLi do meu pipe o medico com o nome %s de especialidade %s com o pid %d \n",MEDICO_CALL->nome,MEDICO_CALL->especialidade,MEDICO_CALL->pid);
    //CONVERSA COM O MEDICOOOOO
    char mensagem[100];
    int size2;


    int chat=fork();
    
    //FILHO
    printf("\nProcesso filho aberto\n");
    if(chat==0){
        int fd_escrever=open(MEDICO_CALL->fifo,O_WRONLY);
        printf("\n Abri o fifo do medico\n");
        do{
            printf("\nInsira a sua mensagem\n");
            fgets(mensagem,sizeof(mensagem),stdin);
            size=write(fd_escrever,&mensagem,sizeof(mensagem));
            printf("\nEscrevi a mensagem %s para o fifo do medico\n", mensagem);
        }while(strcmp(mensagem,"adeus")!=0);
    }
    
    //PAI
    printf("\nProcesso pai aberto\n");
    
    int fd_ler=open(CLIENTE_FIFO_FINAL,O_RDONLY);
    printf("\nAbri o pipe do Cliente para ler mensagens\n");

    do{
        
        size=read(fd_ler,&mensagem,sizeof(mensagem));
        printf("Li a mensagem seguinte do medico:\n");
        printf("Dr.%s: %s \n",MEDICO_CALL->nome, mensagem);
    }while(strcmp(mensagem,"adeus")!=0);

    printf("\n Estou a espera que o medico diga adeus\n");
    wait(NULL);

    printf("\nO medico disse adeus\n");

    int fd_sair;
    fd_sair=open("BALCAO",O_WRONLY);
    int size10=write(fd_sair,&THIS_CLIENTE.pid,sizeof(pid_t));
    printf("\n Enviei para o balcao o meu pid que e: %d \n", THIS_CLIENTE.pid);
    close(fd_sair);
    printf("\nFechei o pipe do balcao\n");

    kill(pidBALCAO,SIGPROF);
    printf("\nEnviei um sinal para o balcao para visa-lo que sai\n");

    unlink(CLIENTE_FIFO_FINAL);
    printf("\nDesconectei o meu fifo\n");

    printf("\n Volte Sempre\n");
    exit(1);
    
}