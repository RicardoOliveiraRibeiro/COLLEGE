#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>
#include <sys/select.h>
#include "medico.h"
#include "cliente.h"

#define BALCAO_FIFO "BALCAO"
#define MEDICO_FIFO "MEDICO%d"
char MEDICO_FIFO_FINAL[100];

void handler_sigusr2(){
    printf("\n Foi removido pelo Admin\n");
    unlink(MEDICO_FIFO_FINAL);
    exit(1);
}

void handle_sigusr1(){
    printf("\nHospital cheio, volte mais tarde\n");
    unlink(MEDICO_FIFO_FINAL);
    exit(1);
}

void handler_sprof(){
    printf("\n Ligacao a um cliente estabelecida \n Pode Iniciar a conversa \n");
}

//QND RECEBE SIGINT
void handler_sint(){
    sleep(5);
    printf("Ja esperei 5 segundos vou agr encerrar\n");
    unlink(MEDICO_FIFO_FINAL);
    exit(1);
}


//THREAD QND O MEDICO SAI
void* medico_saiu(void* cliente_com_que_esta_a_falar){
    cliente* CLIENTE_CALL = (cliente*) cliente_com_que_esta_a_falar;
    printf("\nFala a thread que esta a espera que des log off do sistema, estou a espera\n");
        //SIGINT - AVISA BALCAO E SAI
    struct sigaction sint={0};
    sint.sa_flags=SA_RESTART;
    sint.sa_handler=&handler_sint;
    sigaction(SIGINT,&sint,NULL);
        //signal SET (SIGINT)
    sigset_t sigMedico;
    sigemptyset(&sigMedico);
    sigaddset(&sigMedico,SIGINT);
    
    printf("\nEstou a espera que haja um sinal sigint\n");
    sigwait(&sigMedico,NULL);

    printf("\nuiui recebi um sinal sigint bou terminar\n");
    

    int fd_envia_pid_balcao=open("BALCAO",O_WRONLY);
    printf("\nantes de terminar abri o pipe do balcao\n");
    pid_t este_pid=getpid();
    int size=write(fd_envia_pid_balcao,&este_pid,sizeof(pid_t));
    printf("\nEscrevi para o balcao o meu pid pra ele saber que fui eu q sai : %d\n", este_pid);
    close(fd_envia_pid_balcao);
    printf("\n fechei o pipe do balcao\n");
    kill(CLIENTE_CALL->pidbalcao,SIGPROF);
    printf("\n Enviei um sinal SIGPROF ao balcao para avisa-lo\n");
    
    
    int fd_envia_adeus_cliente=open(CLIENTE_CALL->fifo,O_WRONLY);
    printf("\nVou ver se estavas a falar com algum cliente abrindo o seu pipe\n");
    if(fd_envia_adeus_cliente!=-1){
        printf("\nEstavas a falar com um cliente\n");
        int size2=write(fd_envia_adeus_cliente,"adeus",100*sizeof(char));
        printf("\nEscrevi para o pipe desse cliente adeus\n");
        close(fd_envia_adeus_cliente);
        printf("\nE fechei o seu pipe\n");
        printf("\n Agora vou esperar que termines com a funcao do sinal SIGINT\n");
    }
    else{
        printf("\nNao estavas a flr com nenhum cliente\n");
    }
    
    printf("\nAcabou a thread de sair\n");
  
}


void main(int argc, char* argv[]){
    
    medico THIS_MEDICO;
    
    if(argc==1){
        
        printf("\nIndique o seu nome\n");
        fgets(THIS_MEDICO.nome,sizeof(THIS_MEDICO.nome),stdin);
        printf("\nNome inserido: %s",THIS_MEDICO.nome);
        printf("\nInfique a sua especialidade\n");
        fgets(THIS_MEDICO.especialidade,sizeof(THIS_MEDICO.especialidade),stdin);
        printf("\nEspecialidade inserida: %s",THIS_MEDICO.especialidade);
    }
    if(argc==2){
        printf("\nIndique a sua especialidade\n");
        fgets(THIS_MEDICO.especialidade,sizeof(THIS_MEDICO.especialidade),stdin);
        printf("\nEspecialidade inserida: %s",THIS_MEDICO.especialidade);
        strcpy(THIS_MEDICO.nome,argv[2]);
        printf("\nO seu nome: %s",THIS_MEDICO.nome);
    }
    
    if(argc==3){
        strcpy(THIS_MEDICO.nome,argv[2]);
        printf("\nO seu nome: %s", THIS_MEDICO.nome);
        strcpy(THIS_MEDICO.especialidade,argv[3]);
        printf("\nA sua especialidade: %s",THIS_MEDICO.especialidade);
    }
    
    
    THIS_MEDICO.pid=getpid();
    THIS_MEDICO.estado=0;
    sprintf(MEDICO_FIFO_FINAL,MEDICO_FIFO,getpid());
    strcpy(THIS_MEDICO.fifo,MEDICO_FIFO_FINAL);
    
    printf("\nO teu nome e %s", THIS_MEDICO.nome);
    printf("\nO teu pid e %d", THIS_MEDICO.pid);
    printf("\nA tua especialidade e %s", THIS_MEDICO.especialidade);
    printf("\nO teu estado e %d", THIS_MEDICO.estado);


    //CRIA FIFO DO MEDICO
    if(mkfifo(MEDICO_FIFO_FINAL,0666)==-1){
        if(errno==EEXIST){
            printf("\nfifo já existe\n");
        }
        printf("\n erro ao abrir fifo \n");
        exit(1);
    }

    printf("\nCriei o teu fifo que e %s",MEDICO_FIFO_FINAL);

    
    //LE DO BALCAO O PID DO BALCAO
    pid_t pidBALCAO;
    int fd_recebe_pid_entrada;
    fd_recebe_pid_entrada=open(BALCAO_FIFO,O_RDONLY);

    if(fd_recebe_pid_entrada==-1){
        printf("\nO hospital n ta aberto bro\n");
        unlink(MEDICO_FIFO_FINAL);
        exit(1);
    }
    
    printf("\nAbri o pipe do balcao");
    int size=read(fd_recebe_pid_entrada,&pidBALCAO,sizeof(pid_t));
    printf("\nLi do pipe do balcao o pid %d", pidBALCAO);
    close(fd_recebe_pid_entrada);
    printf("\nFechei o pipe do balcao");
    
    
  
    
    //CRIAÇÃO DOS SINAIS E DO SET DE SINAIS
        //SIGUSR1-DEMASIADOS CLIENTES NO HOSPITAL - SAI - NAO AVISA BALCAO QUE SAIU
    struct sigaction susr1 ={0};
    susr1.sa_flags=SA_RESTART;
    susr1.sa_handler=&handle_sigusr1;
    sigaction(SIGUSR1,&susr1,NULL);
        //SIGUSR2-REMOVIDO PELO ADMIN - SAI - NAO AVISA BALCAO QUE SAIU
    struct sigaction susr2={0};
    susr2.sa_flags=SA_RESTART;
    susr2.sa_handler=&handler_sigusr2;
    sigaction(SIGUSR2,&susr2,NULL);
        //SIGPROF-COMEÇA CONVERSA TENS O CLIENTE NO PIPE
    struct sigaction sprof={0};
    sprof.sa_flags=SA_RESTART;
    sprof.sa_handler=&handler_sprof;
    sigaction(SIGPROF,&sprof,NULL);
        //signal SET (SIGPROF)
    sigset_t sigMedico;
    sigemptyset(&sigMedico);
    sigaddset(&sigMedico,SIGPROF);
    
    
    int fd_enviarSelf;
    fd_enviarSelf=open(BALCAO_FIFO,O_WRONLY);
    printf("\nAbri o pipe do balcao again");
    int size3=write(fd_enviarSelf,&THIS_MEDICO,sizeof(medico));
    printf("\nE escrevi para la toda a minha informacao");
    close(fd_enviarSelf);
    printf("\nFechei o pipe do balcao");
    
    kill(pidBALCAO,SIGUSR2);
    printf("\n Enviei o sinal SIGUSR2 para o balcao para ele saber que cheguei\n");
    
    

    cliente* CLIENTE_CALL=malloc(sizeof(cliente));
    printf("\nAloquei memoria para 1 cliente com que vais flr\n");

    //THREAD QND O MEDICO SAI
    printf("\nVou agora criar a thread para o caso d quereres sair\n");
    pthread_t medico_sai;
    int iMedico_sai;
    iMedico_sai=pthread_create(&medico_sai,NULL,&medico_saiu,(void*) CLIENTE_CALL);
    if(iMedico_sai==0){
        printf("\nThread criada com sucesso\n");
    }

    do{
        
    printf("\n Vou agora esperar por um cliente\n");
    sigwait(&sigMedico,NULL);
    printf("\nuiui Recebi um sinal que me indica que ja tenho um cliente pra falar\n");
    
    //LE O CLIENTE DO PIPE
    
    int fd_read_cliente=open(MEDICO_FIFO_FINAL,O_RDONLY);
    printf("\nAbri o meu fifo");
    int size1=read(fd_read_cliente,CLIENTE_CALL,sizeof(cliente));
    printf("\nLi do meu fifo a info do cliente com q vou flr");
    close(fd_read_cliente);
    printf("\nFechei o meu fico");
    
    CLIENTE_CALL->pidbalcao=pidBALCAO;
    
    printf("\nInformacao do meu cliente:\n");
    printf("\nO meu cliente chama-se %s",CLIENTE_CALL->nome);
    printf("\nO meu cliente tem os sintomas %s",CLIENTE_CALL->sintomas);
    printf("\nO meu cliente foi dirigido a especialidade %s",CLIENTE_CALL->esp_atribuida);
    printf("\nO meu cliente esta agora em estado %d",CLIENTE_CALL->estado);
    printf("\nO meu cliente tem o pid %d",CLIENTE_CALL->pid);
    printf("\nO meu cliente tem a prioridade %d", CLIENTE_CALL->prioridade);
    
    
    //CONVERSA COM O CLIENTE
    char mensagem[100];
    int size;
    printf("\n\n Vamos la fazer um fork para flr com o cliente\n");
    int chat=fork();
    
    //FILHO
    if(chat==0){
        printf("\nOla eu so o filho e vou escrever as mensagens para o cliente\n");
        int fd_escrever=open(CLIENTE_CALL->fifo,O_WRONLY);
        printf("\nFilho abriu o pipe do cliente para escrever\n");
        do{
            printf("\n Eu sou o filho- digite uma mensagem\n");
            fgets(mensagem,sizeof(mensagem),stdin);
            printf("\nEscreveu a mensagem: %s", mensagem);
            size=write(fd_escrever,&mensagem,sizeof(mensagem));
            printf("\nE eu filho escrevia para o pipe do cliente\n");
        }while(strcmp(mensagem,"adeus")!=0);
        printf("\n Ora a mensagem que escreveu foi adeus por isso eu (filho) terminei");
    }
    
    printf("\n Ola eu sou o pai e vou escutar as mensagens do cliente\n");
    //PAI
    int fd_ler=open(MEDICO_FIFO_FINAL,O_RDONLY);
    printf("\nPai abriu o meu pipe para ler do cliente\n");
    do{
        size=read(fd_ler,&mensagem,sizeof(mensagem));
        printf("\nO pai lei uma mensagem do cliente\n");
        printf("%s: %s \n",CLIENTE_CALL->nome, mensagem);
    }while(strcmp(mensagem,"adeus")!=0);
    printf("\n Ora a mensagem que recebi do cliente foi adeus\n Por isso vou esperar que lhe envies um adeus tambem\n");
    wait(NULL);

    
    printf("\nFixe, enviaste um adeus tambem\n");

    printf("\n Consulta Terminada\n");

    printf("\nVou entao mandar para o balcal o teu pid");
    int fd_sair;
    fd_sair=open("BALCAO",O_WRONLY);
    printf("\nAbri fifo balcao");
    int size10=write(fd_sair,&THIS_MEDICO.pid,sizeof(pid_t));
    printf("\nEscrevi para la o teu pid: %d", THIS_MEDICO.pid);
    close(fd_sair);
    printf("\nFechei o pipe do balcao");
    
    
    kill(pidBALCAO,SIGIO);
    printf("\n\nMandei o sinal SIGIO para o balcao para ele saber que acabaste a consulta\n");

    
  }while(1);
    
}