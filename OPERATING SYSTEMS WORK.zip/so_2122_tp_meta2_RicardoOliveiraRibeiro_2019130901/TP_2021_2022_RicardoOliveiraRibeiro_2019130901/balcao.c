#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <pthread.h>
#include <sys/select.h>
#include "cliente.h"
#include "medico.h"
#include "balcao.h"

#define BALCAO_FIFO "BALCAO";

int block_ctrl_c=0;

//CLIENTE=1 //MEDICO=2
int cliente_ou_medico;

//FREQUENCIA DE APRESENTA LISTA DE ESPERA
int freq=120;

//RECEBE SINAL SIGUSR1=1 CLIENTE INSERIDO NO PIPE BALCAO
void handle_sigurs1(int sig){
    cliente_ou_medico=1;
}

//RECEBE SINAL SIGUSR2=1 MEDICO INSERIDO NO PIPE BALCAO
void handle_sigusr2(int sig){
    cliente_ou_medico=2;
}

//RECEBE SINAL SIGPROF= SAIU ALGUEM, O SEU PID TA NO PIPE
void handle_sprof(int sig){
    printf("Saiu alguem:");
}

//RECEBE SINAL SIGIO = MEDICO ACABOU CHAT
void handle_sigio(int sig){
    printf("Medico acabou uma consulta\n");
}

//RECEBE SINAL SIGINT = TERMINA BALCAO
void handle_sigint(int sig){
    printf("\n Balcao ira terminar\n");
}


//THREAD QUE CONECTA CLIENTES A MEDICOS
void* connect_conversas( void* balcao_recebido){
    printf("\nOla eu sou a thread que conecta clientes a medicos\n");
    sBalcao* THIS_BALCAO;
	THIS_BALCAO=(sBalcao*)balcao_recebido;

    //CRIAÇÃO DOS SINAIS E DO SET DE SINAIS
        //SIGUSR1-cliente no pipe pra ler
    struct sigaction susr1 ={0};
    susr1.sa_flags=SA_RESTART;
	susr1.sa_handler = &handle_sigurs1;
    //susr1.sa_handler=handle_sigusr1;
    sigaction(SIGUSR1,&susr1,NULL);
        //SIGUSR2-medico no pipe pra ler
    struct sigaction susr2={0};
    susr2.sa_flags=SA_RESTART;
	susr2.sa_handler = &handle_sigusr2;
    //susr2.sa_handler=handler_sigusr2;
    sigaction(SIGUSR2,&susr2,NULL);
        //signal SET (SIGUSR1 e SIGUSR2)
    sigset_t sigBalcao5;
    sigemptyset(&sigBalcao5);
    sigaddset(&sigBalcao5,SIGUSR1);
    sigaddset(&sigBalcao5,SIGUSR2);


    do{
        printf("\nVou esperar por um sinal de que chegou alguem\n");
        sigwait(&sigBalcao5,NULL);
        printf("\nThread q conecta clientes: Ha um cliente ou medico novo\n vou esperar 5 segundos para dar tempo de aloca-lo\n e depois vou tentar arranjar um novo chat\n");
        sleep(5);

        pthread_mutex_lock(&THIS_BALCAO->mutex);

        printf("\nVou tentar conectar clientes a medicos\n");
        for(int i=0;i<THIS_BALCAO->numClientes;i++){
            printf("\nCliente %d\n",i);
            if(THIS_BALCAO->ArrayDeClientes[i].estado==0){
                printf("Nao esta em consulta\n");
                printf("Vou procurar um medico\n");
                for(int j=0;j<THIS_BALCAO->numMedicos;j++){
                    printf("med[%d] ",j);
                    if(THIS_BALCAO->ArrayDeMedicos[j].estado==0){
                        printf("nao esta em consulta");
                        if(strcmp(THIS_BALCAO->ArrayDeClientes[i].esp_atribuida,THIS_BALCAO->ArrayDeMedicos[j].especialidade)==0){
                            printf(" e tem a especialidade que o cliente precisa\n");
                            int fd_escrever_cliente;
                            int fd_escrever_medico;
                            
                            
                            THIS_BALCAO->ArrayDeClientes[i].estado=1;
                            THIS_BALCAO->ArrayDeMedicos[j].estado=1;
                            printf("\nColoquei este cliente e este medico em estado 1\n");

                            fd_escrever_cliente=open(THIS_BALCAO->ArrayDeClientes[i].fifo,O_WRONLY|O_NONBLOCK);
                            int size=write(fd_escrever_cliente,&THIS_BALCAO->ArrayDeMedicos[j],sizeof(medico));
                            close(fd_escrever_cliente);
                            printf("\nAbri, escrevi, e fechei, para o fifo do cliente a info do medico\n");
                            
                            fd_escrever_medico=open(THIS_BALCAO->ArrayDeMedicos[j].fifo,O_WRONLY|O_NONBLOCK);
                            int size2=write(fd_escrever_medico,&THIS_BALCAO->ArrayDeClientes[i],sizeof(cliente));
                            close(fd_escrever_medico);
                            printf("\nAbri,escrevi, e fechei, para o fifo do medico a info do cliente\n");
                            
                            kill(THIS_BALCAO->ArrayDeClientes[i].pid,SIGPROF);
                            kill(THIS_BALCAO->ArrayDeMedicos[j].pid,SIGPROF);
                            printf("\nEnviei um sinal para o cliente e o medico de que podem começar a falar\n");
                            
                                
                            THIS_BALCAO->chats[THIS_BALCAO->n_chats][0]=THIS_BALCAO->ArrayDeClientes[i].pid;
                            THIS_BALCAO->chats[THIS_BALCAO->n_chats][1]=THIS_BALCAO->ArrayDeMedicos[j].pid;
                            printf("\nColoquei os pid deles no meu array bi de chats pos:%d [%d][%d]",THIS_BALCAO->n_chats,THIS_BALCAO->chats[THIS_BALCAO->n_chats][0],THIS_BALCAO->chats[THIS_BALCAO->n_chats][1]);
                                
                            THIS_BALCAO->n_chats++;
                            break;
                            
                        }
                        else{
                            printf(" nao tem a especialidade que o cliente precisa\n");
                        }
                    }
                    else{
                        printf("esta em consulta");
                    }
                }
               
            }
            else{
                printf("Ja esta em consulta\n");
            }
        }
        printf("\nLOOP terminado\n");

        pthread_mutex_unlock(&THIS_BALCAO->mutex);

    }while(1);
}

//THREAD QUE APRESENTA FILAS DE ESPERA DE -freq- EM -freq- segundos
void* listaFilas(void* balcao_recebido){
    printf("\nOla eu sou a thread q mostra as listas de espera de x em x segundos\n");
    sBalcao* THIS_BALCAO;
	THIS_BALCAO=(sBalcao*)balcao_recebido;
    int num_de_clientes_em_cada_especialidade=0;
    printf("\nVou começar o meu loop\n");
    do{
        sleep(freq);
        
        pthread_mutex_lock(&THIS_BALCAO->mutex);
        
        for(int i=0;i<5;i++){//5 especialidades
            switch(i){
                case 0:
                    printf("\nOftalmologia:\n");
                    for(int j=0;j<THIS_BALCAO->numClientes;j++){
                        
                        if(strcmp(THIS_BALCAO->ArrayDeClientes[i].esp_atribuida,"OFTALMOLOGIA")==0 && THIS_BALCAO->ArrayDeClientes[i].estado==0){
                            num_de_clientes_em_cada_especialidade++;
                        }
                        
                    }
                    printf("Clientes em fila de espera: %d \n", num_de_clientes_em_cada_especialidade);
                    num_de_clientes_em_cada_especialidade=0;
                    break;
                
                case 1:
                    printf("\nNeurologia:\n");
                    for(int j=0;j<THIS_BALCAO->numClientes;j++){
                        
                        if(strcmp(THIS_BALCAO->ArrayDeClientes[i].esp_atribuida,"NEUROLOGIA")==0 && THIS_BALCAO->ArrayDeClientes[i].estado==0){
                            num_de_clientes_em_cada_especialidade++;
                        }
                        
                    }
                    printf("Clientes em fila de espera: %d \n", num_de_clientes_em_cada_especialidade);
                    num_de_clientes_em_cada_especialidade=0;
                break;
                
                case 2:
                    printf("\nEstomatologia:\n");
                    for(int j=0;j<THIS_BALCAO->numClientes;j++){
                        
                        if(strcmp(THIS_BALCAO->ArrayDeClientes[i].esp_atribuida,"ESTOMATOLOGIA")==0 && THIS_BALCAO->ArrayDeClientes[i].estado==0){
                            num_de_clientes_em_cada_especialidade++;
                        }
                        
                    }
                    printf("Clientes em fila de espera: %d \n", num_de_clientes_em_cada_especialidade);
                    num_de_clientes_em_cada_especialidade=0;
                break;
                
                case 3:
                    printf("\nOrtopedia:\n");
                    for(int j=0;j<THIS_BALCAO->numClientes;j++){
                        
                        if(strcmp(THIS_BALCAO->ArrayDeClientes[i].esp_atribuida,"ORTOPEDIA")==0 && THIS_BALCAO->ArrayDeClientes[i].estado==0){
                            num_de_clientes_em_cada_especialidade++;
                        }
                        
                    }
                    printf("Clientes em fila de espera: %d \n", num_de_clientes_em_cada_especialidade);
                    num_de_clientes_em_cada_especialidade=0;
                break;
                
                case 4:
                    printf("\nGeral:\n");
                    for(int j=0;j<THIS_BALCAO->numClientes;j++){
                        
                        if(strcmp(THIS_BALCAO->ArrayDeClientes[i].esp_atribuida,"GERAL")==0 && THIS_BALCAO->ArrayDeClientes[i].estado==0){
                            num_de_clientes_em_cada_especialidade++;
                        }
                        
                    }
                    printf("Clientes em fila de espera: %d \n", num_de_clientes_em_cada_especialidade);
                    num_de_clientes_em_cada_especialidade=0;
                break;
            }
            
        }
        pthread_mutex_unlock(&THIS_BALCAO->mutex);
    }while(1);
}

//FUNÇÃO PARA ORGANIZAR ARRAY DE CLIENTES POR PRIORIDADE;
void organiza(sBalcao*ESTE_BALCAO){
    printf("\nVamos la organizar os clientes por prioridade\n");
    cliente ArrayDeClientesAUX[ESTE_BALCAO->MAXCLIENTES];
    int quantos_clientes=0;

    printf("\nBalcao desordenado:");
    for(int i=0;i<ESTE_BALCAO->numClientes;i++){
        printf("[%d] -> nome: %s [prioridade: %d]\n",i,ESTE_BALCAO->ArrayDeClientes[i].nome,ESTE_BALCAO->ArrayDeClientes[i].prioridade);
    }

    //Preencho array aux ordenadamente
    printf("\nVou percorrer as minhas prioridades de 4 ate 1");
    for(int i=4;i>=1;i--){ //percorro prioridade de 4 ate 1
    printf("\nPriori: %d",i);
        for(int j=0;j<ESTE_BALCAO->numClientes;j++){ //em cada prioridade percorro o array de clientes e se a prioridade deste for 4, 3, 2, 1 coloco-os ordenadamente
            if(ESTE_BALCAO->ArrayDeClientes[j].prioridade==i){
                printf("\nO cliente da pos: %d tem a prioridade %d",j,i);
                ArrayDeClientesAUX[quantos_clientes]=ESTE_BALCAO->ArrayDeClientes[j];
                quantos_clientes++;
            }
        }
    }

    
    
    //Copio o array aux para o array de cliente do balcao
    for(int i=0;i<ESTE_BALCAO->MAXCLIENTES;i++){
        ESTE_BALCAO->ArrayDeClientes[i]=ArrayDeClientesAUX[i];
    }

    printf("\nBalcao ordenado:");
    for(int i=0;i<ESTE_BALCAO->numClientes;i++){
        printf("[%d] -> nome: %s [prioridade: %d]\n",i,ESTE_BALCAO->ArrayDeClientes[i].nome,ESTE_BALCAO->ArrayDeClientes[i].prioridade);
    }

    printf("\nAcabei a ordenacao\n");
}


//THREAD QUE FICA A ESCUTA DE NOVOS CLIENTES E MEDICOS
void* EscutaClientesEMedicos(void* balcao_recebido){
    printf("\nOla eu sou a thread que fica a escuta de novos medicos e clientes\n");
    sBalcao*THIS_BALCAO = (sBalcao*) balcao_recebido;
    
           
    //CRIAÇÃO DOS SINAIS E DO SET DE SINAIS
        //SIGUSR1-cliente no pipe pra ler
    struct sigaction susr1 ={0};
    susr1.sa_flags=SA_RESTART;
	susr1.sa_handler = &handle_sigurs1;
    //susr1.sa_handler=handle_sigusr1;
    sigaction(SIGUSR1,&susr1,NULL);
        //SIGUSR2-medico no pipe pra ler
    struct sigaction susr2={0};
    susr2.sa_flags=SA_RESTART;
	susr2.sa_handler = &handle_sigusr2;
    //susr2.sa_handler=handler_sigusr2;
    sigaction(SIGUSR2,&susr2,NULL);
        //signal SET (SIGUSR1 e SIGUSR2)
    sigset_t sigBalcao;
    sigemptyset(&sigBalcao);
    sigaddset(&sigBalcao,SIGUSR1);
    sigaddset(&sigBalcao,SIGUSR2);
    
        
        do{
            
            printf("\nVou ficar a espera de um sinal SIGUSR1 ou SIGUSR2\n");
            sigwait(&sigBalcao, NULL);//espera por um sinal 
            printf("\nThread que escuta novos clientes e medicos: WEPA novo sinal acordei\n");
            

            pthread_mutex_lock(&THIS_BALCAO->mutex);
            
            if(cliente_ou_medico==1){ //CLIENTE INSERIDO NO PIPE DO BALCAO
                printf("\nOK e um cliente\n");
                if(THIS_BALCAO->numClientes<THIS_BALCAO->MAXCLIENTES){ //SE O BALCAO AINDA TIVER ESPAÇO PARA CLIENTES
					printf("\nE tenho espaco pra ele\n");
                    int fd_ler;
                    fd_ler=open("BALCAO",O_RDONLY | O_NONBLOCK);
                    int size3=read(fd_ler,&THIS_BALCAO->ArrayDeClientes[THIS_BALCAO->numClientes],sizeof(cliente));
                    close(fd_ler);
                    printf("\nAbri fifo do balcao, e li um cliente de la\n");
                    printf("\nVou correr o classificador pro novo menino\n");
                                                                                            int balcaoP[2], classificadorP[2];
                                                                                            if(pipe(balcaoP)==-1)
                                                                                                printf("Erro ao abrir pipe balcao");
                                                                                            
                                                                                            if(pipe(classificadorP)==-1)
                                                                                                printf("Erro ao abrir pipe classificador");
                                                                                            
                                                                                            
                                                                                            int classificar=fork();
                                                                                            
                                                                                            if(classificar==0){ //FILHO
                                                                                                close(0);
                                                                                                dup(balcaoP[0]);
                                                                                                close(balcaoP[0]);
                                                                                                close(balcaoP[1]);
                                                                                                
                                                                                                close(1);
                                                                                                dup(classificadorP[1]);
                                                                                                close(classificadorP[1]);
                                                                                                close(classificadorP[0]);
                                                                                                
                                                                                                execlp("./classificador","classificador",NULL);
                                                                                                printf("Falha ao abrir classificador\n");
                                                                                                exit(2);
                                                                                            }
                                                                                            
                                                                                            //PAI
                                                                                            
                                                                                            char returnDoClass[40];
                                                                                            
                                                                                            close(balcaoP[0]);
                                                                                            write(balcaoP[1],THIS_BALCAO->ArrayDeClientes[THIS_BALCAO->numClientes].sintomas,sizeof(THIS_BALCAO->ArrayDeClientes[THIS_BALCAO->numClientes].sintomas));
                                                                                            close(classificadorP[1]);
                                                                                            read(classificadorP[0],returnDoClass,sizeof(returnDoClass));
                                                                                            
                                                                                            printf("O que eu recebi do classificador: %s", returnDoClass);
                                                                                            int length=strlen(returnDoClass);
                                                                                            int priori;
                                                                                            char esp[40];
                                                                                            for(int i=0;i<length-2;i++){
                                                                                               esp[i]=returnDoClass[i];
                                                                                            }
                                                                                            printf("\nEspecialidade retornada pelo class: %s",esp);
                                                                                
                                                                                            priori=atoi(&returnDoClass[length]);
                                                                                            printf("\nPrioridade retornada pelo classificador: %d \n",priori);
                                                                                            THIS_BALCAO->ArrayDeClientes[THIS_BALCAO->numClientes].prioridade=priori;
                                                                                            strcpy(THIS_BALCAO->ArrayDeClientes[THIS_BALCAO->numClientes].esp_atribuida,esp);
                printf("\nVou organizar o array de cliente por prioridade\n");
                THIS_BALCAO->numClientes++;
                organiza(THIS_BALCAO);
                
                int fd_escrever;
                fd_escrever=open("BALCAO",O_WRONLY|O_NONBLOCK);
                int size4=write(fd_escrever,&THIS_BALCAO->pid,sizeof(pid_t));
                close(fd_escrever);
                printf("\nAbri o fifo do balcao, e escrevi pra la o pid do balcao\n");
                }
            
                else{ //SE O BALCAO JA NAO TIVER ESPAÇO PARA CLIENTES
                    printf("\nWepah n tenho espaço pra mais clientes\n");
                    cliente *cliente_aux=malloc(sizeof(cliente));
                    int fd_ler=open("BALCAO",O_RDONLY|O_NONBLOCK);
                    int size6=read(fd_ler,cliente_aux,sizeof(cliente));
                    close(fd_ler);
                    printf("\nAbri e li do pipe do balcao o cliente que la estava\n");

                    kill(cliente_aux->pid,SIGUSR1);
                    printf("\nEnviei para ele um sinal SIGUSR1 pra terminar\n");

                    free(cliente_aux);
                    printf("\n e fiz free da informacao que tinha dele\n");


                    int fd_escrever2;
                    fd_escrever2=open("BALCAO",O_WRONLY|O_NONBLOCK);
                    int size7=write(fd_escrever2,&THIS_BALCAO->pid,sizeof(pid_t));
                    close(fd_escrever2);
                    printf("\nAbre o balcao fifo e meti la o pid do balcao\n");
                    
                }
                
                
            }
        
            else if(cliente_ou_medico==2){ //MEDICO INSERIDO NO PIPE DO BALCAO
                printf("\nE realmente um doutor eheh\n");
                if(THIS_BALCAO->numMedicos<THIS_BALCAO->MAXMEDICOS){//SE AINDA HOUVER ESPAÇO PARA O MEDICO
                    printf("\nE tenho espaco pra ele\n");
                    int fd_ler;
                    fd_ler=open("BALCAO",O_RDONLY|O_NONBLOCK);
                    int size9=read(fd_ler,&THIS_BALCAO->ArrayDeMedicos[THIS_BALCAO->numMedicos],sizeof(medico));
                    close(fd_ler);
                    printf("\nAbri o meu fifo balcao e Li para o meu array de medicos o equivalente a um medico do fifo\n");
                    THIS_BALCAO->numMedicos++;
                    
                    int fd_escrever3;
                    fd_escrever3=open("BALCAO",O_WRONLY|O_NONBLOCK);
                    int size10=write(fd_escrever3,&THIS_BALCAO->pid,sizeof(pid_t));
                    close(fd_escrever3);
                    printf("\nAbri e escrevi para o fifo do balcao o pid do balcao\n");

                }
                else{
                    printf("\nMas n tenho espaco para ele :/\n");
                    medico *aux=malloc(sizeof(medico));
                    int fd_ler;
                    fd_ler=open("BALCAO",O_RDONLY|O_NONBLOCK);
                    int size12=read(fd_ler,aux,sizeof(medico));
                    printf("\nAbri e li do fifo do balcao o medico que queria entrar\n");
                    kill(aux->pid,SIGUSR1);
                    printf("\nMando-lhe um sinal SIGUSR1 para terminar\n");
                    free(aux);
                    printf("\nLiberto a informacao q tinha sobre ele\n");
                    close(fd_ler);
                    
                    int fd_escrever3;
                    fd_escrever3=open("BALCAO",O_WRONLY|O_NONBLOCK);
                    int size10=write(fd_escrever3,&THIS_BALCAO->pid,sizeof(pid_t));
                    close(fd_escrever3);
                    printf("\nAbri o fifo do balcao e escrevi para la o pid do balcao\n");
                }
                
            }
            pthread_mutex_unlock(&THIS_BALCAO->mutex);
        
        }while(1);
    
}

//THREAD QND MEDICO ACABA CHAT
void* Medico_chat_over(void* balcao_recebido){
    printf("\nOla sou a thread que espea que um medico acabe um chat\n");
    sBalcao* THIS_BALCAO= (sBalcao*)balcao_recebido;

    //CRIAÇÃO DOS SINAIS E DO SET DE SINAIS
        //SIGPROF- pid de alguem no pipe
    struct sigaction sgio ={0};
    sgio.sa_flags=SA_RESTART;
    sgio.sa_handler=&handle_sigio;
    sigaction(SIGIO,&sgio,NULL);

        //signal SET (SIGPROF)
    sigset_t sigBalcao3;
    sigemptyset(&sigBalcao3);
    sigaddset(&sigBalcao3,SIGIO);

    int fd_le_pid;
    int fd_escreve_pid;
    pid_t lixo;
    pid_t pid_do_medico_que_terminou;

    do{
        printf("\nvou esperar por um sinal do tipo SIGIO\n");
        sigwait(&sigBalcao3,NULL);

        printf("\nthread que espera um medico acabar consulta: uiui recebi um sinal\n");
        fd_le_pid=open("BALCAO",O_RDONLY);
        printf("\nAbri o pipe do balcao\n");
        int size=read(fd_le_pid,&lixo,sizeof(pid_t));
        printf("\nLi este lixo do pipe do balcao: %d\n", lixo);
        int size2=read(fd_le_pid,&pid_do_medico_que_terminou,sizeof(pid_t));
        printf("\nLi este pid que deve ser do medico q terminou a consulta:%d\n",pid_do_medico_que_terminou);
        close(fd_le_pid);
        printf("\nFechei o pipe do balcao");

        printf("\nVou percorrer o array de medicos\n");
        for(int i=0;i<THIS_BALCAO->numMedicos;i++){
            printf("med[%d]: %d\n",i,THIS_BALCAO->ArrayDeMedicos[i].pid);
            if(THIS_BALCAO->ArrayDeMedicos[i].pid==pid_do_medico_que_terminou){
                printf("\nEncontrei o medico que terminou na pos %d\n",i);
                THIS_BALCAO->ArrayDeMedicos[i].estado=0;
                printf("\nMudei o seu estado para 0 (livre)");
                break;
            }
        }
        printf("\nVou percorrer o array de chats a ver se por acaso ainda ta la o chat do medico\n");
        for(int i=0;i<THIS_BALCAO->n_chats;i++){
            printf("pos [%d]: [%d][%d]\n",i,THIS_BALCAO->chats[i][0],THIS_BALCAO->chats[i][1]);
            if(THIS_BALCAO->chats[i][1]==pid_do_medico_que_terminou){
                printf("\nOlha encontrei o char desse medico na pos %d\n",i);
                printf("\nVou apagar esse chat");
                for(int j=i;j<THIS_BALCAO->n_chats;j++){
                    if(j+1!=THIS_BALCAO->MAXCLIENTES){
                        THIS_BALCAO->chats[j][0]=THIS_BALCAO->chats[j+1][0];
                        THIS_BALCAO->chats[j][1]=THIS_BALCAO->chats[j+1][0];
                    }
                    else{
                        THIS_BALCAO->chats[j][0]=0;
                        THIS_BALCAO->chats[j][1]=0;
                    }
                }
                THIS_BALCAO->n_chats--;
                break;
            }
        }

        
        fd_escreve_pid=open("BALCAO",O_WRONLY|O_NONBLOCK);
        int size3=write(fd_escreve_pid,&THIS_BALCAO->pid,sizeof(pid_t));
        close(fd_escreve_pid);
        printf("\nAbri, e escrevi o pid do balcao outra ver para o fifo do balcao\n");
        
    }while(1);


}


//FUNÇÃO PARA REMOVER UM MEDICO DO ARRAY
void organizaMedicos(sBalcao *THIS_BALCAO,int pos){
    medico ArrayMedicosAux[THIS_BALCAO->MAXMEDICOS];
    
   
    
    for(int i=0;i<pos;i++){
        ArrayMedicosAux[i]=THIS_BALCAO->ArrayDeMedicos[i];
    }
    for(int i=pos+1;i<THIS_BALCAO->numMedicos;i++){
        ArrayMedicosAux[i-1]=THIS_BALCAO->ArrayDeMedicos[i];
    }
    
    THIS_BALCAO->numMedicos--;

    printf("\nArray medicos Atualizado:");
    for(int i=0;i<THIS_BALCAO->numMedicos;i++){
        THIS_BALCAO->ArrayDeMedicos[i]=ArrayMedicosAux[i];
        printf("[%s]\n",THIS_BALCAO->ArrayDeMedicos[i].nome);	
    }
		
}

//FUNÇÃO PARA REMOVER UM CLIENTE DO ARRAY
void organizaClientes(sBalcao *THIS_BALCAO,int pos){
    cliente ArrayDeClientesAux[THIS_BALCAO->MAXCLIENTES];
    printf("\nOra vou apagar o cliente na pos: %d",pos);

    
    
    for(int i=0;i<pos;i++){
        ArrayDeClientesAux[i]=THIS_BALCAO->ArrayDeClientes[i];
    }
    for(int i=pos+1;i<THIS_BALCAO->numClientes;i++){
        ArrayDeClientesAux[i-1]=THIS_BALCAO->ArrayDeClientes[i];
    }
    
    THIS_BALCAO->numClientes--;

    printf("\nArray clientes Atualizado:");
    for(int i=0;i<THIS_BALCAO->numClientes;i++){
        THIS_BALCAO->ArrayDeClientes[i]=ArrayDeClientesAux[i];
        printf("[%s]\n",THIS_BALCAO->ArrayDeClientes[i].nome);
    }
	 
}



//THREAD QUE APAGA CLIENTES E MEDICOS
void* ApagaClientesOuMedicos(void* balcao_recebido){
    printf("\nOla sou a thread que apaga clientes ou medicos qnd estes saem\n");
    
    sBalcao* THIS_BALCAO=(sBalcao*)balcao_recebido;

    
    //CRIAÇÃO DOS SINAIS E DO SET DE SINAIS
        //SIGPROF- pid de alguem no pipe
    struct sigaction sprof ={0};
    sprof.sa_flags=SA_RESTART;
    sprof.sa_handler=&handle_sprof;
    sigaction(SIGPROF,&sprof,NULL);

        //signal SET (SIGPROF)
    sigset_t sigBalcao2;
    sigemptyset(&sigBalcao2);
    sigaddset(&sigBalcao2,SIGPROF);
    
    
    int fd_read;
    int fd_escrita;
    pid_t aux;
    
    do{
        printf("\nVou so esperar que me mandei um sinal SIGPROF\n");
        sigwait(&sigBalcao2,NULL);
        printf("\nthread: apagar cliente e medicos");
        printf("\n wepaaah mandaram-me um sinal\n");
        pthread_mutex_lock(&THIS_BALCAO->mutex);
        
        pid_t* lixo1;
        lixo1=malloc(sizeof(pid_t));
      
        int fd_lixo;
        fd_lixo=open("BALCAO",O_RDONLY|O_NONBLOCK);
        int size10=read(fd_lixo, lixo1,sizeof(pid_t));

        printf("\nabri o balcao e li isto [%d] mas vou descartar\n", lixo1);
        free(lixo1);
        
        
        fd_read=open("BALCAO",O_RDONLY|O_NONBLOCK);
        int size=read(fd_read,&aux,sizeof(pid_t));
        close(fd_read);
        printf("\nAbri o balcao e li o pid da pessoa q vou remover: %d", aux);
        int e_cliente=1;
            
            printf("\nSera que esta nos clientes?\n");
        for(int i=0;i<THIS_BALCAO->numClientes;i++){
            printf("\ncli[i] = pid: %d",THIS_BALCAO->ArrayDeClientes[i].pid);
            if(THIS_BALCAO->ArrayDeClientes[i].pid==aux){
                printf("Ulha ta mesmo, na posicao %d\n",i);
                printf("\nVou ent apaga-lo mm do array:\n");
                organizaClientes(THIS_BALCAO,i);
                e_cliente=0;
                break;
            }
            
        }
        
        if(e_cliente!=0){
            printf("\n pelos visto nao esta, e nos medicos:\n");
            for(int i=0;i<THIS_BALCAO->numMedicos;i++){

                printf("\nmedico[i] = pid: %d",THIS_BALCAO->ArrayDeMedicos[i].pid);
                
                if(THIS_BALCAO->ArrayDeMedicos[i].pid==aux){
                    printf("Ulha ta mesmo, na posicao %d\n",i);
                    printf("\nVou ent apaga-lo mm do array:\n");
                    organizaMedicos(THIS_BALCAO,i);
                    break;
                }
                
            }
        }

        printf("\nBem sera q a pessoa que apaguei tava a flr com alguem\n");

        for(int i=0;i<THIS_BALCAO->MAXCLIENTES;i++){
            printf("chat[i]: [%d][%d]",THIS_BALCAO->chats[i][0],THIS_BALCAO->chats[i][1]);
            if(THIS_BALCAO->chats[i][0]==aux){
                printf("\nOlha era um cliente a flr com um medico\n Vou remove-lo\n");
                for(int j=i;j<THIS_BALCAO->n_chats;j++){
                    if(j+1!=THIS_BALCAO->MAXCLIENTES){
                        THIS_BALCAO->chats[j][0]=THIS_BALCAO->chats[j+1][0];
                        THIS_BALCAO->chats[j][1]=THIS_BALCAO->chats[j+1][1];
                    }
                    else{
                        THIS_BALCAO->chats[j][0]=0;
                        THIS_BALCAO->chats[j][1]=0;
                    }
                }
                THIS_BALCAO->n_chats--;
                break;
            }
            if(THIS_BALCAO->chats[i][1]==aux){
                printf("\nOlha era um medico a flr com um cliente\n Vou remove-lo\n");
                for(int j=i;j<THIS_BALCAO->n_chats;j++){
                    if(j+1!=THIS_BALCAO->MAXCLIENTES){
                        THIS_BALCAO->chats[j][0]=THIS_BALCAO->chats[j+1][0];
                        THIS_BALCAO->chats[j][1]=THIS_BALCAO->chats[j+1][1];
                    }
                    else{
                        THIS_BALCAO->chats[j][0]=0;
                        THIS_BALCAO->chats[j][1]=0;
                    }
                }
                THIS_BALCAO->n_chats--;
                break;
            }
        }
            
        e_cliente=1;
        
        fd_escrita=open("BALCAO",O_WRONLY|O_NONBLOCK);
        int size2=write(fd_escrita,&THIS_BALCAO->pid,sizeof(pid_t));
        close(fd_escrita);
        printf("\nEscrevi para o pipe do balcao o seu pid outra vez\n");
        
        pthread_mutex_unlock(&THIS_BALCAO->mutex);
	}  
    while(1);
    
    printf("\nThread que apaga clientes ou medicos encerrada\n");
}





//FUNÇÃO PARA ENCERRAR BALCÃO
void encerraTudo(sBalcao *THIS_BALCAO){
    printf("\nvou enviar sinais sigusr2 a todos os clientes");
    for(int i=0; i<THIS_BALCAO->numClientes;i++){
        kill(THIS_BALCAO->ArrayDeClientes[i].pid,SIGUSR2);
    }
    printf("\nvou enviar sinais sigusr2 a todos os medicos");
    for(int i=0; i<THIS_BALCAO->numMedicos;i++){
        kill(THIS_BALCAO->ArrayDeMedicos[i].pid,SIGUSR2);
    }
    

    free(THIS_BALCAO->ArrayDeClientes);
    free(THIS_BALCAO->ArrayDeMedicos);
    free(THIS_BALCAO->chats);
    
    printf("\nLibertei a memoria dos teus array\n");
    
    unlink(("BALCAO"));
    printf("\nDesconectei o fifo do balcao\n");
}

//FUNÇÃO PARA MUDAR FREQUENCIA
void mudaFreq(sBalcao *THIS_BALCAO){
    pthread_mutex_lock(&THIS_BALCAO->mutex);
    printf("\nIndique a nova frequencia em segundos\n");
    scanf("%d", &freq);
    pthread_mutex_unlock(&THIS_BALCAO->mutex);
}

//FUNÇÃO PARA APAGAR UM ESPECIALISTA ENCERRANDO-O
void deleteEspecialista(sBalcao *THIS_BALCAO){
    pthread_mutex_lock(&THIS_BALCAO->mutex);
    int pos;
    printf("\nIndique a posicao do especialista que quer remover\n");
    scanf("%d", &pos);
    if(THIS_BALCAO->ArrayDeMedicos[pos].estado!=1){
        if(pos<THIS_BALCAO->numMedicos){
            kill(THIS_BALCAO->ArrayDeMedicos[pos].pid,SIGUSR2);
            printf("\nEnviei um sinal ao medico que estava na pos: %d",pos);
            printf(" para ele se desconectar (SIGUSR2)\n");
           
            organizaMedicos(THIS_BALCAO,pos);
        }
        else{
            printf("\nNao existe especialista nessa posicao\n");
        }
    }
    else{
        printf("\nEsse especialista esta em consulta\n");
    }
    pthread_mutex_unlock(&THIS_BALCAO->mutex);
}

//FUNÇÃO PARA APAGAR CLIENTE ENCERRANDO-O
void deleteUtente(sBalcao *THIS_BALCAO){
    pthread_mutex_lock(&THIS_BALCAO->mutex);
    int pos;
    if(THIS_BALCAO->numClientes>0){
        do{
            printf("\nIndique a posicao do cliente que quer remover\n");
            scanf("%d", &pos);
        }while(pos>=THIS_BALCAO->numClientes);

        if(THIS_BALCAO->ArrayDeClientes[pos].estado!=1){
            
            kill(THIS_BALCAO->ArrayDeClientes[pos].pid,SIGUSR2);
            printf("\nEnviei um sinal ao cliente que estava na pos: %d\n",pos);
            printf(" para ele se desconectar (SIGUSR2)\n");
            
            organizaClientes(THIS_BALCAO,pos);
            
        }
        else{
            printf("\nEsse cliente esta em consulta\n");
        }
    }
    else{
        printf("\nNao existem clientes\n");
    }
    pthread_mutex_unlock(&THIS_BALCAO->mutex);
}

//FUNÇÃO PARA LISTAR ARRAY DE ESPECIALISTAS
void listaEspecialistas(sBalcao *THIS_BALCAO){
    pthread_mutex_lock(&THIS_BALCAO->mutex);
    printf("\nVou listar os especialistas:\n");
    for(int i=0;i<THIS_BALCAO->numMedicos;i++){
        if(&THIS_BALCAO->ArrayDeMedicos[i]!=NULL){
            printf("O medico %s de especialidade %s ",THIS_BALCAO->ArrayDeMedicos[i].nome, THIS_BALCAO->ArrayDeMedicos[i].especialidade);
            if(THIS_BALCAO->ArrayDeMedicos[i].estado==0){
                printf("esta a espera de uma consulta\n");
            }
            if(THIS_BALCAO->ArrayDeMedicos[i].estado==1){
                printf("esta em consulta\n");
            }
        }
    }
    pthread_mutex_unlock(&THIS_BALCAO->mutex);
}

//FUNÇÃO PARA LISTAR ARRAY DE CLIENTES
void listaClientes(sBalcao *THIS_BALCAO){
    pthread_mutex_lock(&THIS_BALCAO->mutex);
    //pos da linha no array de chats do medico que esta a flr com o cliente, NULL se o cliente n estiver a flr com ninguem
    int pos_do_medico_a_falar_com_o_cliente=0;
    //crio um ponteiro para um medico
    medico* medico_que_esta_a_falar_com_o_cliente=NULL;
    
    //percorro todos os clientes
    printf("\nVou percorrer os clientes:");
    for(int i=0; i<THIS_BALCAO->numClientes;i++){
        
        //se houver cliente ainda
        
            
        printf("O [%d] cliente %s", i,THIS_BALCAO->ArrayDeClientes[i].nome);
        printf(" de prioridade %d ", THIS_BALCAO->ArrayDeClientes[i].prioridade);
        //se este cliente estiver a ser atendido
        if(THIS_BALCAO->ArrayDeClientes[i].estado==1){  
            //percorro as linhas do array de chats
            for(int j=0;j<THIS_BALCAO->MAXCLIENTES;j++){
                //e descubro em que linha ta o chat do cliente atual
                if(THIS_BALCAO->chats[j][0]==THIS_BALCAO->ArrayDeClientes[i].pid){
                    //e coloco essa linha nesta variavel
                    pos_do_medico_a_falar_com_o_cliente=j;
                    printf("(pos array de chats: [%d][0 e 1] )",j);
                    break;
                }
            }
                
                
            //percorro a lista de medicos
            for(int j=0;j<THIS_BALCAO->numMedicos;j++){
                //e descubro qual o medico do array de medicos tem o pid igual ao do array de chats que esta a flr com o cliente
                if(THIS_BALCAO->chats[pos_do_medico_a_falar_com_o_cliente][1]==THIS_BALCAO->ArrayDeMedicos[j].pid){
                    medico_que_esta_a_falar_com_o_cliente=&THIS_BALCAO->ArrayDeMedicos[j]; //e coloco o ponteiro a apontar pra esse medico
                }
            }
                    
            printf("esta a falar com o medico %s especialista em %s.\n", medico_que_esta_a_falar_com_o_cliente->nome, medico_que_esta_a_falar_com_o_cliente->especialidade);
 
        }
            
        if(THIS_BALCAO->ArrayDeClientes[i].estado==0){
            printf("esta a espera de ser atendido\n");
        }
            
        if(THIS_BALCAO->ArrayDeClientes[i].estado==2){
            printf("ja foi atendido nao sei o que esta aqui a fazer\n");
        }
        
    }
    printf("\nClientes percorridos\n");
    pthread_mutex_unlock(&THIS_BALCAO->mutex);
}

void* Admin_interface(void* balcao_recebido){
    sBalcao* THIS_BALCAO = (sBalcao*) balcao_recebido;

    //LE E EXECUTA COMANDOS DO ADMINISTRADOR
	char comando[20];

    int fd_writeC;
    int size_writeC;
    sleep(2);
    do{
        printf("\nBota Comando bro\n");
        fgets(comando,sizeof(comando),stdin);
        fflush(stdin);
        printf("\nGanda comando: %s\n",comando);

        if(strcmp(comando,"utentes\n")==0||strcmp(comando,"especialistas\n")==0||
        strcmp(comando,"delut\n")==0||strcmp(comando,"delesp\n")==0||
        strcmp(comando,"freq\n")==0||strcmp(comando,"encerra\n")==0 ||
        strcmp(comando,"writepid\n")==0){

            if(strcmp(comando,"utentes\n")==0){
                listaClientes(THIS_BALCAO);
            }
            if(strcmp(comando,"especialistas\n")==0){
                listaEspecialistas(THIS_BALCAO);
            }
            if(strcmp(comando,"delut\n")==0){
                deleteUtente(THIS_BALCAO);
            }
            if(strcmp(comando,"delesp\n")==0){
                deleteEspecialista(THIS_BALCAO);
            }
            if(strcmp(comando,"freq\n")==0){
                mudaFreq(THIS_BALCAO);
            }
            if(strcmp(comando,"encerra\n")==0){
                kill(THIS_BALCAO->pid,SIGINT);
            }
            if(strcmp(comando,"writepid\n")==0){
                fd_writeC=open("BALCAO",O_WRONLY|O_NONBLOCK);
                if(fd_writeC==-1){printf("\nNao consegui abrir o fifo\n");}
                size_writeC=write(fd_writeC,&THIS_BALCAO->pid,sizeof(pid_t));
                printf("\nColoquei o meu pid no fifo: %d : que tem o tamanho %d\n",THIS_BALCAO->pid,size_writeC);
            }
        }

        else{
            printf("\nComando Invalido\n");
        }

	}while(strcmp(comando,"encerra\n")!=0);
}
   
         
void main()
{
    printf("\nBalcao iniciado bro\n");
    //CRIAR UMA VARIAVEL DO TIPO sBalcao
    sBalcao THIS_BALCAO;

    sleep(1);
    
    //INIT PID BALCAO
    THIS_BALCAO.pid=getpid();
    printf("\nPID do Balcao: %d\n", THIS_BALCAO.pid);

    sleep(1);
    
    //INIT MUTEX
    pthread_mutex_init(&THIS_BALCAO.mutex,NULL); 
    printf("\nInicializei o teu mutex bro\n");

    sleep(1);

    //INIT MAX pessoas
    /*
    THIS_BALCAO.MAXCLIENTES=(int)(*getenv("MAXCLIENTES"));
    printf("\nO teu numero max de clientes e %d", THIS_BALCAO.MAXCLIENTES);
    sleep(5);

    THIS_BALCAO.MAXMEDICOS=(int)(*getenv("MAXMEDICOS"));
    printf("\nO teu numero max de medicos e %d",THIS_BALCAO.MAXMEDICOS);
    sleep(5);
    */

    THIS_BALCAO.MAXCLIENTES=maxCli;
    printf("\nO teu numero max de clientes e %d", THIS_BALCAO.MAXCLIENTES);
    THIS_BALCAO.MAXMEDICOS=maxMed;
    printf("\nO teu numero max de medicos e %d\n",THIS_BALCAO.MAXMEDICOS);

    sleep(1);
    
	//ALOCAR MEM NOS ARRAYS
	THIS_BALCAO.ArrayDeClientes=malloc((THIS_BALCAO.MAXCLIENTES * (sizeof(cliente))));
    printf("\nArray de clientes tem espaço para %d clientes\n",THIS_BALCAO.MAXCLIENTES);
	THIS_BALCAO.ArrayDeMedicos=malloc(THIS_BALCAO.MAXMEDICOS * (sizeof(medico)));
    printf("\nArray de medico tem espaco para %d medicos\n",THIS_BALCAO.MAXMEDICOS);
    
    sleep(1);

	//ALOCAR MEM NO ARRAY DE CHATS
	THIS_BALCAO.chats=(pid_t**)malloc(THIS_BALCAO.MAXCLIENTES*(sizeof(pid_t*)));
	for(int i=0;i<THIS_BALCAO.MAXCLIENTES;i++){
		THIS_BALCAO.chats[i]=(pid_t*)malloc(2 * (sizeof(pid_t)));
	}
    THIS_BALCAO.n_chats=0;

    printf("\nAloquei memoria pra %d Pids no teu array de chats bro\n",(2 * THIS_BALCAO.MAXCLIENTES));

    sleep(1);

    THIS_BALCAO.numClientes=0;
    THIS_BALCAO.numMedicos=0;
    THIS_BALCAO.n_chats=0;

    printf("\nTem %d clientes, %d medicos, e %d chats)",THIS_BALCAO.numClientes,THIS_BALCAO.numMedicos,THIS_BALCAO.n_chats);

	
    //INICIALIZAR ARRAY DE CHATS A 0

    for(int i=0;i<THIS_BALCAO.MAXCLIENTES;i++){
        for(int j=0;j<2;j++){
            THIS_BALCAO.chats[i][j]=0;
        }
    }

    printf("\nArray de chats:\n");
    for(int i=0;i<THIS_BALCAO.MAXCLIENTES;i++){
        printf("[%d][%d]",THIS_BALCAO.chats[i][0],THIS_BALCAO.chats[i][1]);
        printf("\n");
    }

    sleep(1);
    
    //CRIAR PIPE DO BALCAO

    if(mkfifo("BALCAO",0666) == -1){
        if(errno == EEXIST){
            printf("fifo ja existe");
        }
        printf("erro ao abrir fifo");
        exit(1);
    }
    printf("\nCriei o seu fifo administradorzinho\n");

    sleep(1);
    
    
    //CRIAÇÃO DOS SINAIS DO BALCÃO
    struct sigaction sigMata ={0};
    sigMata.sa_flags=SA_RESTART;
	sigMata.sa_handler=&handle_sigint;
    sigaction(SIGINT,&sigMata,NULL);
    

    //ESCREVE PID NO FIFO
    int fd_primeiro=open("BALCAO",O_WRONLY|O_NONBLOCK);
    int size_primeiro=write(fd_primeiro,&THIS_BALCAO.pid,sizeof(pid_t));
    printf("\nColoquei o meu pid no fifo: %d",THIS_BALCAO.pid);

    //CRIAÇÃO DAS THREADS
        //thread que conecta clientes a medicos 
        printf("\nVou criar uma thread maluca pra ligar medicos a clientes\n");
        sleep(2);
    pthread_t CONVERSAS;
    int iCONVERSAS;
    iCONVERSAS=pthread_create(&CONVERSAS,NULL,&connect_conversas,&THIS_BALCAO);
        sleep(2);

        //thread que apaga clientes e medicos quando estes saem
        printf("\nVou criar uma thread maluca pra apagar medicos a clientes qnd saem\n");
        sleep(2);
    pthread_t Del;
    int iDel;
    iDel=pthread_create(&Del,NULL,&ApagaClientesOuMedicos,&THIS_BALCAO);
        sleep(2);

        //thread que fica a escuta de novos clientes e medicos 
        printf("\nVou criar uma thread maluca pra esperar por clientes e medicos\n");
        sleep(2);
    pthread_t Escuta;
    int iEscuta;
    iEscuta=pthread_create(&Escuta,NULL,&EscutaClientesEMedicos,&THIS_BALCAO);
        sleep(2);

        //thread ativa qnd medico acaba chat
        printf("\nVou criar uma thread maluca pra qnd um medico acaba um chat\n");
        sleep(2);
    pthread_t med_end_chat;
    int iMed_end_chat;
    iMed_end_chat=pthread_create(&med_end_chat,NULL,&Medico_chat_over,&THIS_BALCAO);
        sleep(2);

        

        //thread que lista filas de -freq- em -freq- segundos
        printf("\nVou criar uma thread maluca pra listar filas de espera\n");
        sleep(2);
    pthread_t listaDeEspera;
    int iListaDeEspera;
    iListaDeEspera=pthread_create(&listaDeEspera,NULL,&listaFilas,&THIS_BALCAO);
        sleep(2);

        //thread que recebe e executa comandos
        printf("\nVou criar uma thread maluca pra pedir e executar comandos\n");
    pthread_t admin_ui;
    int iadmin_ui;
    iadmin_ui=pthread_create(&admin_ui,NULL,&Admin_interface,&THIS_BALCAO);

    



    //espera sinais e reencaminha
    sigset_t sinais;
    sigemptyset(&sinais);
    sigaddset(&sinais,SIGUSR1);
    sigaddset(&sinais,SIGUSR2);
    sigaddset(&sinais,SIGIO);
    sigaddset(&sinais,SIGPROF);
    sigaddset(&sinais,SIGINT);

    

    printf("\nJa ta tudo a funciminar espero eu\n Aguarde 2 segundos para digitar comandos\n");
    sleep(1);

    int sinal;
    do{
        printf("\nEsperando um sinal\n");
        sigwait(&sinais,&sinal);

        printf("\nBalcao recebeu sinal: %d\n",sinal);
        if(sinal==10||sinal==12){

            printf("\nVou adicionar o sinal utilizado novamente\n");
            sigaddset(&sinais,sinal);
            printf("\nAdicionei o sinal novamente\n");

            printf("\nVou enviar sinal SIGUSR1 OU SIGUSR2 as threads\n");
            pthread_kill(Escuta,sinal);
            pthread_kill(CONVERSAS,sinal);
            printf("\nEnviei\n");

            sleep(5);
        } 
        if(sinal==29){
            printf("\nVou enviar sinal SIGIO as threads\n");
            sleep(5);
            pthread_kill(med_end_chat,sinal);
            sigaddset(&sinais,sinal);
        }
        if(sinal==27){
            printf("\nVou enviar sinal SIGPROF as threads\n");
            sleep(5);
            pthread_kill(Del,sinal);
            sigaddset(&sinais,sinal);
        }
    }while(sinal!=2); 

    sleep(5);
    
    pthread_kill(CONVERSAS,SIGINT);
    pthread_kill(listaDeEspera,SIGINT);
    pthread_kill(Del,SIGINT);
    pthread_kill(Escuta,SIGINT);
    pthread_kill(med_end_chat,SIGINT);
    printf("\nDesconectei todas as minhas threads\n");

    encerraTudo(&THIS_BALCAO);
    
    pthread_kill(admin_ui,SIGINT);
    printf("\nDesconectei a thread do admin interface\n");

    printf("\nBALCAO ENCERRADO\n");

    
}

