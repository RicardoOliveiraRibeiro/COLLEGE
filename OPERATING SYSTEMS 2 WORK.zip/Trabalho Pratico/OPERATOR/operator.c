
#include "operator.h"



DWORD WINAPI _showBoard(LPVOID lpParam) {
    OPERATOR_DATA _opData = *(OPERATOR_DATA*)lpParam;

    while (WaitForSingleObject(_opData._hExitEventOperator, 0) == WAIT_TIMEOUT) {
        WaitForSingleObject(_opData._hMutex, INFINITE);



        _tprintf(_T("\n"));
       
        for (DWORD i = 0; i < _opData._sharedMem->_nColunasAtual;i++) {
            _tprintf(_T("___"));
        }
        _tprintf(_T("\n"));

        for (DWORD i = 0; i < _opData._sharedMem->_nLinhasAtual; i++) {
            for (DWORD j = 0; j < _opData._sharedMem->_nColunasAtual; j++) {
                if (_opData._sharedMem->_tabuleiro[i][j] == 0) {
                    _tprintf(_T("   "));
                }
                if (_opData._sharedMem->_tabuleiro[i][j] == 1) {
                    _tprintf(_T("{>}"));
                }
                if (_opData._sharedMem->_tabuleiro[i][j] == 2) {
                    _tprintf(_T("{<}"));
                }
                if (_opData._sharedMem->_tabuleiro[i][j] == 10) {
                    _tprintf(_T("[1]"));
                }
                if (_opData._sharedMem->_tabuleiro[i][j] == 11) {
                    _tprintf(_T("[2]"));
                }
                if (_opData._sharedMem->_tabuleiro[i][j] == 30) {
                    _tprintf(_T("[|]"));
                }
            }
            _tprintf(_T("\n"));
        }

        for (DWORD i = 0; i < _opData._sharedMem->_nColunasAtual;i++) {
            _tprintf(_T("---"));
        }

        ReleaseMutex(_opData._hMutex);
        
        Sleep(_opData._sharedMem->_gameSpeed*100);




        /*

        _tprintf(_T("\n"));
        for (int i = 0; i < _opData._sharedMem->_nLinhasAtual; i++) {
            _tprintf(_T("|"));
            for (int j = 0; j < _opData._sharedMem->_nColunasAtual; j++) {
                if (_opData._sharedMem->_tabuleiro[i][j] == _T(' ')) {
                    _tprintf(_T(" |"));
                }
                else {
                    _tprintf(_T("%lc|"), _opData._sharedMem->_tabuleiro[i][j]);
                }
            }
            _tprintf(_T("\n"));
        }
        _tprintf(_T("\n"));
        ReleaseMutex(_opData._hMutex);
        Sleep(_opData._sharedMem->_gameSpeed);

        */
    }
    return 1;

}





int _tmain(int argc, TCHAR* argv[]) {


#ifdef UNICODE
    _setmode(_fileno(stdin), _O_WTEXT);
    _setmode(_fileno(stdout), _O_WTEXT);
    _setmode(_fileno(stderr), _O_WTEXT);
#endif

    HANDLE _hEventWaitForOperators = OpenEvent(EVENT_ALL_ACCESS, FALSE, WAIT_FOR_OPERATORS_EVENT_NAME);
    if (GetLastError() == ERROR_FILE_NOT_FOUND) {
        _tprintf(_T("\n(OPERATOR MAIN) SERVER NOT RUNNING\n"));
        return 1;
    }
    if (_hEventWaitForOperators != NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) SERVER RUNNING\n"));
        PulseEvent(_hEventWaitForOperators);
    }
    else {
        _tprintf(_T("\n(OPERATOR MAIN) FAILED TO OPEN WAIT FOR OPERATOR EVENT\n"));
        return 1;
    }


    OPERATOR_DATA _opData;

    //INIT EXIT EVENT
    _opData._hExitEventOperator = CreateEvent(NULL, TRUE, FALSE, EXIT_EVENT_OPERATOR_NAME);
    if (_opData._hExitEventOperator != NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) CREATED EXIT EVENT SUCCESSFULLY"));
    }
    else {
        _tprintf(_T("\n(OPERATOR MAIN) EXIT EVENT CREATION FAILED"));
        CloseHandle(_hEventWaitForOperators);
        return 1;
    }

    //ABRIR EXIT SERVER EVENT
    _opData._hExitEventServer = OpenEvent(EVENT_ALL_ACCESS, FALSE, EXIT_EVENT_SERVER_NAME);
    if (GetLastError() == ERROR_FILE_NOT_FOUND) {
        _tprintf(_T("\n(OPERATOR MAIN) SERVER NOT RUNNING\n"));
        CloseHandle(_hEventWaitForOperators);
        return 1;
    }
    if (_opData._hExitEventServer == NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) FAILED TO OPEN EXIT EVENT FOR SERVER\n"));
        CloseHandle(_hEventWaitForOperators);
        return 1;
    }
    else {
        _tprintf(_T("\n(OPERATOR MAIN) SERVER RUNNING\n"));
    }

    HANDLE hMapFile = OpenFileMapping(
        FILE_MAP_ALL_ACCESS,
        FALSE,
        SHARED_MEMORY_NAME
    );
    if (hMapFile == NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) FAILED TO OPEN FILE MAP\n"));
        CloseHandle(_opData._hExitEventOperator);
        CloseHandle(_opData._hExitEventServer);
        CloseHandle(_hEventWaitForOperators);
        return 1;
    }
    _tprintf(_T("\n(OPERATOR MAIN) FILE MAP OPPENED SUCCESSFULLY\n"));
    
    LPVOID lpMapAddress = MapViewOfFile(
        hMapFile,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        sizeof(SH_MEM)
    );
    if (lpMapAddress == NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) FAILED TO MAP VIEW OF FILE\n"));
        CloseHandle(_opData._hExitEventOperator);
        CloseHandle(_opData._hExitEventServer);

        CloseHandle(_hEventWaitForOperators);
        return 1;

    }
    _tprintf(_T("\n(OPERATOR MAIN) VIEW OF FILE MAPPED SUCCESSFULLY\n"));

    //CAST DO PONTEIRO MEM PARTILHADA PARA PONTEIRO COMMANDS_STRUCT
    _opData._sharedMem = (SH_MEM*)lpMapAddress;


    //CREATE THREADS (_waitForOperators && _waitForCommands)
    HANDLE _hOperatorThread;
    DWORD _operatorThreadId;
    _hOperatorThread = CreateThread(NULL, 0, _showBoard, (LPVOID)(&_opData), 0, &_operatorThreadId);

    if (_hOperatorThread == NULL) {
        _tprintf(_T("(OPERATOR MAIN) ERRO AO CRIAR THREAD \n"));
        SetEvent(_opData._hExitEventOperator);
        CloseHandle(_opData._hExitEventOperator);
        CloseHandle(_hEventWaitForOperators);
        CloseHandle(_opData._hExitEventServer);

        UnmapViewOfFile(lpMapAddress);
        CloseHandle(hMapFile);
        return 1;
    }
    else {
        _tprintf(_T("\n(OPERATOR MAIN) THREAD CREATED SUCCESSFULLY"));
    }


    //OPEN SYNC COMMAND OBJECTS
    HANDLE _hSemWrite = OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, SEMAPHORE_COMMAND_WRITE_NAME);
    if (_hSemWrite == NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) FAILED TO OPEN COMMAND WRITE SEMAPHORE\n"));
        SetEvent(_opData._hExitEventOperator);
        CloseHandle(_hOperatorThread);
        CloseHandle(_opData._hExitEventOperator);
        CloseHandle(_hEventWaitForOperators);
        CloseHandle(_opData._hExitEventServer);

        UnmapViewOfFile(lpMapAddress);
        CloseHandle(hMapFile);
        return 1;
    }
    _tprintf(_T("\n(OPERATOR MAIN) WRITE SEMAPHORE OPENNED SUCCESSFULLLY\n"));
    HANDLE _hSemRead = OpenSemaphore(SEMAPHORE_ALL_ACCESS, FALSE, SEMAPHORE_COMMAND_READ_NAME);
    if (_hSemRead == NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) FAILED TO OPEN COMMAND READ SEMAPHORE\n"));
        SetEvent(_opData._hExitEventOperator);
        CloseHandle(_hOperatorThread);
        CloseHandle(_opData._hExitEventOperator);
        CloseHandle(_hEventWaitForOperators);
        CloseHandle(_opData._hExitEventServer);

        UnmapViewOfFile(lpMapAddress);
        CloseHandle(hMapFile);
        CloseHandle(_hSemWrite);
        return 1;
    }
    _tprintf(_T("\n(OPERATOR MAIN) READ SEMAPHORE OPPENED SUCCESSFULLY\n"));
    _opData._hMutex = OpenMutex(SYNCHRONIZE, FALSE, MUTEX_SHARED_MEM_NAME);
    if (_opData._hMutex == NULL) {
        _tprintf(_T("\n(OPERATOR MAIN) FAILED TO OPEN SHARED MEM MUTEX\n"));
        SetEvent(_opData._hExitEventOperator);
        CloseHandle(_hOperatorThread);
        CloseHandle(_opData._hExitEventOperator);
        CloseHandle(_hEventWaitForOperators);
        CloseHandle(_opData._hExitEventServer);

        UnmapViewOfFile(lpMapAddress);
        CloseHandle(hMapFile);
        CloseHandle(_hSemWrite);
        CloseHandle(_hSemRead);
        return 1;
    }
    _tprintf(_T("\n(OPERATOR MAIN) SHARED MEM MUTEX OPENNED SUCCESSFULLY\n"));
    


    //ENQUANTO EXIT NAO SINALADO
    //BUFFER CIRCULAR PEDE COMANDOS AO USER E ENVIA PARA O SERVER
    HANDLE _hEventosArray[2] = { _opData._hExitEventOperator, _opData._hExitEventServer };
    while ((WaitForMultipleObjects(2, _hEventosArray, FALSE, 0) == WAIT_TIMEOUT)) {
        _tprintf(_T("\nDIGITE COMANDOS\n"));
        _tscanf_s(_T("%c %u %u"), &_opData._command, sizeof(TCHAR), &_opData._val1, & _opData._val2);

        WaitForSingleObject(_hSemWrite, INFINITE);
        WaitForSingleObject(_opData._hMutex, INFINITE);
        _opData._sharedMem->_CommandsBuffer[_opData._sharedMem->_WriteIndex] = _opData._command;
        _opData._sharedMem->_ValBuffer1[_opData._sharedMem->_WriteIndex] = _opData._val1;
        _opData._sharedMem->_ValBuffer2[_opData._sharedMem->_WriteIndex] = _opData._val2;

        _opData._sharedMem->_WriteIndex = (_opData._sharedMem->_WriteIndex + 1) % 10;
        ReleaseMutex(_opData._hMutex);
        ReleaseSemaphore(_hSemRead, 1, NULL);
        if (_opData._command==_T('e')) {
            SetEvent(_opData._hExitEventOperator);
        }
    }
    ResetEvent(_opData._hExitEventOperator);


    _tprintf(_T("\n(OPERATOR MAIN) OPERATOR SHUTTING DOWN\n"));

    CloseHandle(_hOperatorThread);
    CloseHandle(_opData._hExitEventOperator);
    CloseHandle(_hEventWaitForOperators);
    UnmapViewOfFile(lpMapAddress);
    CloseHandle(hMapFile);
    CloseHandle(_hSemWrite);
    CloseHandle(_hSemRead);
}
