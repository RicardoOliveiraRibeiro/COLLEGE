#pragma once
#include <windows.h>
#include <string.h>
#include <tchar.h>
#include <io.h>
#include <fcntl.h>
#include <stdio.h>

#define EXIT_EVENT_OPERATOR_NAME _T("EXIT_EVENT_OPERATOR_NAME")
#define EXIT_EVENT_SERVER_NAME _T("EXIT_EVENT_SERVER_NAME")

#define SHARED_MEMORY_NAME _T("SHARED_MEMORY_NAME")
#define MUTEX_SHARED_MEM_NAME _T("MUTEX_SHARED_MEM_NAME")
#define WAIT_FOR_OPERATORS_EVENT_NAME _T("WAIT_FOR_OPERATORS_EVENT_NAME")
#define SEMAPHORE_COMMAND_WRITE_NAME _T("SEMAPHORE_COMMAND_WRITE_NAME")
#define SEMAPHORE_COMMAND_READ_NAME _T("SEMAPHORE_COMMAND_READ_NAME")


typedef struct SH_MEM {
    DWORD _WriteIndex;
    DWORD _ReadIndex;
    TCHAR _CommandsBuffer[10];
    DWORD _ValBuffer1[10];
    DWORD _ValBuffer2[10];
    DWORD _tabuleiro[10][20];
    DWORD _nLinhasAtual;
    DWORD _nColunasAtual;
    DWORD _gameSpeed;
    DWORD _sapoCount;
}SH_MEM;

typedef struct OPERATOR_DATA {
    HANDLE _hExitEventOperator;
    HANDLE _hExitEventServer;
    HANDLE _hMutex;
    SH_MEM* _sharedMem;
    TCHAR _command;
    DWORD _val1;
    DWORD _val2;
}OPERATOR_DATA;