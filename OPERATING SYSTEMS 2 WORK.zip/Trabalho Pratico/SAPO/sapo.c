#include "sapo.h"

LRESULT CALLBACK TrataEventos(HWND, UINT, WPARAM, LPARAM);

TCHAR szProgName[] = TEXT("Base");
HBITMAP hCarro1Bmp, hCarroBmp, hSapo1Bmp, hSapo2Bmp, hObstaculoBmp;

DWORD WINAPI PipeListenerThread(LPVOID lpParam) {
    SAPO_DATA _sapoData = *(SAPO_DATA*)lpParam;
    while (1) {
        //aguarda alguma coisa no pipe
        ReadFile(_sapoData._hpipeServSapo, &_sapoData._comsWithSapo, sizeof(PIPE_COM_STRUCT), NULL, NULL);
        //quando recebe assinala costume event WM_PIPE_MESSAGE e envia para o mesmo a estrutura _comsWithSapo
        PostMessage(_sapoData._hwnd, WM_PIPE_MESSAGE,&_sapoData._comsWithSapo,&_sapoData._comsWithSapo);
        
    }
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow) {


    HWND hWnd;
    MSG lpMsg;
    WNDCLASSEX wcApp;

    wcApp.cbSize = sizeof(WNDCLASSEX);
    wcApp.hInstance = hInst;
    wcApp.lpszClassName = szProgName;
    wcApp.lpfnWndProc = TrataEventos;
    wcApp.style = CS_HREDRAW | CS_VREDRAW;
    wcApp.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcApp.hIconSm = LoadIcon(NULL, IDI_INFORMATION);
    wcApp.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcApp.lpszMenuName = NULL;
    wcApp.cbClsExtra = 0;
    wcApp.cbWndExtra = 0;
    wcApp.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);

    if (!RegisterClassEx(&wcApp))
        return 0;

    

    // Load the bitmaps
    hCarro1Bmp = (HBITMAP)LoadImage(NULL, TEXT("carro1.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
    hCarroBmp = (HBITMAP)LoadImage(NULL, TEXT("carro.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
    hSapo1Bmp = (HBITMAP)LoadImage(NULL, TEXT("sapo1.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
    hSapo2Bmp = (HBITMAP)LoadImage(NULL, TEXT("sapo2.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);
    hObstaculoBmp = (HBITMAP)LoadImage(NULL, TEXT("obstaculo.bmp"), IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);

    hWnd = CreateWindow(
        szProgName,
        TEXT("FROGGER"),
        WS_OVERLAPPEDWINDOW,
        0,
        0,
        1000,
        500,
        (HWND)HWND_DESKTOP,
        (HMENU)NULL,
        (HINSTANCE)hInst,
        0
    );

    ShowWindow(hWnd, nCmdShow);
    UpdateWindow(hWnd);


    while (GetMessage(&lpMsg, NULL, 0, 0)) {
        TranslateMessage(&lpMsg);
        DispatchMessage(&lpMsg);
    }

    return (int)lpMsg.wParam;

}

void DesenhaImagem(HDC hdc, HBITMAP hBitmap, int x, int y) {
    HDC hdcMem = CreateCompatibleDC(hdc);
    HBITMAP hBitmapOld = (HBITMAP)SelectObject(hdcMem, hBitmap);

    BITMAP bitmap;
    GetObject(hBitmap, sizeof(BITMAP), &bitmap);

    BitBlt(hdc, x, y, bitmap.bmWidth, bitmap.bmHeight, hdcMem, 0, 0, SRCCOPY);

    SelectObject(hdcMem, hBitmapOld);
    DeleteDC(hdcMem);
}

void DesenhaTabuleiro(HDC hdc, DWORD tabuleiro[10][20]) {
    const int tileSize = 25; // Adjust the tile size according to your needs

    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
         
            int _characterInTabuleiro = tabuleiro[i][j];
           
            int xPos = j * tileSize;
            int yPos = i * tileSize;
            switch (_characterInTabuleiro) {
            case 1:
                DesenhaImagem(hdc, hCarro1Bmp, xPos, yPos);
                break;
            case 2:
                DesenhaImagem(hdc, hCarroBmp, xPos, yPos);
                break;
            case 10:
                DesenhaImagem(hdc, hSapo1Bmp, xPos, yPos);
                break;
            case 11:
                DesenhaImagem(hdc, hSapo2Bmp, xPos, yPos);
                break;
            case 30:
                DesenhaImagem(hdc, hObstaculoBmp, xPos, yPos);
                break;
            }
        }
    }
}

LRESULT CALLBACK TrataEventos(HWND hWnd, UINT messg, WPARAM wParam, LPARAM lParam) {
    static DWORD tabuleiro[10][20];
    static SAPO_DATA _sapoData;

    switch (messg) {
    case WM_PIPE_MESSAGE: {
        // Assuming the received structure is PIPE_COM_STRUCT and contains the tabuleiro data
        PIPE_COM_STRUCT* pComStruct = (PIPE_COM_STRUCT*)lParam;
        memcpy(tabuleiro, pComStruct->_tabuleiro, sizeof(tabuleiro));
        InvalidateRect(hWnd, NULL, TRUE);

        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);

        // Clear the background
        RECT clientRect;
        GetClientRect(hWnd, &clientRect);
        FillRect(hdc, &clientRect, (HBRUSH)GetStockObject(WHITE_BRUSH));

        // Draw the board
        DesenhaTabuleiro(hdc, tabuleiro);

        EndPaint(hWnd, &ps);
    }
    break;
    case WM_PAINT:
    {
      /*  PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);

        // Clear the background
        RECT clientRect;
        GetClientRect(hWnd, &clientRect);
        FillRect(hdc, &clientRect, (HBRUSH)GetStockObject(WHITE_BRUSH));

        // Draw the board
        DesenhaTabuleiro(hdc, tabuleiro);

        EndPaint(hWnd, &ps);
        */
    }
    break;
    case WM_KEYDOWN:
        //sempre que � pressionado uma tecla
        switch (wParam) {
        case VK_UP:
            _sapoData._command = 1;
            break;
        case VK_DOWN:
            _sapoData._command = 4;
            break;
        case VK_LEFT:
            _sapoData._command = 3;
            break;
        case VK_RIGHT:
            _sapoData._command = 2;
            break;
        case 'W':
            _sapoData._command = 10;
            break;
        case 'A':
            _sapoData._command = 12;
            break;
        case 'S':
            _sapoData._command = 13;
            break;
        case 'D':
            _sapoData._command = 11;
            break;
        }
        WriteFile(
            _sapoData._hpipeSapoServ,
            &_sapoData._command,
            sizeof(DWORD),
            _sapoData._numberOfBytes,
            NULL
        );
        break;
    case WM_CREATE:
        //abre pipe de receber do servidor
        _sapoData._hpipeServSapo = CreateFile(
            _T("\\\\.\\pipe\\ComsWithSapo"),
            GENERIC_READ,
            0,
            NULL,
            OPEN_EXISTING,
            0,
            NULL
        );
        if (_sapoData._hpipeServSapo == NULL) { return 1; }
        //abre pipe de enviar para o servidor
        _sapoData._hpipeSapoServ = CreateFile(
            _T("\\\\.\\pipe\\Coms2WithSapo"),
            GENERIC_WRITE,
            0,
            NULL,
            OPEN_EXISTING,
            0,
            NULL
        );

        if (_sapoData._hpipeSapoServ == NULL) { return 1; }

        //inicia thread de escuta
        HANDLE hThread = CreateThread(NULL, 0, PipeListenerThread, &_sapoData, 0, NULL);


        //abre message box a perguntar quantos jogadores s�o
        int result = MessageBox(hWnd, TEXT("1 JOGADOR?"), TEXT("Escolha"), MB_ICONQUESTION | MB_YESNO);
        //se o jogador selecionar 1 jogador
        if (result == IDYES) {
            _sapoData._command = 1;
            _sapoData._numberOfSaposAtual = 1;
        }
        //se o jogador selecionar 2 jogadores
        else if (result == IDNO) {
            _sapoData._command = 2;
            _sapoData._numberOfSaposAtual = 2;
        }
        //se o jogador n�o selecionar nada
        else {
            return 1;
        }
        //envia para o servidor quantos jogadores s�o
        BOOL isSuccess = WriteFile(
            _sapoData._hpipeSapoServ,
            &_sapoData._command,
            sizeof(DWORD),
            _sapoData._numberOfBytes,
            NULL
        );
        break;
    case WM_DESTROY:
        //envia ao server commando 100
        _sapoData._command = 100;

        WriteFile(
            _sapoData._hpipeSapoServ,
            &_sapoData._command,
            sizeof(DWORD),
            _sapoData._numberOfBytes,
            NULL
        );        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, messg, wParam, lParam);
    }
    return 0;
}
