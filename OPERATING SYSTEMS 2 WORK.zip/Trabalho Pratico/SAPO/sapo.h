#pragma once

#include <windows.h>
#include <string.h>
#include <tchar.h>
#include <io.h>
#include <fcntl.h>
#include <stdio.h>

#define WM_PIPE_MESSAGE (WM_USER + 1)


typedef struct pipestruct {
    DWORD _tabuleiro[10][20];
    DWORD _sapo;
    DWORD _command;
    DWORD _numberOfBytes;
    DWORD _exitFlag;

}PIPE_COM_STRUCT;


typedef struct SAPO_DATA {
    HANDLE _hpipeServSapo;
    HANDLE _hpipeSapoServ;
    DWORD _command;
    DWORD _numberOfBytes;
    DWORD _numberOfSaposAtual;
    DWORD _exitFlag;
    HDC _hdc;
    HWND _hwnd;
    PIPE_COM_STRUCT _comsWithSapo;
}SAPO_DATA;