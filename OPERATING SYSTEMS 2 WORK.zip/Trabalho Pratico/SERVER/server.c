
#include "server.h"


DWORD WINAPI _RunGame(LPVOID lpParam) {
    SERVER_DATA _servData = *(SERVER_DATA*)lpParam;
    //INITIALIZE SPEED
    _servData._sharedMem->_gameSpeed = 50;
    //INITIALIZE BOARD
    WaitForSingleObject(_servData._hMutex, INFINITE);
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 20; j++) {
            _servData._sharedMem->_tabuleiro[i][j] = 0;
        }
    }
    ReleaseMutex(_servData._hMutex);
    WaitForSingleObject(_servData._hMutex, INFINITE);
    _servData._sapoCount = _servData._sharedMem->_sapoCount;
    ReleaseMutex(_servData._hMutex);
    _tprintf(_T("\n(SERVER -> RUN GAME) NUMERO DE SAPOS A JOGAR: (%u)\n"), _servData._sapoCount);

    if (_servData._sapoCount == 1) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][2] = 10;
        ReleaseMutex(_servData._hMutex);
    }
    else {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][2] = 10;
        _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][8] = 11;
        ReleaseMutex(_servData._hMutex);
    }

    //GERAR SAPOS
    /*
    srand(GetTickCount64());

    DWORD _slotSapo1 = 0;
    int slot = rand() % _servData._sharedMem->_nColunasAtual;
    _slotSapo1 = slot;
    WaitForSingleObject(_servData._hMutex, INFINITE);
    _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual-1][_slotSapo1] = 10;
    ReleaseMutex(_servData._hMutex);
    DWORD _slotSapo2 = _slotSapo1;
    while (_slotSapo2 = _slotSapo1) {
        slot = rand() % _servData._sharedMem->_nColunasAtual;
        _slotSapo2 = slot;
    }
    WaitForSingleObject(_servData._hMutex, INFINITE);
    _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual-1][_slotSapo2] = 11;
    ReleaseMutex(_servData._hMutex);
    */

    DWORD _carroAndouPar = 0;
    DWORD _carroAndouImpar = 0;
    while (WaitForSingleObject(_servData._hExitEventServer, 0) == WAIT_TIMEOUT) {
        //MOVE CARS PAR
        for (DWORD i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) { //percorre linhas
            _carroAndouPar = 0;
            for (DWORD j = 0; j < _servData._sharedMem->_nColunasAtual; j++) { //percorre colunas

                if (_servData._sharedMem->_tabuleiro[i][j] == 1) { //se houver um carro
                    if (_carroAndouPar == 0) { //e se esse carro ainda nao andou

                        if (j == (_servData._sharedMem->_nColunasAtual) - 1 || _servData._sharedMem->_tabuleiro[i][j + 1] == 30) { //se ele estiver na ultima coluna
                            WaitForSingleObject(_servData._hMutex, INFINITE);
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            ReleaseMutex(_servData._hMutex);
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        else {                                                  //se ele nao estiver na ultima coluna vai andar
                            WaitForSingleObject(_servData._hMutex, INFINITE);
                            //se para onde vai andar estiver o sapo 1
                            if (_servData._sharedMem->_tabuleiro[i][j + 1] == 10) {
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[i][j + 1] = 1;
                                //sapo1 volta ao inicio
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j + 1] = 10;

                            }
                            else {
                                //se para onde vai andar estiver o sapo 2
                                if (_servData._sharedMem->_tabuleiro[i][j + 1] == 11) {
                                    _servData._sharedMem->_tabuleiro[i][j] = 0;
                                    _servData._sharedMem->_tabuleiro[i][j + 1] = 1;
                                    //sapo2 volta ao inicio
                                    _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j + 1] = 10;

                                }
                                //senao anda so
                                else {
                                    _servData._sharedMem->_tabuleiro[i][j] = 0;
                                    _servData._sharedMem->_tabuleiro[i][j + 1] = 1;
                                }
                            }
                            ReleaseMutex(_servData._hMutex);
                            //sinaliza evento que come�a o envio do tabuleiro para o sapo
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }


                        _carroAndouPar = 1;
                    }
                }
            }
        }

        //MOVE CARS IMPAR
        for (DWORD i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) { //percorre linhas
            _carroAndouImpar = 0;
            for (DWORD j = 0; j < _servData._sharedMem->_nColunasAtual; j++) { //percorre colunas

                if (_servData._sharedMem->_tabuleiro[i][j] == 2) { //se houver um carro
                    if (_carroAndouImpar == 0) { //e se esse carro ainda nao andou

                        if (j == 0 || _servData._sharedMem->_tabuleiro[i][j - 1] == 30) { //se ele estiver na primeira coluna
                            WaitForSingleObject(_servData._hMutex, INFINITE);
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            ReleaseMutex(_servData._hMutex);
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        else {      //se ele nao estiver na primeira coluna vai andar
                            WaitForSingleObject(_servData._hMutex, INFINITE);
                            //se para onde vai andar estiver o sapo 1
                            if (_servData._sharedMem->_tabuleiro[i][j - 1] == 10) {
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[i][j - 1] = 2;
                                //volta sapo para o inicio
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j - 1] = 10;
                            }
                            //senao
                            else {
                                //se para onde vai andar estiver o sapo 2
                                if (_servData._sharedMem->_tabuleiro[i][j - 1] == 11) {
                                    _servData._sharedMem->_tabuleiro[i][j] = 0;
                                    _servData._sharedMem->_tabuleiro[i][j - 1] = 2;
                                    //volta sapo 2 para o inicio
                                    _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j - 1] = 11;
                                }
                                //senao
                                else {
                                    //anda so
                                    _servData._sharedMem->_tabuleiro[i][j] = 0;
                                    _servData._sharedMem->_tabuleiro[i][j - 1] = 2;
                                }
                            }
                            
                            ReleaseMutex(_servData._hMutex);
                            //sinaliza evento que come�a o envio do tabuleiro para o sapo
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }

                        _carroAndouImpar = 1;
                    }
                }
            }
        }


        //GENERATE CARS
        int i = (rand() % (_servData._sharedMem->_nLinhasAtual - 3)) + 1;

        WaitForSingleObject(_servData._hMutex, INFINITE);
        if (i % 2 == 0) { //se for par
            if (_servData._sharedMem->_tabuleiro[i][0] == 0) { //se a primeira casa estiver vazia
                _servData._sharedMem->_tabuleiro[i][0] = 1; //coloca carro na primeira casa
                PulseEvent(_servData._hSendTabSapoEvent);
            }
            if (_servData._sharedMem->_tabuleiro[i][0] == 10) //se a primeira casa tiver o sapo1
            {
                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][0] = 10;//sapo pro inicio
                _servData._sharedMem->_tabuleiro[i][0] = 1; //coloca carro na primeira casa
                PulseEvent(_servData._hSendTabSapoEvent);
            }
            if (_servData._sharedMem->_tabuleiro[i][0] == 11)//se a primeira casa tiver o sapo2
            {
                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][0] = 11;//sapo pro inicio
                _servData._sharedMem->_tabuleiro[i][0] = 1; //coloca carro na primeira casa
                PulseEvent(_servData._hSendTabSapoEvent);
            }
        }
        else {//se for impar
            if (_servData._sharedMem->_tabuleiro[i][_servData._sharedMem->_nColunasAtual - 1] == 0) { //se a ultima casa estiver vazia
                _servData._sharedMem->_tabuleiro[i][_servData._sharedMem->_nColunasAtual - 1] = 2; //coloca carro na ultima casa
                PulseEvent(_servData._hSendTabSapoEvent);
            }
            if (_servData._sharedMem->_tabuleiro[i][_servData._sharedMem->_nColunasAtual - 1] == 10) {
                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][_servData._sharedMem->_nColunasAtual] = 10;
                _servData._sharedMem->_tabuleiro[i][_servData._sharedMem->_nColunasAtual - 1] = 2; //coloca carro na ultima casa
                PulseEvent(_servData._hSendTabSapoEvent);
            }
            if (_servData._sharedMem->_tabuleiro[i][_servData._sharedMem->_nColunasAtual - 1] == 11) {
                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][_servData._sharedMem->_nColunasAtual] = 11;
                _servData._sharedMem->_tabuleiro[i][_servData._sharedMem->_nColunasAtual - 1] = 2; //coloca carro na ultima casa
                PulseEvent(_servData._hSendTabSapoEvent);
            }
        }
        ReleaseMutex(_servData._hMutex);
        Sleep((_servData._sharedMem->_gameSpeed) * 100);

    }


    return 1;
}

DWORD WINAPI _ReceiveFromSapo(LPVOID lpParam) {
    SERVER_DATA _servData = *(SERVER_DATA*)lpParam;
    _tprintf(_T("\n(SERVER) -> (RECEIVE FROM SAPO) THREAD INITIATED"));

    _tprintf(_T("\n(SERVER) -> (RECEIVE FROM SAPO) WAITING FOR SAPO"));
    if (ConnectNamedPipe(_servData._hPipeSapoServ, NULL)) {
        _tprintf(_T("\n(SERVER) -> (RECEIVE FROM SAPO) SAPO CONNECTED"));

        //le quantos jogadores o sapo escolheu
        ReadFile(_servData._hPipeSapoServ, &_servData._comsWithSapo._command, sizeof(DWORD), &_servData._comsWithSapo._numberOfBytes, NULL);

        _tprintf(_T("\n(SERVER) -> (RECEIVE FROM SAPO) SAPO MESSAGE RECEIVED (%u)"), _servData._comsWithSapo._command);
        _servData._sapoCount = _servData._comsWithSapo._command;
        WaitForSingleObject(_servData._hMutex, INFINITE);
        _servData._sharedMem->_sapoCount = _servData._sapoCount;
        ReleaseMutex(_servData._hMutex);
        //resume threads de correr o jogo e mandar info pro sapo
        ResumeThread(_servData._sendSapoThreadHandle);
        ResumeThread(_servData._runGameThreadHandle);

        while (WaitForSingleObject(_servData._hExitEventServer, 0) == WAIT_TIMEOUT) {
            //em loop espera comandos do sapo para movimentar o sapo.
            ReadFile(_servData._hPipeSapoServ, &_servData._comsWithSapo._command, sizeof(DWORD), &_servData._comsWithSapo._numberOfBytes, NULL);
            _tprintf(_T("\n(SERVER) -> (RECEIVE FROM SAPO) SAPO COMMMAND RECEIVED (%u)"), _servData._comsWithSapo._command);
            //quando recebe comando ativa esta fun��o e manda esse comando
            _dealWithCommandsFromSapo(_servData);

        }

    }
}

DWORD WINAPI _SendToSapo(LPVOID lpParam) {
    SERVER_DATA _servData = *(SERVER_DATA*)lpParam;
    _tprintf(_T("\n(SERVER) -> (SEND TO SAPO) THREAD INITIATED"));

    _servData._hSendTabSapoEvent = CreateEvent(NULL, TRUE, FALSE, SEND_TAB_TO_SAPO_EVENT_NAME);
    if (_servData._hSendTabSapoEvent != NULL) {
        _tprintf(_T("\n(SERVER -> SEND TO SAPO) CREATED SEND EVENT SUCCESSFULLY"));
    }
    else {
        _tprintf(_T("\n(SERVER -> SEND TO SAPO) SEND EVENT CREATION FAILED"));
        SetEvent(_servData._hExitEventServer);
        return 1;
    }
    _servData._comsWithSapo._exitFlag = 0;
    //enquanto server nao desligar
    while (WaitForSingleObject(_servData._hExitEventServer, 0) == WAIT_TIMEOUT) {
        //espera pelo evento que transmite que pode enviar o tabuleiro para o sapo
        WaitForSingleObject(_servData._hSendTabSapoEvent, INFINITE);
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 20; j++) {
                _servData._comsWithSapo._tabuleiro[i][j] = _servData._sharedMem->_tabuleiro[i][j];
            }
        }
        ReleaseMutex(_servData._hMutex);
        //envia o tabuleiro
        BOOL isSuccess = WriteFile(
            _servData._hPipeServSapo,
            &_servData._comsWithSapo,
            sizeof(PIPE_COM_STRUCT),
            NULL,
            NULL
        );
    }
    //se o servidor desligar
    _servData._comsWithSapo._exitFlag = 1;
    BOOL isSuccess = WriteFile(
        _servData._hPipeServSapo,
        &_servData._comsWithSapo,
        sizeof(PIPE_COM_STRUCT),
        NULL,
        NULL
    );
}


DWORD _dealWithCommandsFromSapo(SERVER_DATA _servData) {
    //se receber up arrow key
    if (_servData._comsWithSapo._command == 1) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o sapo 1
                if (_servData._sharedMem->_tabuleiro[i][j] == 10) {
                    //se o sapo nao estiver na primeira linha
                    if (i != 0) {
                        //se a casa para onde vai andar nao tem nada
                        if (_servData._sharedMem->_tabuleiro[i - 1][j] == 0) {
                            //anda
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i - 1][j] = 10;
                        }
                        //se a casa para onde vai andar tem alguma coisa
                        else {
                            //e se essa coisa nao for o outro sapo
                            if (_servData._sharedMem->_tabuleiro[i - 1][j] != 11) {
                                //quer dizer que essa coisa era um obstaculo ou um carro por isso sapo volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 10;
                            }
                        }
                    }
                    //se o sapo estiver na primeira linha
                    else {
                        //gg ganhou e volta ao inicio
                        _servData._sharedMem->_tabuleiro[i][j] = 0;
                        _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual-1][j] = 10;

                    }
                }
            }
        }
        

        ReleaseMutex(_servData._hMutex);
        PulseEvent(_servData._hSendTabSapoEvent);
    }



    //se receber right arrow key
    if (_servData._comsWithSapo._command == 2) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o sapo 1
                if (_servData._sharedMem->_tabuleiro[i][j] == 10) {
                    //se o sapo nao estiver na ultima coluna
                    if (j != _servData._sharedMem->_nColunasAtual - 1) {
                        //e se para onde ele vai andar estiver vazio
                        if (_servData._sharedMem->_tabuleiro[i][j + 1] == 0) {
                            //anda
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i][j + 1] = 10;
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        //se nao estiver vazio
                        else {
                            //se nao for o outro sapo
                            if (_servData._sharedMem->_tabuleiro[i][j + 1] != 11) {
                                //quer dizer que � um obstaculo ou carro e volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual-1][j] = 10;
                                PulseEvent(_servData._hSendTabSapoEvent);
                            }
                        }
                    }
                }
            }
        }
        ReleaseMutex(_servData._hMutex);
    }
    //se receber left arrow key
    if (_servData._comsWithSapo._command == 3) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o sapo 1
                if (_servData._sharedMem->_tabuleiro[i][j] == 10) {
                    //se nao for a primeira coluna
                    if (j != 0) {
                        //se para onde vai andar n tem nada
                        if (_servData._sharedMem->_tabuleiro[i][j - 1] == 0)
                            //anda
                        {
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i][j - 1] = 10;
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        //senao
                        else {
                            //se nao for o outro sapo
                            if (_servData._sharedMem->_tabuleiro[i][j - 1] != 11) {
                                //e um obstaculo ou carro e volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 10;
                                PulseEvent(_servData._hSendTabSapoEvent);
                            }
                        }
                    }
                }
            }
        }
        ReleaseMutex(_servData._hMutex);
    }

    //se receber down arrow key
    if (_servData._comsWithSapo._command == 4) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o sapo 1
                if (_servData._sharedMem->_tabuleiro[i][j] == 10) {
                    //se nao for a ultima linha
                    if (i != _servData._sharedMem->_nLinhasAtual - 1) {
                        //se a casa para onde vai andar estiver vazia
                        if(_servData._sharedMem->_tabuleiro[i + 1][j]==0)
                        {
                            //anda
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i + 1][j] = 10;
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        else {
                            //se a casa para onde vai andar estiver ocupada e nao for o outro sapo
                            if (_servData._sharedMem->_tabuleiro[i + 1][j] != 11) {
                                //e um obstaculo ou carro e volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 10;
                                PulseEvent(_servData._hSendTabSapoEvent);
                            }
                        }
                    }
                }
            }
        }
        ReleaseMutex(_servData._hMutex);
    }

    //se receber W
    if (_servData._comsWithSapo._command == 10) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o sapo 2
                if (_servData._sharedMem->_tabuleiro[i][j] == 11) {
                    //se nao for a primeira linha
                    if (i != 0) {
                        //se a casa para onde vai andar estiver vazia
                        if (_servData._sharedMem->_tabuleiro[i - 1][j] == 0)
                        {
                            //anda
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i - 1][j] = 11;
                        }
                        //senao
                        else {
                            //se a casa para onde vai andar n for o outro sapo e estiver ocupada
                            if (_servData._sharedMem->_tabuleiro[i - 1][j] != 10) {
                                //volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 11;
                            }
                        }
                    }
                    //se for a primeira linha
                    else {
                        //gg ganhou e volta ao inicio
                        _servData._sharedMem->_tabuleiro[i][j] = 0;
                        _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 11;

                    }
                }
            }
        }
        ReleaseMutex(_servData._hMutex);
        PulseEvent(_servData._hSendTabSapoEvent);
    }


    //se receber D
    if (_servData._comsWithSapo._command == 11) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o segundo sapo
                if (_servData._sharedMem->_tabuleiro[i][j] == 11) {
                    //se nao estiver na ultima coluna
                    if (j != _servData._sharedMem->_nColunasAtual - 1) {
                        //se para onde vai andar esta vazio
                        if (_servData._sharedMem->_tabuleiro[i][j + 1] == 0)
                        {
                            //anda
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i][j + 1] = 11;
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        //senao
                        else {
                            //se estiver ocupada e nao for o outro sapo
                            if (_servData._sharedMem->_tabuleiro[i][j + 1] != 10) {
                                //volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 11;
                                PulseEvent(_servData._hSendTabSapoEvent);
                            }
                        }
                    }
                }
            }
        }
        ReleaseMutex(_servData._hMutex);
    }
    //se receber A
    if (_servData._comsWithSapo._command == 12) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o sapo 2
                if (_servData._sharedMem->_tabuleiro[i][j] == 11) {
                    //se nao � a primeira coluna
                    if (j != 0) {
                        //se a casa para onde vai anda esta vazia
                        if (_servData._sharedMem->_tabuleiro[i][j - 1] == 0)
                        {
                            //anda
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i][j - 1] = 11;
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        //senao
                        else {
                            //se nao for o outro sapo
                            if (_servData._sharedMem->_tabuleiro[i][j - 1] != 10) {
                                //volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 11;
                                PulseEvent(_servData._hSendTabSapoEvent);
                            }
                        }
                    }
                }
            }
        }
        ReleaseMutex(_servData._hMutex);
    }
    //se receber S
    if (_servData._comsWithSapo._command == 13) {
        WaitForSingleObject(_servData._hMutex, INFINITE);
        for (int i = 0; i < _servData._sharedMem->_nLinhasAtual; i++) {
            for (int j = 0; j < _servData._sharedMem->_nColunasAtual; j++) {
                //se for o sapo 2
                if (_servData._sharedMem->_tabuleiro[i][j] == 11) {
                    //se nao for a ultima linha
                    if (i != _servData._sharedMem->_nLinhasAtual - 1) {
                        //se a casa para onde vai andar esta vazia
                        if (_servData._sharedMem->_tabuleiro[i + 1][j] == 0) 
                        {
                            //anda
                            _servData._sharedMem->_tabuleiro[i][j] = 0;
                            _servData._sharedMem->_tabuleiro[i + 1][j] = 11;
                            PulseEvent(_servData._hSendTabSapoEvent);
                        }
                        //senao
                        else {
                            //se nao for o outro sapo
                            if (_servData._sharedMem->_tabuleiro[i + 1][j] != 10) {
                                //volta ao inicio
                                _servData._sharedMem->_tabuleiro[i][j] = 0;
                                _servData._sharedMem->_tabuleiro[_servData._sharedMem->_nLinhasAtual - 1][j] = 11;
                                PulseEvent(_servData._hSendTabSapoEvent);
                            }
                        }
                    }
                }
            }
        }
        ReleaseMutex(_servData._hMutex);
    }

    //se receber 100
    if (_servData._comsWithSapo._command == 100) {
        _tprintf(_T("\n(SERVER -> RECEIVE COMMAND FROM SAPO) SAPO SAIU"));

        TerminateThread(_servData._recieveFromSapoThreadHandle, NULL);
        TerminateThread(_servData._sendSapoThreadHandle, NULL);
        TerminateThread(_servData._runGameThreadHandle, NULL);
        _servData._runGameThreadHandle = CreateThread(NULL, 0, _RunGame, (LPVOID)(&_servData), CREATE_SUSPENDED, NULL);
        _servData._recieveFromSapoThreadHandle = CreateThread(NULL, 0, _ReceiveFromSapo, (LPVOID)(&_servData), 0, NULL);
        _servData._sendSapoThreadHandle = CreateThread(NULL, 0, _SendToSapo, (LPVOID)(&_servData), CREATE_SUSPENDED, NULL);
    }
}



DWORD WINAPI _waitForOperators(LPVOID lpParam) {
    SERVER_DATA _servData = *(SERVER_DATA*)lpParam;
    _servData._opCount = 0;
    //CREATE WAIT FOR OPERATORS EVENT
    HANDLE _hEventWaitForOperators = CreateEvent(NULL, TRUE, FALSE, WAIT_FOR_OPERATORS_EVENT_NAME);
    //WAIT FOR OPERATOR EVENT SUCCESS
    if (_hEventWaitForOperators == NULL) {
        _tprintf(_T("\n(SERVER -> WAIT FOR OPERATORS) FAILED TO CREATE WAIT FOR OPERATORS EVENT"));
        SetEvent(_servData._hExitEventServer);
        return 1;
    }
    //WAIT FOR OPERATOR EVENT FAIL
    else {
        _tprintf(_T("\n(SERVER -> WAIT FOR OPERATORS) WAIT FOR OPERATORS EVENT CREATE SUCCESS"));

    }
    _tprintf(_T("\n(SERVER -> WAIT FOR OPERATORS) WAITTING FOR OPERATORS..."));
    //ENQUANTO EXIT NAO SINALADO
    while (WaitForSingleObject(_servData._hExitEventServer, 0) == WAIT_TIMEOUT) {
        //WAIT FOR OPERATOR
        WaitForSingleObject(_hEventWaitForOperators, INFINITE);
        _tprintf(_T("\n(SERVER -> WAIT FOR OPERATORS) OPERATOR LOOGED IN!"));
        (_servData._opCount)++;
        //SE ENTRA O PRIMEIRO OPERADOR
        if (_servData._opCount == 1) {
            //ABRE CLOSE OPERATOR EVENT

            _servData._hExitEventOperator = OpenEvent(EVENT_ALL_ACCESS, FALSE, EXIT_EVENT_OPERATOR_NAME);
            if (GetLastError() == ERROR_FILE_NOT_FOUND) {
                _tprintf(_T("\n(SERVER MAIN) NO OPERTOR RUNNING\n"));
                return 1;
            }
            if (_servData._hExitEventOperator != NULL) {
                _tprintf(_T("\n(OPERATOR MAIN) OPERATOR RUNNING\n"));
            }
            else {
                _tprintf(_T("\n(OPERATOR MAIN) FAILED TO OPEN EXIT FOR OPERATOR EVENT\n"));
                return 1;
            }
        }

    }

    CloseHandle(_hEventWaitForOperators);
    ExitThread(0);
}

DWORD _dealWithCommandRecieved(SERVER_DATA _servData) {
    if (_servData._command == TEXT('e')) {//exit command
        _tprintf(_T("\n(SERVER -> DEAL WITH COMMANDS) OPERADOR SAIU\n"));
        if (_servData._opCount == 0) {
            CloseHandle(_servData._hExitEventOperator);
        }
        else {
            ResetEvent(_servData._hExitEventOperator);
        }
        return 0;
    }
    if (_servData._command == TEXT('s')) {//speed command
        if (_servData._valCommand1 > 30) {
            _servData._valCommand1 = 30;
        }
        if (_servData._valCommand1 < 1) {
            _servData._valCommand1 = 1;
        }
        WaitForSingleObject(_servData._hMutex, INFINITE);
        _servData._sharedMem->_gameSpeed = _servData._valCommand1;
        _tprintf(_T("(SERVER -> DEAL WITH COMMANDS) SPEED CHANGED TO %d\n"), _servData._valCommand1);
        ReleaseMutex(_servData._hMutex);
        return 0;

    }
    if (_servData._command == _T('l')) {//linhas command
        if (_servData._valCommand1 > 10) {
            _servData._valCommand1 = 10;
        }
        if (_servData._valCommand1 < 3) {
            _servData._valCommand1 = 3;
        }
        WaitForSingleObject(_servData._hMutex, INFINITE);
        _servData._sharedMem->_nLinhasAtual = _servData._valCommand1;
        _tprintf(_T("(SERVER -> DEAL WITH COMMANDS) NUMBER OF LINES CHANGED TO %d\n"), _servData._valCommand1);
        ReleaseMutex(_servData._hMutex);
        return 0;

    }
    if (_servData._command==_T('c')) {//collumns command
        if (_servData._valCommand1 > 20) {
            _servData._valCommand1 = 20;
        }
        if (_servData._valCommand1 < 2) {
            _servData._valCommand1 = 2;
        }
        WaitForSingleObject(_servData._hMutex, INFINITE);
        _servData._sharedMem->_nColunasAtual = _servData._valCommand1;
        _tprintf(_T("(SERVER -> DEAL WITH COMMANDS) NUMBER OF COLUMNS CHANGED TO %d\n"), _servData._valCommand1);
        ReleaseMutex(_servData._hMutex);
        return 0;
    }
    if (_servData._command == _T('o')) {//obstacle command
        if(_servData._valCommand1 < 0) { _servData._valCommand1 = 1; }
        if(_servData._valCommand1 > 10) { _servData._valCommand1 = 10; }
        if (_servData._valCommand2 < 0) { _servData._valCommand2 = 1; }
        if (_servData._valCommand2 > 19) { _servData._valCommand2 = 19; }
        WaitForSingleObject(_servData._hMutex, INFINITE);

        _servData._sharedMem->_tabuleiro[_servData._valCommand1][_servData._valCommand2] = 30;
        _tprintf(_T("(SERVER -> DEAL WITH COMMANDS) BLOCK PLACED IN LINE - %d / COLUMN - %d\n"), _servData._valCommand1,_servData._valCommand2);

        ReleaseMutex(_servData._hMutex);

        PulseEvent(_servData._hSendTabSapoEvent);
    }
    
    return 1;
}

DWORD WINAPI _WaitForCommands(LPVOID lpParam) {
    SERVER_DATA _servData = *(SERVER_DATA*)lpParam;
    //CREATE WRITE SEMAPHORE
    HANDLE _hSemWrite = CreateSemaphore(NULL, 10, 10, SEMAPHORE_COMMAND_WRITE_NAME);
    if (_hSemWrite == NULL) {
        _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) FAILED TO CREATE COMMAND WRITE SEMAPHORE"));
        SetEvent(_servData._hExitEventServer);
        CloseHandle(_servData._hExitEventServer);
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) COMMAND WRITE SEMAPHORE CREATED SUCCESSFULLY"));
    }
    //CREATE READ SEMAPHORE
    HANDLE _hSemRead = CreateSemaphore(NULL, 0, 10, SEMAPHORE_COMMAND_READ_NAME);
    if (_hSemRead == NULL) {
        _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) FAILED TO CREATE COMMAND READ SEMAPHORE"));
        SetEvent(_servData._hExitEventServer);
        CloseHandle(_servData._hExitEventServer);
        CloseHandle(_hSemWrite);
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) COMMAND READ SEMAPHORE CREATED SUCCESSFULLY"));
    }
    
    _servData._sharedMem->_ReadIndex = 0;
    _servData._sharedMem->_WriteIndex = 0;


    //BUFFER CIRCULAR FOR COMMANDS
    while (WaitForSingleObject(_servData._hExitEventServer, 0) == WAIT_TIMEOUT) {
        _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) WAITTING FOR COMMAND..."));
        WaitForSingleObject(_hSemRead, INFINITE);
        WaitForSingleObject(_servData._hMutex, INFINITE);
        _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) COMMAND RECEIVED!"));
        _servData._command = _servData._sharedMem->_CommandsBuffer[_servData._sharedMem->_ReadIndex];
        _servData._valCommand1 = _servData._sharedMem->_ValBuffer1[_servData._sharedMem->_ReadIndex];
        _servData._valCommand2 = _servData._sharedMem->_ValBuffer2[_servData._sharedMem->_ReadIndex];


        //_tcscpy_s(_servData._command,sizeof(_servData._sharedMem->_CommandsBuffer[_servData._sharedMem->_ReadIndex]), _servData._sharedMem->_CommandsBuffer[_servData._sharedMem->_ReadIndex]);
        //_servData._valCommand1 = _servData._sharedMem->_ValBuffer1[_servData._sharedMem->_ReadIndex];
        //_servData._valCommand2 = _servData._sharedMem->_ValBuffer2[_servData._sharedMem->_ReadIndex];
        _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) COMANDO RECEBIDO: (%c) (%d) (%d)"), _servData._command,_servData._valCommand1,_servData._valCommand2);
        _servData._sharedMem->_ReadIndex = (_servData._sharedMem->_ReadIndex + 1) % 10;
        ReleaseMutex(_servData._hMutex);
        ReleaseSemaphore(_hSemWrite, 1, NULL);
        if (_dealWithCommandRecieved(_servData) == 0) {
            _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) COMMAND PROCESSED SUCCESSFULLY!"));
        }
        else {
            _tprintf(_T("\n(SERVER -> WAIT FOR COMMANDS) COMMAND NOT PROCESSED!"));
        }
        
    }

   
    CloseHandle(_hSemRead);
    CloseHandle(_hSemWrite);
    return 0;

}

REG_DATA init_registry_data(REG_DATA reg_data) {
    //ABRIR A CHAVE
    HKEY chave;
    DWORD estado;
    LSTATUS res = RegOpenKeyEx(HKEY_CURRENT_USER, _T("Software\\AULA\\SO2\\TP"), 0, KEY_ALL_ACCESS, &chave);
    if (res == ERROR_SUCCESS) {
        //SUCCESS
        _tprintf(_T("\n(SERVER -> REGISTRY INITIALIZATION) OPENED KEY\n"));
    }
    else {
        //FAIL
        //CRIAR A CHAVE
        _tprintf(_T("\n(SERVER -> REGISTRY INITIALIZATION) COULD NOT OPEN KEY\n"));
        res = RegCreateKeyEx(HKEY_CURRENT_USER,
            _T("Software\\AULA\\SO2\\TP"),
            0,
            NULL,
            REG_OPTION_NON_VOLATILE,
            KEY_ALL_ACCESS,
            NULL,
            &chave,
            &estado);
        if (res == ERROR_SUCCESS) {
            //SUCCESS
            _tprintf_s(_T("(SERVER -> REGISTRY INITIALIZATION) CREATED KEY!\n"));
        }
        else {
            //FAIL
            _tprintf_s(_T("(SERVER -> REGISTRY INITIALIZATION) COULD NOT CREATE KEY (ERROR)\n"));
            reg_data.res = 1;
            return reg_data;
        }
    }
    DWORD type;
    DWORD init_LINES = 0;
    DWORD size = sizeof(DWORD);
    res = RegQueryValueEx(chave, _T("INIT_LINES"), NULL, &type, (LPBYTE)&init_LINES, &size);
    if (res != ERROR_SUCCESS) {
        _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) QUERY INIT VALUE OF LINES TO REGISTRY FAILED (WARNING)\n"));
        do {
            _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) DEFINE VALUE FOR INITIAL LINES:\n"));
            fflush(stdin);
            _tscanf_s(_T("%d"), &init_LINES);
        } while (init_LINES <= 0 || init_LINES > 10);

        res = RegSetValueEx(chave, _T("INIT_LINES"), 0, REG_DWORD, (const BYTE*)&init_LINES, sizeof(DWORD));

        if (res != ERROR_SUCCESS) {
            _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) ERROR ASSIGNING VALUE TO KEY (ERROR)\n"));
            reg_data.res = 1;
            return reg_data;
        }
        else {
            _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) VALUE ASSIGNED TO KEY SUCCESSFULLY\n"));
        }
    }
    else {
        _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) QUERY INIT VALUE OF LINES TO REGISTRY SUCCESS\n"));
    }
    DWORD init_COLUMNS = 0;
    res = RegQueryValueEx(chave, _T("INIT_COLLUMNS"), NULL, &type, (LPBYTE)&init_COLUMNS, &size);
    if (res != ERROR_SUCCESS) {
        _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) QUERY INIT VALUE OF COLUMNS TO REGISTRY FAILED (WARNING)\n"));
        do {
            _tprintf(_T("SERVER->REGISTRY INITIALIZATION) DEFINE VALUE FOR INITIAL COLUMNS : \n"));
            fflush(stdin);
            _tscanf_s(_T("%d"), &init_COLUMNS);
        } while (init_COLUMNS <= 0 || init_COLUMNS > 20);
        res = RegSetValueEx(chave, _T("INIT_COLLUMNS"), 0, REG_DWORD, (const BYTE*)&init_COLUMNS, sizeof(DWORD));
        if (res != ERROR_SUCCESS) {
            _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) ERROR ASSIGNING VALUE TO KEY (ERROR)\n"));
            reg_data.res = 1;
            return reg_data;
        }
        else {
            _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) VALUE ASSIGNED TO KEY SUCCESSFULLY\n"));
        }
    }
    else {
        _tprintf(_T("(SERVER -> REGISTRY INITIALIZATION) QUERY INIT VALUE OF COLUMNS TO REGISTRY SUCCESS\n"));
    }
    reg_data.chave = chave;
    reg_data.colunas = init_COLUMNS;
    reg_data.linhas = init_LINES;
    reg_data.res = 0;
    return(reg_data);
}


int _tmain(int argc, TCHAR* argv[]) {


#ifdef UNICODE
    _setmode(_fileno(stdin), _O_WTEXT);
    _setmode(_fileno(stdout), _O_WTEXT);
    _setmode(_fileno(stderr), _O_WTEXT);
#endif

    SERVER_DATA _serverData;

    //SERVER RUNNING? 
    _serverData._hExitEventServer = OpenEvent(EVENT_ALL_ACCESS, FALSE, EXIT_EVENT_SERVER_NAME);
    if (_serverData._hExitEventServer != NULL)
    {
        _tprintf(_T("\n(SERVER MAIN) ANOTHER SERVER ALREADY RUNNING"));
        return 1;
    }

    //INIT EXIT EVENT
    _serverData._hExitEventServer = CreateEvent(NULL, TRUE, FALSE, EXIT_EVENT_SERVER_NAME);
    if (_serverData._hExitEventServer != NULL) {
        _tprintf(_T("\n(SERVER MAIN) CREATED EXIT EVENT SUCCESSFULLY"));
    }
    else {
        _tprintf(_T("\n(SERVER MAIN) EXIT EVENT CREATION FAILED"));
        return 1;
    }

    //INIT REGISTRY
    REG_DATA _regData = { NULL,0,0,0 };
    _regData = init_registry_data(_regData);
    if (_regData.res == 0) {
        _tprintf(_T("(SERVER MAIN) REGISTRY INITIALIZED SUCCESSFULLY\n"));
    }
    else {
        _tprintf(_T("(SERVER MAIN) REGISTRY FAILED TO INITIALIZE\n"));
        CloseHandle(_serverData._hExitEventServer);
        ExitProcess(1);
    }
    
    //INIT SHARED MEM
    HANDLE _hMapFileCommands = CreateFileMapping(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        sizeof(SH_MEM),
        SHARED_MEMORY_NAME
    );
    if (_hMapFileCommands == NULL) {
        _tprintf(_T("\n(SERVER MAIN) COULD NOT MAP SHARED MEMORY"));
        SetEvent(_serverData._hExitEventServer);
        CloseHandle(_serverData._hExitEventServer);
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER MAIN) CREATED FILE MAPPING OF SHARED MEMORY"));
    }
    //map shared mem
    LPVOID lpMapAddress = MapViewOfFile(
        _hMapFileCommands,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        sizeof(SH_MEM));
    if (lpMapAddress == NULL) {
        _tprintf(_T("\n(SERVER MAIN) COULD NOT MAP ADDRESS OF SHARED MEMORY"));
        SetEvent(_serverData._hExitEventServer);
        CloseHandle(_serverData._hExitEventServer);
        CloseHandle(_hMapFileCommands);
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER MAIN) MAPPED ADDRESS FOR SHARED MEM"));
    }
    //CAST DO PONTEIRO MEM PARTILHADA PARA PONTEIRO COMMANDS_STRUCT
    _serverData._sharedMem = (SH_MEM*)lpMapAddress;
    _serverData._sharedMem->_gameSpeed = 99;

   
    //CREATE SHARED MEM MUTEX
    _serverData._hMutex = CreateMutex(NULL, FALSE, MUTEX_SHARED_MEM_NAME);
    if (_serverData._hMutex == NULL) {
        _tprintf(_T("\n(SERVER MAIN) FAILED TO CREATE SHARED MEM MUTEX"));
        SetEvent(_serverData._hExitEventServer);
        CloseHandle(_serverData._hExitEventServer);
        UnmapViewOfFile(lpMapAddress);
        CloseHandle(_hMapFileCommands);
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER MAIN) SHARED MEM MUTEX CREATED SUCCESSFULLY"));
    }

    //PREENCHER LINHAS E COLUNAS ATUAL OBTIDAS DO REGISTRY
    _serverData._sharedMem->_nLinhasAtual = _regData.linhas;
    _serverData._sharedMem->_nColunasAtual = _regData.colunas;

    //ABRIR O PIPE PARA SEND COMandos dOS SAPOS
    _serverData._hPipeServSapo = CreateNamedPipe(
        _T("\\\\.\\pipe\\ComsWithSapo"),  // Pipe name
        PIPE_ACCESS_OUTBOUND,   // Write-only access
        PIPE_TYPE_BYTE | PIPE_READMODE_BYTE | PIPE_WAIT,  // Message type and mode
        PIPE_UNLIMITED_INSTANCES,  // Number of instances
        1,   // Output buffer size
        0,   // Input buffer size
        0,   // Default timeout
        NULL // Security attributes
    );
    if (_serverData._hPipeServSapo == INVALID_HANDLE_VALUE)
    {
        _tprintf(_T("\n(SERVER MAIN) FAILED TO CREATE NAMED PIPE 1"));
        SetEvent(_serverData._hExitEventServer);
        CloseHandle(_serverData._hExitEventServer);
        UnmapViewOfFile(lpMapAddress);
        CloseHandle(_hMapFileCommands);
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER MAIN) NAMED PIPE SEND CREATED SUCCESSFULLY"));
    }



    //ABRIR O PIPE PARA RECEIVE COMandos dOS SAPOS
    _serverData._hPipeSapoServ = CreateNamedPipe(
        _T("\\\\.\\pipe\\Coms2WithSapo"),  // Pipe name
        PIPE_ACCESS_INBOUND,   // Read-only access
        PIPE_READMODE_BYTE | PIPE_WAIT,  // Message mode
        PIPE_UNLIMITED_INSTANCES,  // Number of instances
        1,   // Output buffer size
        0,   // Input buffer size
        0,   // Default timeout
        NULL // Security attributes
    );
    if (_serverData._hPipeSapoServ == INVALID_HANDLE_VALUE)
    {
        _tprintf(_T("\n(SERVER MAIN) FAILED TO CREATE NAMED PIPE 2"));
        DisconnectNamedPipe(_serverData._hPipeServSapo);
        CloseHandle(_serverData._hPipeServSapo);
        SetEvent(_serverData._hExitEventServer);
        CloseHandle(_serverData._hExitEventServer);
        UnmapViewOfFile(lpMapAddress);
        CloseHandle(_hMapFileCommands);
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER MAIN) NAMED PIPE RECEIVE CREATED SUCCESSFULLY"));

    }
 
    //INIT THREADS
    HANDLE _hServerThreads[5];
    DWORD _ServerThreadIds[5];
    _hServerThreads[0] = CreateThread(NULL, 0, _waitForOperators, (LPVOID)(&_serverData), 0, &_ServerThreadIds[0]);
    _hServerThreads[1] = CreateThread(NULL, 0, _WaitForCommands, (LPVOID)(&_serverData), 0, &_ServerThreadIds[1]);
    _hServerThreads[2] = CreateThread(NULL, 0, _RunGame, (LPVOID)(&_serverData), CREATE_SUSPENDED, &_ServerThreadIds[2]);
    _hServerThreads[3] = CreateThread(NULL, 0, _ReceiveFromSapo, (LPVOID)(&_serverData), 0, &_ServerThreadIds[3]);
    _hServerThreads[4] = CreateThread(NULL, 0, _SendToSapo, (LPVOID)(&_serverData), CREATE_SUSPENDED, &_ServerThreadIds[4]);
    _serverData._sendSapoThreadHandle = _hServerThreads[4];
    _serverData._runGameThreadHandle = _hServerThreads[2];
    _serverData._recieveFromSapoThreadHandle = _hServerThreads[3];

    if (_hServerThreads[0] == NULL || _hServerThreads[1] == NULL || _hServerThreads[2] == NULL || _hServerThreads[3] == NULL || _hServerThreads[4] == NULL) {
        _tprintf(_T("\n(SERVER MAIN) ERROR CREATING THREADS"));
        return 1;
    }
    else {
        _tprintf(_T("\n(SERVER MAIN) THREADS CREATED SUCCESSFULLY"));
    }
    //WAIT FOR EXIT EVENT
    _tprintf(_T("\n(SERVER MAIN) WAITTING FOR EXIT EVENT SIGNAL"));

    

    //SE SERVIDOR FECHAR
    DWORD _CommandObtained = 0;
    _tscanf_s(_T("%d"), &_CommandObtained);
    if (_CommandObtained == 0) {
        SetEvent(_serverData._hExitEventServer);
        SetEvent(_serverData._hExitEventOperator);
        SetEvent(_serverData._hExitEventSapo);
        
    }
    CloseHandle(_serverData._hExitEventOperator);
    CloseHandle(_serverData._hExitEventServer);
    UnmapViewOfFile(lpMapAddress);
    CloseHandle(_hMapFileCommands);
    CloseHandle(_serverData._hMutex);
    DisconnectNamedPipe(_serverData._hPipeServSapo);
    CloseHandle(_serverData._hPipeServSapo);
    DisconnectNamedPipe(_serverData._hPipeSapoServ);
    CloseHandle(_serverData._hPipeSapoServ);

    return 0;
}
