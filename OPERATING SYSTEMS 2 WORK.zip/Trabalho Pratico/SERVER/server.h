#pragma once
#include <windows.h>
#include <string.h>
#include <tchar.h>
#include <io.h>
#include <fcntl.h>
#include <stdio.h>

#define EXIT_EVENT_SAPO_NAME _T("EXIT_EVENT_SAPO_NAME")
#define EXIT_EVENT_OPERATOR_NAME _T("EXIT_EVENT_OPERATOR_NAME")
#define EXIT_EVENT_SERVER_NAME _T("EXIT_EVENT_SERVER_NAME")
#define SEND_TAB_TO_SAPO_EVENT_NAME _T("SEND_TAB_TO_SAPO_EVENT_NAME")

#define SHARED_MEMORY_NAME _T("SHARED_MEMORY_NAME")
#define MUTEX_SHARED_MEM_NAME _T("MUTEX_SHARED_MEM_NAME")
#define WAIT_FOR_OPERATORS_EVENT_NAME _T("WAIT_FOR_OPERATORS_EVENT_NAME")
#define WAIT_FOR_SAPO_EVENT_NAME _T("WAIT_FOR_SAPO_EVENT_NAME")

#define SEMAPHORE_COMMAND_WRITE_NAME _T("SEMAPHORE_COMMAND_WRITE_NAME")
#define SEMAPHORE_COMMAND_READ_NAME _T("SEMAPHORE_COMMAND_READ_NAME")

typedef struct pipestruct {
    DWORD _tabuleiro[10][20];
    DWORD _sapo;
    DWORD _command;
    DWORD _numberOfBytes;
    DWORD _exitFlag;

}PIPE_COM_STRUCT;

typedef struct SH_MEM {
    DWORD _WriteIndex;
    DWORD _ReadIndex;
    TCHAR _CommandsBuffer[10];
    DWORD _ValBuffer1[10];
    DWORD _ValBuffer2[10];
    DWORD _tabuleiro[10][20];
    DWORD _nLinhasAtual;
    DWORD _nColunasAtual;
    DWORD _gameSpeed;
    DWORD _sapoCount;
}SH_MEM;

typedef struct SERVER_DATA {
    HANDLE _hExitEventOperator;
    HANDLE _hExitEventServer;
    HANDLE _hExitEventSapo;
    HANDLE _hSendTabSapoEvent;
    HANDLE _hMutex;
    SH_MEM* _sharedMem;
    TCHAR _command;
    DWORD _valCommand1;
    DWORD _valCommand2;
    DWORD _opCount;
    DWORD _sapoCount;
    HANDLE _hPipeServSapo;
    HANDLE _hPipeSapoServ;
    HANDLE _recieveFromSapoThreadHandle;
    HANDLE _sendSapoThreadHandle;
    HANDLE _runGameThreadHandle;
    PIPE_COM_STRUCT _comsWithSapo;
}SERVER_DATA;


typedef struct registry_data {
    HKEY chave;
    DWORD colunas;
    DWORD linhas;
    DWORD res;
}REG_DATA;

