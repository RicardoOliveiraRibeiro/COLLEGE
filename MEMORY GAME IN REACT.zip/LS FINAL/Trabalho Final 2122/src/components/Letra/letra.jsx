
import './letra.css'

function Letra(props){ //LETRA //POSICAO //SENTIDO
   
    let {
        keyParaDentro,
        texto,
        clicked,
        handleOnClick,
        posicao,
    } = props;

    return(
        <div id='leterPiece' className={clicked} onClick={()=>handleOnClick(keyParaDentro,posicao)}>
            <div className="leter">{texto}</div>
        </div>
    ) 
}

export default Letra;