import './header.css'
function Header(){
    
    return(
        <section className="header">
            <h1 className="title">SOPA DE LETRAS REACT</h1>  
            <h2 className="subtitle">Made by Ricardo Ribeiro, Ion Sacultan and Guilherme Lemos</h2>
            <h3 className="thirdtitle">Linguagens Script 21/22</h3>
        </section>
    ) 
}

export default Header;