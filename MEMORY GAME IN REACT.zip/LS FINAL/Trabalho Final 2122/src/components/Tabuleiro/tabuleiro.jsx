
import { useState } from 'react';
import Letra from '../Letra/letra'
import Palavra from '../Palavra/palavra';
import './tabuleiro.css'
function Tabuleiro(props){
    
    let {
        gameStarted,
       
        arrayTabuleiro,
        selectedLevel,
        palavrasSelecionadas,
        arrayChavesDeLetras,
        pontuacaoAtual,
        incrementaPontuacao
    } = props;

    let estilo='';
    if(selectedLevel==='0'){
        estilo="Default";
    }
    else if(selectedLevel==='1'){
        estilo="Noob";
    }
    else if(selectedLevel==='2'){
        estilo="Monkey";
    }
    else if(selectedLevel==='3'){
        estilo="Apocalipse";
    }

    const [position,setPosition]=useState(0);
    
    function letraClicada(keyRecebida, posicao){
        let letraPressed=arrayTabuleiro[posicao[1]][posicao[0]];
     


        letraPressed.clicked='pressed';

        if(position===0){
            setPosition(posicao);
            console.log("first leter");
        }
        else{
            console.log("second leter");
            let letra1=arrayTabuleiro[position[1]][position[0]];
            let letra2=arrayTabuleiro[posicao[1]][posicao[0]];
            console.log(letra1);
            console.log(letra2);
            console.log(arrayChavesDeLetras);
            
            let Xletra1=position[0]; console.log(Xletra1);
            let Yletra1=position[1]; console.log(Yletra1);
            let Xletra2=posicao[0]; console.log(Xletra2);
            let Yletra2=posicao[1]; console.log(Yletra2);

            for(let i=0;i<arrayChavesDeLetras.length;i=i+2){
                if(letra1.key===arrayChavesDeLetras[i].key){
                    if(letra2.key===arrayChavesDeLetras[i+1].key){
                        console.log("PALAVRA ENCONTRADA");
                        incrementaPontuacao(pontuacaoAtual);
                        console.log(palavrasSelecionadas);
                        for(let j=0;j<palavrasSelecionadas.length;j++){
                            if(palavrasSelecionadas[j].PosInicial===position){
                                if(palavrasSelecionadas[j].PosFinal===posicao){
                                    palavrasSelecionadas[j].found="found";
                                    break;
                                }
                            }
                        }

                        if(Xletra1<Xletra2){ //esquerda pra direita
                            if(Yletra1<Yletra2){ //cima pra baixo
                                let y=Yletra1;
                                for(let x=Xletra1;x<=Xletra2;x++){  
                                    arrayTabuleiro[y][x].clicked='found';
                                    y++;
                                }
                            }
                            if(Yletra1>Yletra2){ //baixo pra cima
                                let y=Yletra1;
                                for(let x=Xletra1;x<=Xletra2;x++){
                                    arrayTabuleiro[y][x].clicked='found';
                                    y--;
                                }
                            }
                            if(Yletra1===Yletra2){ // nao se mexe no eixo dos y
                                let y=Yletra1;
                                for(let x=Xletra1;x<=Xletra2;x++){
                                    arrayTabuleiro[y][x].clicked='found';
                                }
                            }
                        }

                        if(Xletra1>Xletra2){ //direita pra esquerda
                            if(Yletra1<Yletra2){ //cima pra baixo
                                let y=Yletra1;
                                for(let x=Xletra1;x>=Xletra2;x--){
                                    arrayTabuleiro[y][x].clicked='found';
                                    y++;
                                }
                            }
                            if(Yletra1>Yletra2){ //baixo pra cima
                                let y=Yletra1;
                                for(let x=Xletra1;x>=Xletra2;x--){
                                    arrayTabuleiro[y][x].clicked='found';
                                    y--;
                                }
                            }
                            if(Yletra1===Yletra2){ // nao se mexe no eixo dos y
                                let y=Yletra1;
                                for(let x=Xletra1;x>=Xletra2;x--){
                                    arrayTabuleiro[y][x].clicked='found';
                                }
                            }
                        }

                        if(Xletra1===Xletra2){ //nao se mexe no eixo dos x
                            if(Yletra1<Yletra2){ //cima pra baixo
                                let x=Xletra1;
                                for(let y=Yletra1;y<=Yletra2;y++){
                                    arrayTabuleiro[y][x].clicked='found';
                                }
                            }
                            if(Yletra1>Yletra2){ //baixo pra cima
                                let x=Xletra1;
                                for(let y=Yletra1;y>=Yletra2;y--){
                                    arrayTabuleiro[y][x].clicked='found';
                                }
                            }
                        }


                        setPosition(0);
                        return;

                    }
                }
            }
            letra1.clicked='';
            letra2.clicked='';
            console.log("PALAVRA NAO ENCONTRADA");
            setPosition(0);
            return;
        }
    } 
    return(
        <section className="tabuleiro">
        
        <div id="gamePanel"  className={gameStarted? "TRUE":"FALSE"}>

            <section id="words">
                {props.palavrasSelecionadas.map((palavra)=>{
    
                    return <Palavra
                    key={palavra.Key}
                    texto={palavra.Texto}
                    found={palavra.Found}
                    ></Palavra>
                })}
            </section>

        
            <section id="game" className={estilo}>
                {props.arrayTabuleiro.map((linha)=>{            
                    return linha.map((letra)=>{                
                        return(
                            <Letra
                                keyParaDentro={letra.key}
                                texto={letra.texto}
                                first={letra.first}
                                last={letra.last}
                                clicked={letra.clicked}
                                handleOnClick={letraClicada}
                                posicao={letra.pos}
                                found=''
                            ></Letra>
                        )
                    }) 
                })}
            </section>
        

            </div>
        </section>
    )
}

export default Tabuleiro;