
import './controlPanel.css'
import scores from '../../scores.txt'

function ControlPanel(props){
    
    function handleRefreshGame(){
        window.location.reload(true);
    }

    
    function showPontuacoes(){
        fetch(scores)
        .then(t => t.text()).then(text => {
            console.log(text)
            alert(text);
        })
    }
    
    return(

        

        <section className="controlPanel">
            <button type="button" className="ScoreFileButton" onClick={showPontuacoes}>SCORES</button>
            <button type="button" className="AddWord" onClick={props.onAddWord}>ADD WORD</button>
            <button type="button" className="refresh" onClick={handleRefreshGame}>RESTART GAME</button>
            <dd id="gameTime">TIME:  {props.timer}</dd>
            <label className="labelLevel" htmlFor="level">Level:</label>
            <select className="selectLevelDropDown" id="level" onChange={props.onSelectedLevel}>
                <option className="dropDown-default" defaultValue value="0">Select level...</option>
                <option className="dropDown-1" value="1">Noob (10x10)</option>
                <option className="dropDown-2" value="2">Monkey (20x20)</option>
                <option className="dropDown-3" value="3">Apocalipse (30x30)</option>
            </select>
            <button type="button" className="play" onClick={props.onGameStarted}>{props.gameStarted? "STOP" : "PLAY"}</button>
        
        </section>
    )
}
export default ControlPanel;