
import "./palavra.css"

function Palavra(props){ //LETRA //POSICAO //SENTIDO
   
    let {
        texto,
        found
    } = props;
    
    return(
        <div id="palavraPiece" className={found}>
            <div className="palavra">{texto}</div>
        </div>
    ) 
}

export default Palavra;