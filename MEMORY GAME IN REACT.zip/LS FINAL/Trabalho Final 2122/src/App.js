import './App.css';
import Header from './components/Titulo/header';
import Tabuleiro from './components/Tabuleiro/tabuleiro';
import ControlPanel from './components/ControlPanel/ControlPanel';
import { useState } from 'react';
import { useEffect } from 'react';
import scores from './scores.txt'

let TIMEOUTGAME=0;

function App(){

  

  function getRandomLeter(length) {
    let alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    return (alphabet.charAt(Math.floor(Math.random()*alphabet.length)));
  }

  function letraConstrutor(keyR,textoR,firstR,lastR,posR){
    return(
      {
        key:keyR+textoR+firstR+lastR+getRandomLeter(),
        texto:textoR,
        first:firstR,
        last:lastR,
        clicked:'',
        pos:posR
      }
    )
  }

  let palavra={
    texto:'',
    letraInicial:'',
    direcao:'',
    posicao:''
  };
  
  function palavraConstrutor(textoR,letraInicialR,direcaoR,posicaoR){
    return (
      palavra={
        texto:textoR,
        letraInicial:letraInicialR,
        direcao:direcaoR,
        posicao:posicaoR
      }
    )
  }

  const [gameStarted, setGameStarted] = useState(false);
  const [selectedLevel,setSelectedLevel] = useState('0');
  let EnciclopediaObjectos;
  const [arrayTabuleiroEstado,setArrayTabuleiroEstado]=useState([]);
  const [palavrasSelecionadas,setPalavrasSelecionadas]=useState([]);
  const [arrayChavesDeLetras,setArrayChavesDeLetras]=useState([]);
  const [pontuacaoAtual,setPontuacaoAtual]=useState(0);
  
  let ArrayTabuleiro=[];
  let TamTabuleiro=0;

  let Enciclopedia=["PALAVRAMUITOGRANDE","INJECT","OUTLOOK","HEART","LOAN","BOMB","SHEEP","ZONE","STOMACH","RELATED","PATENT","SOLVE","INTERACTIVE","COUSIN","STEPBRO","FEVER","AISLE","MOVING","TANK","UNIFORM","FRIEND","NODE","CALF","GOAT","SHOWER","ISEC","REACT","JAVA","ION","LETRA","RICARDO","LEMOS","SCRIPT","GUILHERME","SACULTAN","RIBEIRO"];

  

  function addWord(){
    Enciclopedia.push((prompt("Insira a Palavra:")).toUpperCase());
    
  }

  function getDirection() {
    let direction = '12345678';
    return (direction.charAt(Math.floor(Math.random()*direction.length)));
  }

  function geraPOS(selectedLevelTemp,dirTemp,palavraTemp){
    let LC=selectedLevelTemp*10 //+1 porque Math.random exclui ultimo valor
  
    let xreturn;
    let yreturn;

    if(dirTemp==='1'){ //ESQUERDA-DIREITA
      xreturn=Math.floor(Math.random()*((LC)-(palavraTemp.length)));
      yreturn=Math.floor(Math.random()*LC);
      //return_pos=(pos(Math.random()*((LC+1)-(palavraTemp.length)),Math.random()*LC));
    }
    if(dirTemp==='2'){ //DIREITA-ESQUERDA
      xreturn=Math.floor(Math.random() * (LC - (palavraTemp.length-1)) + (palavraTemp.length-1));
      yreturn=Math.floor(Math.random()*LC);
      //return_pos=(pos(Math.random() * (LC - ((palavraTemp.length)-1) + ((palavra.length)-1)),Math.random()*LC));
    }
    if(dirTemp==='3'){ //CIMA-BAIXO
      xreturn=Math.floor(Math.random()*LC);
      yreturn=Math.floor(Math.random()*(LC-(palavraTemp.length-1)));
      //return_pos=(pos(Math.random()*LC,Math.random()*(LC-(palavraTemp-1))));
    }
    if(dirTemp==='4'){ //BAIXO-CIMA
      xreturn=Math.floor(Math.random()*LC);
      yreturn=Math.floor(Math.random() * (LC - ((palavraTemp.length)-1)) + ((palavraTemp.length)-1));
      //return_pos=(pos(Math.random()*LC,Math.random() * (LC - ((palavraTemp.length)-1)) + ((palavraTemp.length)-1)));
    }
    if(dirTemp==='5'){ //ESQUERDA_DIREITA-CIMA-BAIXO
      xreturn=Math.floor(Math.random()*(LC-((palavraTemp.length)-1)));
      yreturn=Math.floor(Math.random()*(LC-((palavraTemp.length)-1)));
      //return_pos(pos(Math.random()*(LC-((palavraTemp.length)-1)),Math.random()*(LC-((palavraTemp.length)-1))));
    }
    if(dirTemp==='6'){ //DIRETA-ESQUERDA-CIMA-BAIXO
      xreturn=Math.floor(Math.random() * (LC - (palavraTemp.length-1)) + (palavraTemp.length-1));
      yreturn=Math.floor(Math.random()*(LC-((palavraTemp.length)-1)));
      //return_pos(pos(Math.random() * (LC - (palavraTemp-1)) + (palavraTemp-1),Math.random()*(LC-((palavraTemp.length)-1))));
    }
    if(dirTemp==='7'){ //DIREITA-ESQUERDA-BAIXO_CIMA
      xreturn=Math.floor(Math.random() * (LC - ((palavraTemp.length)-1)) + ((palavraTemp.length)-1));
      yreturn=Math.floor(Math.random() * (LC - ((palavraTemp.length)-1)) + ((palavraTemp.length)-1));
      //return_pos(pos(Math.random() * (LC - ((palavraTemp.length)-1)) + ((palavraTemp.length)-1),Math.random() * (LC - ((palavraTemp.length)-1)) + ((palavraTemp.length)-1)));
    }
    if(dirTemp==='8'){ //ESQUERDA-DIREITA-BAIXO-CIMA
      xreturn=Math.floor(Math.random()*(LC-((palavraTemp.length)-1)));
      yreturn=Math.floor(Math.random() * (LC - ((palavraTemp.length)-1)) + ((palavraTemp.length)-1));
      //return_pos(pos(Math.random()*(LC-((palavraTemp.length)-1)),Math.random() * (LC - ((palavraTemp)-1)) + ((palavraTemp)-1)));
    }
   
    let pos_return=[xreturn,yreturn];
   
    return(pos_return);
  }

  function geraArrayPalavrasObjetos(selectedLevelTemp){
    
    let tamEnciclopediaInicial=Enciclopedia.length;
    

    let n_palavras_grandes=0;
    for(let u=0;u<tamEnciclopediaInicial;u++){
      if(Enciclopedia[u].length>(selectedLevelTemp*10)){
        n_palavras_grandes++;
      }
    }

    let EnciclopediaObjectosTEMP=[];

    for(let i=0;i<(Enciclopedia.length-n_palavras_grandes);i++){
      EnciclopediaObjectosTEMP.push((palavra));
    }

    let directionTemp;
    let posTemp=[];

    let j=0;
    for(let i=0;i<Enciclopedia.length;i++){
      if(Enciclopedia[i].length<(selectedLevelTemp*10)){
        directionTemp=getDirection();
        posTemp=geraPOS(selectedLevelTemp,directionTemp,Enciclopedia[i]);
        EnciclopediaObjectosTEMP[j]=palavraConstrutor(Enciclopedia[i],Enciclopedia[i].charAt(0),directionTemp,posTemp);
        j++;
      }
      else{
      }
    }
    return EnciclopediaObjectosTEMP;
  }

  function verifySeWordPodeIrProTabuleiro(ArrayTabuleiro,PalavraAEntrarTemp){
    let i=0;
  

    if(((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]][PalavraAEntrarTemp.posicao[1]])===undefined) || (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]][PalavraAEntrarTemp.posicao[1]])===PalavraAEntrarTemp.letraInicial){ //se o tamanho do parametro que esta na posicao do tabuleiro for 0 ou seja nao esta la nada, ou se neste estiver uma letra igual a letra da palavra

      if(PalavraAEntrarTemp.direcao==='1'){ //ESQUERDA-DIREITA
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]+(i+1)][PalavraAEntrarTemp.posicao[1]]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]+(i+1)][PalavraAEntrarTemp.posicao[1]])!==undefined){

            return 0;
          }
        }
        return 1;
      }
      if(PalavraAEntrarTemp.direcao==='2'){ //DIREITA-ESQUERDA
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]-(i+1)][PalavraAEntrarTemp.posicao[1]]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]-(i+1)][PalavraAEntrarTemp.posicao[1]])!==undefined){
            
            return 0;
          }
        }
        return 1;
      }
      if(PalavraAEntrarTemp.direcao==='3'){ //CIMA-BAIXO
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]][PalavraAEntrarTemp.posicao[1]+(i+1)]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]][PalavraAEntrarTemp.posicao[1]+(i+1)])!==undefined){
           
            return 0;
          }
        }
        return 1;
      }
      if(PalavraAEntrarTemp.direcao==='4'){ //BAIXO-CIMA
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]][PalavraAEntrarTemp.posicao[1]-(i+1)]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]][PalavraAEntrarTemp.posicao[1]-(i+1)])!==undefined){
           
            return 0;
          }
        }
        return 1;
      }
      if(PalavraAEntrarTemp.direcao==='5'){ //ESQUERDA-DIREITA-CIMA-BAIXO
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]+(i+1)][PalavraAEntrarTemp.posicao[1]+(i+1)]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]+(i+1)][PalavraAEntrarTemp.posicao[1]+(i+1)])!==undefined){
           
            return 0;
          }
        }
        return 1;
      }
      if(PalavraAEntrarTemp.direcao==='6'){ //DIREITA-ESQUERDA-CIMA-BAIXO
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]-(i+1)][PalavraAEntrarTemp.posicao[1]+(i+1)]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]-(i+1)][PalavraAEntrarTemp.posicao[1]+(i+1)])!==undefined){
           
            return 0;
          }
        }
        return 1;
      }
      if(PalavraAEntrarTemp.direcao==='7'){ //DIREITA-ESQUERDA-BAIXO-CIMA
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]-(i+1)][PalavraAEntrarTemp.posicao[1]-(i+1)]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]-(i+1)][PalavraAEntrarTemp.posicao[1]-(i+1)])!==undefined){
           
            return 0;
          }
        }
        return 1;
      }
      if(PalavraAEntrarTemp.direcao==='8'){ //ESQUERDA-DIREITA-BAIXO-CIMA
        for(i=0;i<((PalavraAEntrarTemp.texto.length)-1);i++){
          if((ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]+(i+1)][PalavraAEntrarTemp.posicao[1]-(i+1)]!==(PalavraAEntrarTemp.texto).charAt(i+1)) && (ArrayTabuleiro[PalavraAEntrarTemp.posicao[0]+(i+1)][PalavraAEntrarTemp.posicao[1]-(i+1)])!==undefined){
          
            return 0;
          }
        }
        return 1;
      } 
    }
  }

  function InserePalavraNosTabuleiros(ArrayTabuleiroObjectos,ArrayTabuleiro,PalavraParaColocar){
    
    let firstLeter=0;
    let lastLeter=0;
    let keySFirstLast=arrayChavesDeLetras;
    let letraTemp;


      if(PalavraParaColocar.direcao==='1'){ //ESQUERDA-DIREITA
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1],PalavraParaColocar.posicao[0]+(i)]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]+(i)][PalavraParaColocar.posicao[1]]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]+(i)][PalavraParaColocar.posicao[1]] = letraTemp ;
          if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
         
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
      if(PalavraParaColocar.direcao==='2'){ //DIREITA-ESQUERDA
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1],PalavraParaColocar.posicao[0]-(i)]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]-(i)][PalavraParaColocar.posicao[1]]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]-(i)][PalavraParaColocar.posicao[1]] = letraTemp;
          if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
          
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
      if(PalavraParaColocar.direcao==='3'){ //CIMA-BAIXO
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1]+(i),PalavraParaColocar.posicao[0]]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]][PalavraParaColocar.posicao[1]+(i)]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]][PalavraParaColocar.posicao[1]+(i)] =letraTemp;
         if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
         
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
      if(PalavraParaColocar.direcao==='4'){ //BAIXO-CIMA
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1]-(i),PalavraParaColocar.posicao[0]]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]][PalavraParaColocar.posicao[1]-(i)]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]][PalavraParaColocar.posicao[1]-(i)] = letraTemp;
        if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
         
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
      if(PalavraParaColocar.direcao==='5'){ //ESQUERDA-DIREITA-CIMA-BAIXO
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1]+(i),PalavraParaColocar.posicao[0]+(i)]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]+(i)][PalavraParaColocar.posicao[1]+(i)]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]+(i)][PalavraParaColocar.posicao[1]+(i)] =letraTemp;
         if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
          
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
      if(PalavraParaColocar.direcao==='6'){ //DIREITA-ESQUERDA-CIMA-BAIXO
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1]+(i),PalavraParaColocar.posicao[0]-(i)]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]-(i)][PalavraParaColocar.posicao[1]+(i)]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]-(i)][PalavraParaColocar.posicao[1]+(i)] = letraTemp;
          if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
         
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
      if(PalavraParaColocar.direcao==='7'){ //DIREITA-ESQUERDA-BAIXO-CIMA
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1]-(i),PalavraParaColocar.posicao[0]-(i)]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]-(i)][PalavraParaColocar.posicao[1]-(i)]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]-(i)][PalavraParaColocar.posicao[1]-(i)] =letraTemp;
          if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
          
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
      if(PalavraParaColocar.direcao==='8'){ //ESQUERDA-DIREITA-BAIXO-CIMA
        for(let i=0;i<(PalavraParaColocar.texto.length);i++){
          if(i===0){firstLeter=1;}
          if(i===((PalavraParaColocar.texto.length)-1)){lastLeter=1;firstLeter=0;}
          letraTemp=new letraConstrutor(i+''+PalavraParaColocar.direcao+''+Math.random()*99999,PalavraParaColocar.texto.charAt(i),firstLeter,lastLeter,[PalavraParaColocar.posicao[1]-(i),PalavraParaColocar.posicao[0]+(i)]);
          ArrayTabuleiro[PalavraParaColocar.posicao[0]+(i)][PalavraParaColocar.posicao[1]-(i)]=PalavraParaColocar.texto.charAt(i);
          ArrayTabuleiroObjectos[PalavraParaColocar.posicao[0]+(i)][PalavraParaColocar.posicao[1]-(i)] = letraTemp;
          if(i===0){keySFirstLast.push(letraTemp);}
          if(i===((PalavraParaColocar.texto.length)-1)){keySFirstLast.push(letraTemp);}
         
        }
        setArrayChavesDeLetras(keySFirstLast);
      }
    
  }
  
  function PreencheEspacosVazios(value,ArrayTabuleiroObjectos){
    for(let i=0;i<value*10;i++){
      for(let j=0;j<value*10;j++){
        if(ArrayTabuleiroObjectos[i][j]===undefined){
          ArrayTabuleiroObjectos[i][j]=new letraConstrutor(getRandomLeter()+getRandomLeter()+j+i+''+Math.random()*9999,getRandomLeter(),0,0,[j,i]);
        }
      }
    }
    setArrayTabuleiroEstado(ArrayTabuleiroObjectos);
  }

  function InserePalavraNoArrayDePalavrasSelecionadas(Palavra){
   
 
    let PalavrasSelecionadasTemp=palavrasSelecionadas;

    let PosFinalTemp;
    if(Palavra.direcao==='1'){ //ESQUERDA-DIREITA 
      PosFinalTemp=[Palavra.posicao[0]+(Palavra.texto.length-1),Palavra.posicao[1]];
    }
    if(Palavra.direcao==='2'){ //DIREITA-ESQUERDA
      PosFinalTemp=[Palavra.posicao[0]-(Palavra.texto.length-1),Palavra.posicao[1]];
    }
    if(Palavra.direcao==='3'){ //CIMA-BAIXO
      PosFinalTemp=[Palavra.posicao[0],Palavra.posicao[1]+(Palavra.texto.length-1)];
    }
    if(Palavra.direcao==='4'){ //BAIXO-CIMA
      PosFinalTemp=[Palavra.posicao[0],Palavra.posicao[1]-(Palavra.texto.length-1)];
    }
    if(Palavra.direcao==='5'){ //ESQUERDA-DIREITA-CIMA-BAIXO
      PosFinalTemp=[Palavra.posicao[0]+(Palavra.texto.length-1),Palavra.posicao[1]+(Palavra.texto.length-1)];
    }
    if(Palavra.direcao==='6'){ //DIREITA-ESQUERDA-CIMA-BAIXO
      PosFinalTemp=[Palavra.posicao[0]-(Palavra.texto.length-1),Palavra.posicao[1]+(Palavra.texto.length-1)];
    }
    if(Palavra.direcao==='7'){ //DIREITA-ESQUERDA-BAIXO-CIMA
      PosFinalTemp=[Palavra.posicao[0]-(Palavra.texto.length-1),Palavra.posicao[1]-(Palavra.texto.length-1)];
    }
    if(Palavra.direcao==='8'){ //ESQUERDA-DIREITA-BAIXO-CIMA
      PosFinalTemp=[Palavra.posicao[0]+(Palavra.texto.length-1),Palavra.posicao[1]-(Palavra.texto.length-1)];
    }

    let PalavraTemp={
      Key:Math.random()*99999999,
      Texto:Palavra.texto,
      FirstLeter:Palavra.letraInicial,
      PosInicial:Palavra.posicao,
      LastLeter:Palavra.texto.charAt(Palavra.texto.length-1),
      PosFinal:PosFinalTemp,
      Found:"FALSE"
    }

    PalavrasSelecionadasTemp.push(PalavraTemp);
    setPalavrasSelecionadas(PalavrasSelecionadasTemp);
   
  }

  function verifyAndPutEnciclopediaInTabuleiro(value,ArrayTabuleiroObjectos,ArrayTabuleiro,EnciclopediaObjectos){
    let randomNumber;
    let tamEnciObjetos=EnciclopediaObjectos.length;
    let podeIr=0;
   

    for(let i=0;i<tamEnciObjetos;i++){
      randomNumber=Math.floor(Math.random()*EnciclopediaObjectos.length);
      podeIr=verifySeWordPodeIrProTabuleiro(ArrayTabuleiro,EnciclopediaObjectos[randomNumber]);
      
      if(podeIr===1){
        InserePalavraNoArrayDePalavrasSelecionadas(EnciclopediaObjectos[randomNumber]);
        InserePalavraNosTabuleiros(ArrayTabuleiroObjectos,ArrayTabuleiro,EnciclopediaObjectos[randomNumber]);
        EnciclopediaObjectos.splice(randomNumber,1);
      }
      else{
        EnciclopediaObjectos.splice(randomNumber,1);
     }
    
      
    }
    PreencheEspacosVazios(value,ArrayTabuleiroObjectos);
  }
  
  const [timer,setTimer]=useState(TIMEOUTGAME);
  
  let timerId;
  
  useEffect(() => {
    
    if (gameStarted) {
      let nextTimer;
      timerId = setInterval(() => {
        setTimer((previousState) => {
          nextTimer = previousState - 1;
          return nextTimer;
        });
        
        if (nextTimer === 0) {
          alert("JOGO TERMINADO");
          //GUARDA A PONTUAÇAO NO FICHEIRO
          window.location.reload(true);
        }
      }, 1000);
    } else if (timer !== TIMEOUTGAME) {
      setTimer(TIMEOUTGAME);
    }
    return () => {
      if (timerId) {
        clearInterval(timerId);
      }
    };
  }, [gameStarted]);

  function incrementaPontuacao(){
    setPontuacaoAtual((pontuacaoAtual+timer)*selectedLevel);
  }

  const handleLevelChange = (event) => {
    const { value } = event.currentTarget;
    setSelectedLevel(value);
    let ArrayTabuleiroObjectos=[];
    if(value==='0'){
      setTimer(0);
    }
    if(value==='1'){
      setTimer(60);
      TamTabuleiro=10;
      for(let i=0;i<TamTabuleiro;i++){
        ArrayTabuleiro.push(new Array(TamTabuleiro));
      }

      for(let i=0;i<TamTabuleiro;i++){
        ArrayTabuleiroObjectos.push(new Array(TamTabuleiro));
      }

      EnciclopediaObjectos=geraArrayPalavrasObjetos(value);

      verifyAndPutEnciclopediaInTabuleiro(value,ArrayTabuleiroObjectos,ArrayTabuleiro,EnciclopediaObjectos);
      
     
    }
    if(value==='2'){
      setTimer(120);
      TamTabuleiro=20;
      for(let i=0;i<TamTabuleiro;i++){
        ArrayTabuleiro.push(new Array(TamTabuleiro));
      }

      for(let i=0;i<TamTabuleiro;i++){
        ArrayTabuleiroObjectos.push(new Array(TamTabuleiro));
      }

      
      EnciclopediaObjectos=geraArrayPalavrasObjetos(value);

      ArrayTabuleiro=verifyAndPutEnciclopediaInTabuleiro(value,ArrayTabuleiroObjectos,ArrayTabuleiro,EnciclopediaObjectos);
      
      //setArrayTabuleiroEstado(ArrayTabuleiroObjectos);

    }
    if(value==='3'){
      setTimer(180);
      TamTabuleiro=30;
      for(let i=0;i<TamTabuleiro;i++){
        ArrayTabuleiro.push(new Array(TamTabuleiro));
      }

      for(let i=0;i<TamTabuleiro;i++){
        ArrayTabuleiroObjectos.push(new Array(TamTabuleiro));
      }

      
      EnciclopediaObjectos=geraArrayPalavrasObjetos(value);

  

      ArrayTabuleiro=verifyAndPutEnciclopediaInTabuleiro(value,ArrayTabuleiroObjectos,ArrayTabuleiro,EnciclopediaObjectos);
      
      //setArrayTabuleiroEstado(ArrayTabuleiroObjectos);

    
      
    }
  }

  function handleGameStart() {
    if(gameStarted===false){
      setGameStarted(true); 
      setTimer(60*selectedLevel);
    }
    else{
      setGameStarted(false);
      alert("A SUA PONTUAÇAO: "+pontuacaoAtual);
      //GUARDA PONTUAÇÃO NUM FICHEIRO
      window.location.reload(true);
      setTimer(60*selectedLevel);
    }
  }
  
  return (
    <div className="App">

      <Header>
      </Header>

      <ControlPanel 
        gameStarted={gameStarted} 
        selectedLevel={selectedLevel} 
        onAddWord={addWord}
        onGameStarted={handleGameStart} 
        onSelectedLevel={handleLevelChange}
        timer={timer}
        >
      </ControlPanel>

      <Tabuleiro
        gameStarted={gameStarted}
        enciclopediaCompleta={Enciclopedia}
        arrayTabuleiro={arrayTabuleiroEstado}
        selectedLevel={selectedLevel}
        palavrasSelecionadas={palavrasSelecionadas}
        arrayChavesDeLetras={arrayChavesDeLetras}
        pontuacaoAtual={pontuacaoAtual}
        incrementaPontuacao={incrementaPontuacao}
        >
      </Tabuleiro>
      
      
    </div>
  );
}


export default App;
