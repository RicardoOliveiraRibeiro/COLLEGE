#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "algoritmo.h"
#include "utils.h"



int main(int argc, char *argv[]) {
    char nome_fich[100];
    int vert, arestas, k, num_iter, runs, custo, best_custo = 0;
    int *grafo, *sol, *best;
    float mbf = 0;



    if (argc == 3) {
        runs = atoi(argv[2]);
        strcpy_s(nome_fich, sizeof(nome_fich), argv[1]);
    } else if (argc == 2) {
        printf("Indique o numero de runs:\n");
        scanf_s("%d", &runs);
        strcpy_s(nome_fich, sizeof(nome_fich), argv[1]);
    } else {
        printf("Indique o numero de runs\n");
        scanf_s("%d", &runs);
        printf("Nome do Ficheiro:\n");
        scanf("%s", nome_fich);
    }

    if (runs <= 0) {
        return 0;
    }
    printf("Indique o numero de iteracoes em cada algoritmo:\n");
    scanf_s("%d", &num_iter);
    init_rand();
    // Preenche matriz de adjacencias
    grafo = init_dados((char *) &nome_fich, &vert, &arestas);

    best = malloc(sizeof(int) * vert);

    /*
    if (sol == NULL || best == NULL) {
        printf("Erro na alocacao de memoria");
        exit(1);
    }
     */

    int escolha;
    printf("Trepa Colinas(1)\nEvolutivo(2)\nHibrido(3)(Not Working)\n");
    scanf("%d", &escolha);



    //TREPA COLINAS
    if (escolha == 1) {
        sol = malloc(sizeof(int) * vert);
        for (k = 0; k < runs; k++) {


            // Gerar solucao inicial ate gerar uma valida
            do {
                sol = gera_sol_inicial(sol, vert);
                //sol = escreve_sol(sol, vert);
                //printf("%d\n", check_sol(sol,grafo,vert,arestas));
            } while (check_sol(sol, grafo, vert, arestas) != 0);

            printf("\nSolucao inicial encontrada:\n");
            //apresenta sol
            sol = escreve_sol(sol, vert);

            // Trepa colinas
            custo = trepa_colinas(sol, grafo, vert, num_iter, arestas);
            // Escreve resultados da repeticao k
            printf("\nRepeticao %d:\n", k);

            printf("Melhor custo desta run ==> [%d]\n", custo);
            mbf += (float) custo;
            printf("Melhor Custo Anterior ==> [%d]\n",best_custo);
            if (k == 0 || best_custo <= custo) {
                printf("Troca Realizada\n");
                best_custo = custo;
                substitui(best, sol, vert);
            }
            else{
                printf("Troca Nao Realizada\n");
            }
            printf("Melhor solucao ate agora:\n");
            escreve_sol(best, vert);

        }
        printf("\n\nMBF: %f\n", mbf / k);
    }

    if (escolha == 2) {
        int **populacao;
        int tam_pop;

        printf("Escolha tamanho da populacao inicial\n");
        scanf("%d",&tam_pop);

        int *melhor_sol_da_pop=malloc(vert* (sizeof(int)));

        populacao = malloc(tam_pop * (sizeof(int *)));
        for (int i = 0; i < tam_pop; i++) {
            populacao[i] = malloc(vert * (sizeof(int)));
        }

        for (k = 0; k < runs; k++) {
            printf("\nRepeticao %d:\n",k);



            int **preenche_pop = populacao;
            for (int i = 0; i < tam_pop; i++) {
                sol=malloc(vert*sizeof(int));
                preenche_pop[i]= gera_sol_inicial(sol,vert);
                sol=NULL;
            }

            int** show_pop=populacao;
            printf("\nPopulacao:\n");
            for(int i=0;i<tam_pop;i++){
                show_pop[i]= escreve_sol(show_pop[i],vert);
            }
            printf("\n\n");


            int **show_pop_filho=populacao;

            for(int t=0;t<num_iter;t++) {

                custo = evolution(populacao, melhor_sol_da_pop, tam_pop, vert, grafo, arestas, &mbf, best_custo, t);

                printf("%d - Evolucao da populacao\n",t+1);
                for(int i=0;i<tam_pop;i++){
                    show_pop_filho[i]= escreve_sol(show_pop_filho[i],vert);
                }

                if(k!=0) {
                    printf("\nMelhor solucao encontrada nesta populacao:\n");
                    melhor_sol_da_pop = escreve_sol(melhor_sol_da_pop, vert);
                }

                printf("\nMelhor custo anterior: %d\n",best_custo);
                printf("Melhor custo desta desta run:%d\n",custo);

                if (k == 0 || best_custo <= custo) {
                    printf("Troca Realizada\n");
                    best_custo = custo;
                    substitui(best, melhor_sol_da_pop, vert);
                    reparacao2(best,vert,&best_custo);
                }
            }


        }


        printf("\n\nMBF: %f\n", mbf / ((k-1)*tam_pop));
    }


    // Escreve resultados globais

    printf("\nMelhor solucao encontrada");
    escreve_sol(best, vert);
    printf("Custo final: %2d\n", best_custo);
    free(grafo);
    free(sol);
    free(best);


    return 0;
}
