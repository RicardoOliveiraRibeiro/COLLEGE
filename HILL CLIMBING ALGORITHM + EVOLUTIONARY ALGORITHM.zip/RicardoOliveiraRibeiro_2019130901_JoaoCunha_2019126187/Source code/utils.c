#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "utils.h"

// Leitura do ficheiro de input
// Recebe: nome do ficheiro, numero de vertices (ptr), numero de iteracoes (ptr)
// Devolve a matriz de adjacencias
int* init_dados(char *nome, int *vert, int *arestas) {
    FILE *f;
    int *p, *q;
    int i;

    fopen_s(&f,nome,"r");
    if (!f) {
        printf("Erro no acesso ao ficheiro dos dados\n");
        exit(1);
    }
    //Skip first lines
    char holder;

    char buffer[300];


    holder=fgetc(f);
    do {
        if (holder == 'c') {
            fgets(buffer, 300, f);
        }
        holder=fgetc(f);
    }while(holder=='c');

    if (holder == EOF) {
        printf("ficheiro vazio\n");
    }
    if(holder =='p'){
        fscanf(f, " %s", buffer);//Lê a string
        fscanf(f, " %d", vert);//Lê o numero de vertices
        fscanf(f, " %d", arestas);//Lê o numero de arestas
        fgetc(f);
    }

    // Alocacao dinamica da matriz
    p = malloc(sizeof(int) * (*arestas) * 2);
    if (!p) {
        printf("Erro na alocacao de memoria\n");
        exit(1);
    }
    q = p;

    // Preenchimento da matriz


    for (i = 0; i < *arestas * 2; i++) {
        holder = fgetc(f);
        if(holder =='\n'){
            i--;
        }
        if (holder == 'e') {
            fscanf(f, " %d", q++);
            fscanf(f, " %d", q++);
            holder=fgetc(f);
        }
        if(holder==EOF){
            fclose(f);
            return p;
        }
    }
    fclose(f);
    return p;
}

void reparacao(int filho[], int grafo[],int vert, int arestas){
    int tam=0;

    while(filho[tam]!=0 || tam<vert){
        tam++;
    }

    do{
        if(check_sol(filho,grafo,vert,arestas)!=0) {
            filho[tam - 1] = 0;
            tam--;
        }
    }while(check_sol(filho,grafo,vert,arestas)!=0);
}

void reparacao2(int best[],int vert,int*best_custo){
    int num;
    for(int i=0;i<vert;i++){
        num=best[i];
        for(int j=0;j<i;j++){
            if(best[j]==num){
                for(int k=j;k<vert-1;k++){
                    best[k]=best[k+1];
                    best[vert-1]=0;
                    (*best_custo)--;
                }
            }
        }
        for(int j=i+1;j<vert;j++){
            if(best[j]==num){
                for(int k=j;k<vert-1;k++){
                    best[k]=best[k+1];
                    best[vert-1]=0;
                    (*best_custo)--;
                }
            }
        }
    }
}

// Gera a solucao inicial
// Parametros: solucao, numero de vertices
int* gera_sol_inicial(int sol_recebida[], int v)
{
    int*sol=sol_recebida;
    int *devolve_esta=sol;
    int random;
    int random_length;
    int check=0;
    random_length= random_l_h(1,v);
	for(int i=0; i<random_length; i++) {
        random= random_l_h(1,v);

        for(int j=0;j<=i;j++){
            if(sol[j]==random){
                check=1;
                break;
            }
        }

        if(check==0) {
            sol[i] = random;
        }
        else{
            check=0;
            i--;
        }
    }
    for(int i=random_length;i<v;i++){
        sol[i]=0;
    }


return devolve_esta;
}



//Compara sol com grafo
//Parametros:
int check_sol( int *sol_recebida, int *grafo_recebido, int vert, int arestas){
    int i=0;
    int compara;
    int num;
    int*sol=sol_recebida;
    int* grafo=grafo_recebido;
	//printf("grafo:");
	//grafo=escreve_sol(grafo,arestas*2);

    while(sol[i]!=0) {                    //ENQUANTO HOUVER NUMEROS NA SOL
        num = sol[i];                 //BUSCA UM NUMERO

        for(int j=0;j<arestas*2;j++){     //PERCORRE O GRAFO
            if(num==grafo[j]){            //SE O NUM FOR IGUAL
                float impar=(float)j/2.0;          //DIVIDO ESSA POSICAO NO GRAFO POR 2
                if(impar-(int)impar==0){  //SE FOR PAR
                    compara=grafo[j+1];   //COMPARA = NUMERO DA FRENTE
					//printf("pos do grafo comp: %d\n", j+1);
					//printf("COMPARA = NUMERO DA FRENTE %d\n", compara);
                }
                else{                      //SE FOR IMPAR
                    compara=grafo[j-1];    //COMPARA = NUMERO DE TRAS
					//printf("pos do grafo comp: %d\n", j-1);
					//printf("COMPARA = NUMERO DE TRAS %d\n", compara);
                }
                int u=0;
                while(sol[u]!=0){           //PERCORRO A MINHA SOL OUTRA VEZ
                    if(sol[u]==compara){    //SE LA HOUVER O NUMERO = AO COMPARA
                        //printf("Ligacao encontrada\n");
						//printf("pos u = %d\n", u);
						//printf("sol[u] %d\n", sol[u]);
						//printf("compara %d\n", compara);

                        return 1;       //A SOL NAO É VALIDA

                    }
                    u++;
                }
            }

        }
        i++;
    }

    return 0;
}
// Escreve solucao
// Parametros: solucao e numero de vertices
int* escreve_sol(int *sol_recebido, int vert)
{
    int* sol=sol_recebido;
    int i=0;
    printf("sol: {");
	while(sol[i]!=0&&i<vert){
        printf("%d ", sol[i]);
        i++;
    }
    printf("}\n");
    return sol_recebido;
}

// copia vector b para a (tamanho n)
void substitui(int sol_recebida[], int nova_sol_recebida[], int n)
{
    int* sol=sol_recebida;
    int* nova_sol=nova_sol_recebida;

    int i;
    for(i=0; i<n; i++) {
        sol[i] = nova_sol[i];
    }
}

// Inicializa o gerador de numeros aleatorios
void init_rand()
{
	srand((unsigned)time(NULL));
}

// Devolve valor inteiro aleatorio entre min e max
int random_l_h(int min, int max)
{
	return min + rand() % (max-min+1);
}

// Devolve um valor real aleatorio do intervalo [0, 1]
float rand_01()
{
	return ((float)rand())/RAND_MAX;
}
