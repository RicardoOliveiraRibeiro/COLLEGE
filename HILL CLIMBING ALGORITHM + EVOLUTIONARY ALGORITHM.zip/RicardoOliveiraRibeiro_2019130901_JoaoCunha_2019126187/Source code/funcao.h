int calcula_fit(int sol[],int vert);
