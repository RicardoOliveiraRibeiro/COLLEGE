int trepa_colinas(int sol[], int *mat, int vert, int num_iter, int arestas);
int trepa_colinas_aceita_custo_igual(int sol[], int *mat, int vert, int num_iter);
int trepa_colinas_aceita_sol_pior(int sol[], int *mat, int vert, int num_iter);
int recristalizacao_simulada(int sol[], int *mat, int vert, int num_iter, float TMax, float TMin,
                             float vel_arref, int viz_type);

int evolution(int* populacao[],int melhor_sol_da_pop[],int tam_pop,int vert, int grafo[],int arestas,float* mbf, int best_custo,int iter);