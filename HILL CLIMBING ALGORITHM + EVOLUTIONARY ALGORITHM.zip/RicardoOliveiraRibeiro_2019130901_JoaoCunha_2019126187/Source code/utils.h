
int* init_dados(char *nome, int *vert, int *arestas);
int* gera_sol_inicial(int *sol, int v);
int check_sol(int *sol, int *grafo, int vert, int arestas);
int* escreve_sol(int *sol, int vert);
void substitui(int a[], int b[], int n);
void init_rand(void);
int random_l_h(int min, int max);
float rand_01(void);
void reparacao(int filho1[],int grafo[],int vert, int arestas);
void reparacao2(int best[],int vert,int*best_custo);