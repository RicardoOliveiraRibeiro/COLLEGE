#include <stdio.h>
#include <stdlib.h>
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"
#include "math.h"



// Gera um vizinho
// Parametros: solucao actual, vizinho, numero de vertices
//swap two vertices

void gera_vizinho(int sol_recebida[],int nova_sol_recebida[], int vert){
    int tam=0;
    int*sol=sol_recebida;
    int*nova_sol=nova_sol_recebida;

    for(int i=0;i<vert;i++){
        nova_sol[i]=0;
    }
    while(sol[tam]!=0){
        tam++;
    }

    for(int i=0;i<tam;i++){
        nova_sol[i]=sol[i];
    }

    for(int i=tam;i<vert;i++){
        nova_sol[i]=0;
    }
    int metido;
    int pode_meter;

   do {
       pode_meter=0;
       metido=0;
       int random_number = random_l_h(0, vert);
       if (random_number == 0) {
           if (tam != 0) {
               nova_sol[tam] = 0; // remove ultimo vertice da solucao
               metido=0;
           }
           nova_sol = nova_sol_recebida;
       } else {
           for (int j = 0; j < vert; j++) {
               if (nova_sol[j] == random_number) {
                   pode_meter = 1;
                   metido=1;
               }
           }
           if (pode_meter == 0) {
               nova_sol[tam] = random_number; // adiciona vertice à solucao
               metido=0;
           }

       }
   }while(metido==1);
}




int trepa_colinas(int *sol_recebida, int *grafo_recebido, int vert, int num_iter, int arestas)
{
    int*sol=sol_recebida;
    int*grafo=grafo_recebido;
    int *nova_sol, custo, custo_viz, i;

    nova_sol = malloc((sizeof(int))*(vert));
    if(nova_sol == NULL)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }
    // Avalia solucao inicial
    custo = calcula_fit(sol,vert);
    for(i=0; i<num_iter; i++)
    {
        // Gera vizinho
        do {
            gera_vizinho(sol, nova_sol, vert);
            printf("Vizinho:\n");
            nova_sol=escreve_sol(nova_sol,vert);
        }while(check_sol(nova_sol, grafo,vert,arestas)!=0); //Enquanto este n for bom

        printf("Nova Solucao Aceitada\n");
        //nova_sol=escreve_sol(nova_sol,vert);//apresenta novo vizinho

        // Avalia vizinho
        custo_viz = calcula_fit(nova_sol,vert);
        // Aceita vizinho se o custo diminuir (problema de minimizacao)
        if(custo_viz > custo)
        {
            substitui(sol, nova_sol, vert);
            custo = custo_viz;
        }
    }
    free(nova_sol);
    return custo;
}

int evolution(int* populacao_inicial[],int melhor_sol_da_pop[],int tam_pop,int vert,int grafo[],int arestas,float *mbf,int best_custo,int iter) {

    int **pop_filho;


    pop_filho = malloc(tam_pop * (sizeof(int *)));
    int **init_pop_filho = pop_filho;
    for (int i = 0; i < tam_pop; i++) {
        init_pop_filho[i] = malloc(vert * (sizeof(int)));
    }


    int tam_pai;
    int tam_mae;

    int random_length_filho;
    int **populacao = populacao_inicial;

    int **create_pop_filho = pop_filho;
    int **show_parents = populacao;
    for (int i = 0; i < tam_pop; i = i + 2) {

        tam_mae = 0;
        tam_pai = 0;

        //calc tamanho do pai
        for (int j = 0; j < vert; j++) {
            if (populacao[i][j] != 0) {
                tam_pai++;
            }
        }

        //calc tamanho da mae
        for (int j = 0; j < vert; j++) {
            if (populacao[i + 1][j] != 0) {
                tam_mae++;
            }
        }

        printf("PAI:\n");
        escreve_sol(show_parents[i], vert);
        printf("MAE:\n");
        escreve_sol(show_parents[i + 1], vert);

        //cria filho1
        if (tam_pai >= tam_mae) {
            random_length_filho = random_l_h(0, tam_mae - 1);
            for (int j = 0; j < random_length_filho; j++) {
                create_pop_filho[i][j] = populacao[i + 1][j];
            }
            for (int j = random_length_filho; j < tam_pai; j++) {
                create_pop_filho[i][j] = populacao[i][j];
            }
            for (int j = tam_pai; j < vert; j++) {
                create_pop_filho[i][j] = 0;
            }
        }
        else {
            random_length_filho = random_l_h(0, tam_pai - 1);
            for (int j = 0; j < random_length_filho; j++) {
                create_pop_filho[i][j] = populacao[i][j];
            }
            for (int j = random_length_filho; j < tam_mae; j++) {
                create_pop_filho[i][j] = populacao[i + 1][j];
            }
            for (int j = tam_mae; j < vert; j++) {
                create_pop_filho[i][j] = 0;
            }
        }
        printf("Filho 1 gerado:\n");
        escreve_sol(create_pop_filho[i], vert);

        //cria filho2

        if (tam_pai >= tam_mae) {
            for (int j = 0; j < random_length_filho; j++) {
                create_pop_filho[i+1][j] = populacao[i][j];
            }
            for (int j = random_length_filho; j < tam_mae; j++) {
                create_pop_filho[i+1][j] = populacao[i+1][j];
            }
            for (int j = tam_mae; j < vert; j++) {
                create_pop_filho[i+1][j] = 0;
            }
        }
        else {
            for (int j = 0; j < random_length_filho; j++) {
                create_pop_filho[i+1][j] = populacao[+1][j];
            }
            for (int j = random_length_filho; j < tam_pai; j++) {
                create_pop_filho[i+1][j] = populacao[i][j];
            }
            for (int j = tam_pai; j < vert; j++) {
                create_pop_filho[i+1][j] = 0;
            }
        }


        printf("Filho 2 gerado:\n");
        escreve_sol(create_pop_filho[i + 1], vert);

        //mutaçao dos filhos gerados ate serem validos

        reparacao(create_pop_filho[i], grafo, vert, arestas);
        reparacao(create_pop_filho[i + 1], grafo, vert, arestas);

        printf("Filho 1 depois de reparado:\n");
        escreve_sol(create_pop_filho[i], vert);
        printf("Filho 2 depois de reparado:\n");
        escreve_sol(create_pop_filho[i + 1], vert);
    }

    int **find_best_pop_filho = pop_filho;
    int count;
    int* copy_melhor_sol=melhor_sol_da_pop;

    if (iter != 0) {
        for (int i = 0; i < tam_pop; i++) {
            count = 0;
            for (int j = 0; j < vert; j++) {
                if (find_best_pop_filho[i][j] != 0) {
                    count++;
                } else { break; }
            }

            if (count > best_custo) {
                best_custo = count;

                for (int j = 0; j < vert; j++) {
                    copy_melhor_sol[j] = find_best_pop_filho[i][j];
                }
            }
            *mbf += (float) count;
        }
        *mbf= *mbf/tam_pop;
    }

    int** copy_pop=populacao_inicial;

    for (int i = 0; i < tam_pop; i++) {
        for (int j = 0; j < vert; j++) {
            copy_pop[i][j] = pop_filho[i][j];
        }
    }



    free(pop_filho);
    return best_custo;
}


/*
int trepa_colinas_aceita_sol_pior(int sol[], int *mat, int vert, int num_iter){
    int *nova_sol, custo, custo_viz, i;

    nova_sol = malloc(sizeof(int)*vert);
    if(nova_sol == NULL)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }
    // Avalia solucao inicial
    custo = calcula_fit(sol, mat, vert);
    for(i=0; i<num_iter; i++)
    {
        // Gera vizinho
        gera_vizinho(sol, nova_sol, vert);
        // Avalia vizinho
        custo_viz = calcula_fit(nova_sol, mat, vert);
        // Aceita vizinho se o custo diminuir (problema de minimizacao)
        if(custo_viz <= custo)
        {
            substitui(sol, nova_sol, vert);
            custo = custo_viz;
        }
        else
        {

            int r = rand() %9;      // Returns a pseudo-random integer between 0 and RAND_MAX.
            if(r<1){
                substitui(sol, nova_sol, vert);
                custo = custo_viz;
            }
        }
    }
    free(nova_sol);
    return custo;
}
*/

/*
int recristalizacao_simulada(int sol[], int *mat, int vert, int num_iter, float TMax, float TMin,
                             float vel_arref, int viz_type){


        int *nova_sol, custo, custo_viz, i;
        float t=TMax, delta_c;

        nova_sol = malloc(sizeof(int)*vert);
        if(nova_sol == NULL)
        {
            printf("Erro na alocacao de memoria");
            exit(1);
        }
        // Avalia solucao inicial
        custo = calcula_fit(sol, mat, vert);
        for(i=0; i<num_iter||t>TMin; i++)
        {

                // Gera vizinho
                switch(viz_type){

                    case 1: {
                        gera_vizinho(sol, nova_sol, vert);
                        break;
                    }
                    case 2:{
                        gera_vizinho_2(sol, nova_sol, vert);
                        break;
                    }
                }

                // Avalia vizinho
                custo_viz = calcula_fit(nova_sol, mat, vert);
                // Aceita vizinho se o custo diminuir (problema de minimizacao)
                delta_c=custo_viz-custo;

                if (delta_c<=0) {
                    substitui(sol, nova_sol, vert);
                    custo = custo_viz;
                }
                else {
                    float r = rand_01();      // Returns a pseudo-random integer between 0 and RAND_MAX.
                    if (r <= exp((-delta_c) / t)) {
                        substitui(sol, nova_sol, vert);
                        custo = custo_viz;
                    }
                }


            //t=t-vel_arref;
            t=t*vel_arref;
            //[t=t/(1+(vel_arref*t))];
        }
        free(nova_sol);
        return custo;
    }
*/
