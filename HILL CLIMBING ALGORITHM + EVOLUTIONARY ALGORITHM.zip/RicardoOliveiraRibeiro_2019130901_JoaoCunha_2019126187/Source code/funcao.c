#include "funcao.h"

// Calcula a qualidade de uma solu��o
// Recebe:  A solu��o, a, a matriz de adjac�ncias, mat, e o n�mero de v�rtices, vert
// Devolve: O custo que � o n�mero de liga��es que existem na solu��o
int calcula_fit(int sol_recebida[],int vert)
{
    int* sol=sol_recebida;
    int i=0;
    while(sol[i]>0&&sol[i]<=vert){
        i++;
    }
    return i;
}
