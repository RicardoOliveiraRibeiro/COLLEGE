%Trabalho elaborado por:
%Ricardo Ribeiro :2019130901
%Jo�o Cunha : 2019126187

%   [t,u,v]=NEuler_MSED(f,g,a,b,n,u0,v0) M�todo num�rico para a resolu��o de um PVI
%   u'= f(t,u,v), v'=g(t,u,v), t=[a, b], u(a)=u0 e v(a)=v0  
%
%INPUT:
%   f, g - fun��es do 2.� membro das Equa��es Diferenciais
%   [a, b] - extremos do intervalo da vari�vel independente t
%   n - n�mero de subintervalos ou itera��es do m�todo
%   u0, v0 - condi��es iniciais t=a -> u=u0 e v=v0
%OUTPUT: 
%   [t,u,v] - vector das solu��es aproxima��es e da discretiza��o de t
%   auxy_1 = u(i)+ h*f(t(i),u(i),v(i))
%   u(i+1) = u(i)+h*(f(t(i),u(i),v(i))+f(t(i+1),auxy_1)/2 , i =0,1,...,n-1
%
%   01/04/2020 - Rodrigo Duarte e Rui Oliveira : a2019132858@isec.pt e a2019132875@isec.pt 

function [u,v]=NEuler_MSED(f,g,a,b,n,u0,v0)
    h = (b-a)/n; %c�lculo da dist�ncia h entre dois pontos num intervalo [a,b] com n sub-intervalos
    t = a:h:b; %vetor com valores de t num intervalo [a,b] com passo h
    u = zeros(1,n+1); 
    v = zeros(1,n+1); 
    u(1) = u0; %atribui��o do valor u0(Condi��o Inicial) a u(1)
    v(1) = v0; %atribui��o do valor v0(Condi��o Inicial) a v(1)
    
    for i=1:n
        uk = u(i)+h*f(t(i),u(i),v(i));
        vk = v(i)+h*g(t(i),u(i),v(i));
        u(i+1) = u(i) + (h/2)*(f(t(i),u(i),v(i)) + f((t(i)+h),uk,vk));
        v(i+1) = v(i) + (h/2)*(g(t(i),u(i),v(i)) + g((t(i)+h),uk,vk));

    end
end