%Trabalho elaborado por:
%Ricardo Ribeiro :2019130901
%João Cunha : 2019126187

function varargout = GUI(varargin)
% GUI MATLAB code for GUI.fig
%      GUI, by itself, creates a new GUI or raises the existing
%      singleton*.
%
%      H = GUI returns the handle to a new GUI or the handle to
%      the existing singleton*.
%
%      GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GUI.M with the given input arguments.
%
%      GUI('Property','Value',...) creates a new GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before GUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to GUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help GUI

% Last Modified by GUIDE v2.5 09-May-2020 19:25:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @GUI_OpeningFcn, ...
                   'gui_OutputFcn',  @GUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before GUI is made visible.
function GUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to GUI (see VARARGIN)

% Choose default command line output for GUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);
MyAtualizar(handles);

grid on;


%Associar o logotipo do isec ao Axes com id logo_isec_gui através de
%variável auxiliar com o caminho para a imagem
ISEC=imread('files/img/logos/isecSigla_cor.jpg','JPEG');
imshow(ISEC,[],'Parent',handles.logo_isec_gui);

%Associar o logotipo do ipc ao Axes com id logo_ipc_gui através de variável
%auxiliar com o caminho para a imagem.
IPC=imread('files/img/logos/ipc_preto.jpg','JPEG');
imshow(IPC,[],'Parent',handles.logo_ipc_gui);


% UIWAIT makes GUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = GUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function func_f_Callback(hObject, eventdata, handles)
% hObject    handle to func_f (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of func_f as text
%        str2double(get(hObject,'String')) returns contents of func_f as a double
set(handles.func_f,'BackgroundColor','w');  

% --- Executes during object creation, after setting all properties.
function func_f_CreateFcn(hObject, eventdata, handles)
% hObject    handle to func_f (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function a_Callback(hObject, eventdata, handles)
% hObject    handle to a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of a as text
%        str2double(get(hObject,'String')) returns contents of a as a double
set(handles.a,'BackgroundColor','w');  

% --- Executes during object creation, after setting all properties.
function a_CreateFcn(hObject, eventdata, handles)
% hObject    handle to a (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function f0_Callback(hObject, eventdata, handles)
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of f0 as text
%        str2double(get(hObject,'String')) returns contents of f0 as a double
set(handles.f0,'BackgroundColor','w');  

% --- Executes during object creation, after setting all properties.
function f0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to f0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function b_Callback(hObject, eventdata, handles)
% hObject    handle to b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of b as text
%        str2double(get(hObject,'String')) returns contents of b as a double
set(handles.b,'BackgroundColor','w');  

% --- Executes during object creation, after setting all properties.
function b_CreateFcn(hObject, eventdata, handles)
% hObject    handle to b (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in cb_h.
function cb_h_Callback(hObject, eventdata, handles)
% hObject    handle to cb_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cb_h


% --- Executes on button press in cb_n.
function cb_n_Callback(hObject, eventdata, handles)
% hObject    handle to cb_n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of cb_n



function value_h_Callback(hObject, eventdata, handles)
% hObject    handle to value_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of value_h as text
%        str2double(get(hObject,'String')) returns contents of value_h as a double


% --- Executes during object creation, after setting all properties.
function value_h_CreateFcn(hObject, eventdata, handles)
% hObject    handle to value_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function n_Callback(hObject, eventdata, handles)
% hObject    handle to n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of n as text
%        str2double(get(hObject,'String')) returns contents of n as a double
set(handles.n,'BackgroundColor','w');  

% --- Executes during object creation, after setting all properties.
function n_CreateFcn(hObject, eventdata, handles)
% hObject    handle to n (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in rb_h.
function rb_h_Callback(hObject, eventdata, handles)
% hObject    handle to rb_h (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_h


% --- Executes on button press in rb_Euler.
function rb_Euler_Callback(hObject, eventdata, handles)
% hObject    handle to rb_Euler (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_Euler


% --- Executes on button press in rb_EulerV2.
function rb_EulerV2_Callback(hObject, eventdata, handles)
% hObject    handle to rb_EulerV2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_EulerV2


% --- Executes on button press in rb_NRK2.
function rb_NRK2_Callback(hObject, eventdata, handles)
% hObject    handle to rb_NRK2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_NRK2


% --- Executes on button press in radiobutton7.
function radiobutton7_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton7


% --- Executes on button press in rb_NRK3.
function rb_NRK3_Callback(hObject, eventdata, handles)
% hObject    handle to rb_NRK3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_NRK3


% --- Executes on button press in rb_NRK4.
function rb_NRK4_Callback(hObject, eventdata, handles)
% hObject    handle to rb_NRK4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_NRK4


% --- Executes on button press in rb_ODE45.
function rb_ODE45_Callback(hObject, eventdata, handles)
% hObject    handle to rb_ODE45 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_ODE45

% --- Executes on button press in rb_Todos.
function rb_Todos_Callback(hObject, eventdata, handles)
% hObject    handle to rb_Todos (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rb_Todos


% --- Executes on button press in btn_Atualizar.
function btn_Atualizar_Callback(hObject, eventdata, handles)
% hObject    handle to btn_Atualizar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
MyAtualizar(handles);

function MyAtualizar(handles)

set(handles.a,'BackgroundColor','w');

strG=get(handles.func_g,'String');
g   =@(t,u,v) eval(vectorize(strG));

strF=get(handles.func_f,'String');
f   =@(t,u,v) eval(vectorize(strF));

a   = str2num(get(handles.a,'String'));
b   = str2num(get(handles.b,'String'));
n   = str2num(get(handles.n,'String'));
f0  = str2num(get(handles.f0,'String'));
g0  = str2num(get(handles.g0,'String'));
finalError = {};

escolhabg=get(handles.metodosNum,'SelectedObject');
escolha=find([handles.rb_Euler,...
              handles.rb_EulerV2,...
              handles.rb_NRK2,...
              handles.rb_NRK4,...
              handles.rb_Todos]==escolhabg);
EULER=1;
EULERM=2;
RK2=3;
RK4=4;
TODOS=5;
 
try  
    %Verificação das funções para ver se estas são válidas (funções em t, u e v)
    try
        gTeste=g(sym('t'),sym('u'),sym('v'));  
    catch
        finalError = [finalError {'G tem de ser uma função em t, u e v'}];
        set(handles.func_g,'BackgroundColor','r');        
    end
    
    try
        fTeste=f(sym('t'),sym('u'),sym('v'));  
    catch
        finalError = [finalError {'F tem de ser uma função em t, u e v'}];
        set(handles.func_f,'BackgroundColor','r');        
    end
    %--------------------------------------------------------------------
    
    %verificar se o valor introduzido é escalar e real (não complexo)
    if ~(isscalar(a) && isreal(a)) 
        finalError = [finalError {'O valor de A tem de ser um número real'}];
        set(handles.a,'BackgroundColor','r');  
    end
    %---------------------------------------------------------------------
    
    %verificar se o valor introduzido é escalar e real (não complexo)
    if ~(isscalar(b) && isreal(b)) 
        finalError = [finalError {'O valor de B tem de ser um número real'}];
        set(handles.b,'BackgroundColor','r');  
    end
    %----------------------------------------------------------------------
    
    %verificar se o valor de a é maior que b, se for dá erro pois o valor de 
    %a tem de ser inferior ao valor de b
    if (a > b) 
        finalError = [finalError {'O valor de A tem de ser inferior a B'}]; 
        set(handles.b,'BackgroundColor','r'); 
        set(handles.a,'BackgroundColor','y'); 
    end
    %-----------------------------------------------------------------------
    
    %verificar se o valor introduzido é maior que zero, se for menor dá
    %erro pois não existem intervalos negativos.
    if ~(n > 0) 
        finalError = [finalError {'Valor de N inválido! Não podem existir intervalos negativos!'}];
        set(handles.n,'BackgroundColor','r'); 
    end
    %------------------------------------------------------------------------
    
    %verificar se o valor introduzido é escalar e real (não complexo)
    if ~(isscalar(n) && isreal(n)) 
        finalError = [finalError {'Valor de N inválido! N tem de ser um número real positivo.'}]; 
        set(handles.n,'BackgroundColor','r'); 
    end
    %------------------------------------------------------------------------
    
    %verificar se o valor introduzido é um número inteiro    
    if ~(n==round(n, 0)) %se o valor do campo for igual ao seu valor arredondado então n é inteiro
        finalError = [finalError {'Valor de N inválido! Não existe um número decimal de sub-intervalos'}];
        set(handles.n,'BackgroundColor','r'); 
    end
    %---------------------------------------------------------------------
    
    %verificar se o valor introduzido é escalar e real (não complexo)
    if ~(isscalar(f0) && isreal(f0)) 
        finalError = [finalError {'Valor de f0 inválido! Tem de introduzir um valor real!'}];
        set(handles.f0,'BackgroundColor','r'); 
    end
    
    if ~(isscalar(g0) && isreal(g0)) 
        finalError = [finalError {'Valor de g0 inválido! Tem de introduzir um valor real!'}];
        set(handles.g0,'BackgroundColor','r'); 
    end
    %----------------------------------------------------------------------

    %cálculo da distância h entre dois pontos num intervalo [a,b] com n sub-intervalos
    h = (b-a)/n;
   
    %Valores que t pode tomar num intervalo [a,b], com distância h
    t=a:h:b;    

    set(handles.figure1,'CurrentAxes',handles.graph);
    
    %PROBLEMA DO PÊNDULO
    if (get(handles.ppdef,'Value')==1)
        
        %caso haja algum erro, mostra todos os erros numa errordlg em vez de
        %mostrar diversas mensagens de erro separadas
        if ~isempty(finalError)
            waitfor(errordlg(finalError,'ERRO','modal'));
        end
        %----------------------------------------------------------------------
        
        switch (escolha)
            case 1  
                [u,v]=NEulerSED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                hold on
                plot(t , v , 'r' , 'linewidth' , 2);
                hold off
                legend('Deslocamento','Velocidade');
                tabela=[t.',u.',v.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Deslocamento'},{'Velocidade'}]);

            case 2  
                [u,v]=NEuler_MSED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                hold on
                plot(t , v , 'r' , 'linewidth' , 2);
                hold off
                legend('Deslocamento','Velocidade');
                tabela=[t.',u.',v.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Deslocamento'},{'Velocidade'}]);

            case 3
                [u,v] = NRK2_SED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                hold on
                plot(t , v , 'r' , 'linewidth' , 2);
                hold off
                legend('Deslocamento','Velocidade');
                tabela=[t.',u.',v.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Deslocamento'},{'Velocidade'}]);

            case 4
                [u,v] = NRK4_SED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                hold on
                plot(t , v , 'r' , 'linewidth' , 2);
                hold off
                legend('Deslocamento','Velocidade');
                tabela=[t.',u.',v.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Deslocamento'},{'Velocidade'}]);

            case 5
                [uE,vE] = NEulerSED(f,g,a,b,n,f0,g0);
                [uEM,vEM] = NEuler_MSED(f,g,a,b,n,f0,g0);
                [uRK2,vRK2] = NRK2_SED(f,g,a,b,n,f0,g0);
                [uRK4,vRK4] = NRK4_SED(f,g,a,b,n,f0,g0);

                plot(t , uE , '-+' , 'linewidth' , 2, 'Color', [0.4660 0.6740 0.1880]);
                hold on
                plot(t , vE , '-*' , 'linewidth' , 2, 'Color', [0.4660 0.6740 0.1880]);
                hold on

                plot(t , uEM , '-+' , 'linewidth' , 2, 'Color', [0.6350 0.0780 0.1840]);
                hold on
                plot(t , vEM , '-*' , 'linewidth' , 2, 'Color', [0.6350 0.0780 0.1840]);
                hold on

                plot(t , uRK2 , '-b+' , 'linewidth' , 2);
                hold on
                plot(t , vRK2 , '-b*' , 'linewidth' , 2);
                hold on

                plot(t , uRK4 , '-+' , 'linewidth' , 2, 'color', [0.4940 0.1840 0.5560]);
                hold on
                plot(t , vRK4 , '-*' , 'linewidth' , 2, 'color', [0.4940 0.1840 0.5560]);
                hold on

                hold off
                legend('Desloc. Euler','Vel. Euler','Desloc. EulerM','Vel. EulerM','Desloc. NRK2','Vel. NRK2','Desloc. NRK4','Vel. NRK4');
                tabela=[t.',uE.',vE.',uEM.',vEM.',uRK2.',vRK2.',uRK4.',vRK4.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Desloc. Euler'},{'Vel. Euler'},{'Desloc. EulerM'},{'Vel. EulerM'},{'Desloc. NRK2'},{'Vel. NRK2'},{'Desloc. NRK4'},{'Vel. NRK4'}]);
        end
    %----------------------------------------------------------------------
    %outros problemas
    else
        %caso haja algum erro, mostra todos os erros numa errordlg em vez de
        %mostrar diversas mensagens de erro separadas
        if ~isempty(finalError)
            waitfor(errordlg(finalError,'ERRO','modal'));
        end
        %----------------------------------------------------------------------
        
        switch (escolha)
            case 1  
                [u,v]=NEulerSED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                legend('Euler');
                tabela=[t.',u.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Euler'}]);

            case 2  
                [u,v]=NEuler_MSED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                legend('Euler Melhorado');
                tabela=[t.',u.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Euler Melhorado'}]);

            case 3
                [u,v] = NRK2_SED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                legend('NRK2');
                tabela=[t.',u.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'NRK2'}]);

            case 4
                [u,v] = NRK4_SED(f,g,a,b,n,f0,g0);

                plot(t , u , 'm' , 'linewidth' , 2);
                legend('NRK4');
                tabela=[t.',u.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'NRK4'}]);

            case 5
                [uE,vE] = NEulerSED(f,g,a,b,n,f0,g0);
                [uEM,vEM] = NEuler_MSED(f,g,a,b,n,f0,g0);
                [uRK2,vRK2] = NRK2_SED(f,g,a,b,n,f0,g0);
                [uRK4,vRK4] = NRK4_SED(f,g,a,b,n,f0,g0);

                plot(t , uE , '-+' , 'linewidth' , 2, 'Color', [0.4660 0.6740 0.1880]);
                hold on

                plot(t , uEM , '-+' , 'linewidth' , 2, 'Color', [0.6350 0.0780 0.1840]);
                hold on

                plot(t , uRK2 , '-b+' , 'linewidth' , 2);
                hold on

                plot(t , uRK4 , '-+' , 'linewidth' , 2, 'color', [0.4940 0.1840 0.5560]);
                hold on

                hold off
                legend('Euler','Euler Melhorado','NRK2','NRK4');
                tabela=[t.',uE.',uEM.',uRK2.',uRK4.']; 
                set(handles.uiTabela,'Data',num2cell(tabela)); 
                set(handles.uiTabela,'ColumnName',...
                  [{'t'},{'Euler'},{'Euler Melhorado'},{'NRK2'},{'NRK4'}]);
        end
        %set(handles.func_f,'Enable','off');
    end
    
    
    if get(handles.grid_onoff, 'state') == 1
        grid on;
    end
    
    if get(handles.legend_onoff, 'state') == 0
        legend off;
    end
    
catch Me
    errordlg(Me.message,'ERRO','modal');
end


% --------------------------------------------------------------------
function ficheiro_Callback(hObject, eventdata, handles)
% hObject    handle to ficheiro (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sair_Callback(hObject, eventdata, handles)
% hObject    handle to sair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%função de verificação de saída
op=questdlg('Tem a certeza que quer sair?','SAIR','Sim','Não','Sim');
if strcmp(op,'Não')
    return;
end
delete(handles.figure1); %se escolher a opção sim fecha a GUI

function sair_Callback_2(hObject, eventdata, handles)
% hObject    handle to sair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%função de verificação de saída
op=questdlg('Tem a certeza que quer sair?','SAIR','Sim','Não','Sim');
if strcmp(op,'Não')
    return;
end
delete(handles.figure1); Home(); a2019132875_a2019132858_AM2TP; 
%se escolher sim fecha a GUI, abre a interface de texto e a home (Menu)

function sair_Callback_3(hObject, eventdata, handles)
% hObject    handle to sair (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%função de verificação de saída
op=questdlg('Tem a certeza que quer sair?','SAIR','Sim','Não','Sim');
if strcmp(op,'Não')
    return;
end
delete(handles.figure1); Home(); %se escolher sim fecha a GUI e abre o Home (menu)


% --- Executes on button press in reset_values.
function reset_values_Callback(hObject, eventdata, handles)
% hObject    handle to reset_values (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%reset dos valores e propriedades ao clicar no botão de reset
if(get(handles.ppendulo,'Checked') == 1)
    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
    set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
    set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
    set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');

else
    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
    set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
    set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
    set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
    
    questdlg('Foram colocados por defeito os valores correspondentes ao Problema do Pêndulo','RESET GUI','Ok','Ok');

    set(handles.ppendulo,'Checked',1);
    set(handles.mmsa,'Checked',0);
    set(handles.mmca,'Checked',0);
    set(handles.vfa,'Checked',0);
    set(handles.rm,'Checked',0);
    
    set(handles.ppdef,'Value',1);
end

set(handles.metodosNum , 'SelectedObject' , '');

set(handles.rb_Euler , 'value' , 1);

MyAtualizar(handles);

% --- Executes when user attempts to close figureMaquinaEDO1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
% hObject    handle to figureMaquinaEDO1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: delete(hObject) closes the figure
%delete(hObject);

%chamada da função de verificação de saída
sair_Callback([], [], handles);


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function grid_onoff_ClickedCallback(hObject, eventdata, handles)
% hObject    handle to grid_onoff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function grid_onoff_OffCallback(hObject, eventdata, handles)
% hObject    handle to grid_onoff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%ativar a grelha do gráfico
grid on; set(handles.grid_onoff, 'state', 1);

% --------------------------------------------------------------------
function grid_onoff_OnCallback(hObject, eventdata, handles)
% hObject    handle to grid_onoff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%desativar a grelha do gráfico
grid off; set(handles.grid_onoff, 'state', 0);

% --------------------------------------------------------------------
function legend_onoff_OffCallback(hObject, eventdata, handles)
% hObject    handle to legend_onoff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%ativar a legenda do gráfico
legend on; set(handles.legend_onoff, 'state',1);


% --------------------------------------------------------------------
function autor_open_Callback(hObject, eventdata, handles)
% hObject    handle to autor_open (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Abrir a GUI "Autores"
Autores();


% --------------------------------------------------------------------
function relatorio_Callback(hObject, eventdata, handles)
% hObject    handle to relatorio (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%abrir o ficheiro pdf que contém o relatório da atividade
winopen('files/relatorio/Relatorio_Atividade02.pdf');


% --------------------------------------------------------------------
function help_Callback(hObject, eventdata, handles)
% hObject    handle to help (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function matlab_Callback(hObject, eventdata, handles)
% hObject    handle to matlab (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%abrir a página web de ajuda do Matlab
web('http://www.mathworks.com/products/matlab/examples.html?file=/products/demos/shipping/matlab/odedemo.html', '-browser')


% --------------------------------------------------------------------
function txt_interface_Callback(hObject, eventdata, handles)
% hObject    handle to txt_interface (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%chamada da função de verificação de saída
sair_Callback_2([], [], handles);


% --------------------------------------------------------------------
function options_Callback(hObject, eventdata, handles)
% hObject    handle to options (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function menu_Callback(hObject, eventdata, handles)
% hObject    handle to menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%chamada da função de verificação de saída
sair_Callback_3([], [], handles);



function func_g_Callback(hObject, eventdata, handles)
% hObject    handle to func_g (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of func_g as text
%        str2double(get(hObject,'String')) returns contents of func_g as a double


% --- Executes during object creation, after setting all properties.
function func_g_CreateFcn(hObject, eventdata, handles)
% hObject    handle to func_g (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function g0_Callback(hObject, eventdata, handles)
% hObject    handle to g0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of g0 as text
%        str2double(get(hObject,'String')) returns contents of g0 as a double


% --- Executes during object creation, after setting all properties.
function g0_CreateFcn(hObject, eventdata, handles)
% hObject    handle to g0 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function pdef_Callback(hObject, eventdata, handles)
% hObject    handle to pdef (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function ppendulo_Callback(hObject, eventdata, handles)
% hObject    handle to ppendulo (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.ppendulo,'Checked') == 0)
    set(handles.ppendulo,'Checked',1);
    set(handles.mmsa,'Checked',0);
    set(handles.mmca,'Checked',0);
    set(handles.vfa,'Checked',0);
    set(handles.rm,'Checked',0);
    set(handles.ppdef,'Value',1);
    
    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
    set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
    set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
    set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
    MyAtualizar(handles);
end


% --- Executes on selection change in ppdef.
function ppdef_Callback(hObject, eventdata, handles)
% hObject    handle to ppdef (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns ppdef contents as cell array
%        contents{get(hObject,'Value')} returns selected item from ppdef

switch(get(handles.ppdef,'Value'))
    case 1
        set(handles.ppendulo,'Checked',1);
        set(handles.mmsa,'Checked',0);
        set(handles.mmca,'Checked',0);
        set(handles.vfa,'Checked',0);
        set(handles.rm,'Checked',0);
        
        set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
        set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
        set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
        set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
        set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
        set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
        set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
        MyAtualizar(handles);
        
    case 2
        set(handles.ppendulo,'Checked',0);
        set(handles.mmsa,'Checked',1);
        set(handles.mmca,'Checked',0);
        set(handles.vfa,'Checked',0);
        set(handles.rm,'Checked',0);
        
        set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
        set(handles.func_g,'String','-16*u'); set(handles.func_g,'BackgroundColor','w');
        set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
        set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
        set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
        set(handles.f0,'String','9'); set(handles.f0,'BackgroundColor','w');
        set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
        MyAtualizar(handles);
        
    case 3
        set(handles.ppendulo,'Checked',0);
        set(handles.mmsa,'Checked',0);
        set(handles.mmca,'Checked',1);
        set(handles.vfa,'Checked',0);
        set(handles.rm,'Checked',0);
        
        set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
        set(handles.func_g,'String','-10*v-25*u'); set(handles.func_g,'BackgroundColor','w');
        set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
        set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
        set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
        set(handles.f0,'String','0'); set(handles.f0,'BackgroundColor','w');
        set(handles.g0,'String','-4'); set(handles.g0,'BackgroundColor','w');
        MyAtualizar(handles);
        
    case 4
        set(handles.ppendulo,'Checked',0);
        set(handles.mmsa,'Checked',0);
        set(handles.mmca,'Checked',0);
        set(handles.vfa,'Checked',1);
        set(handles.rm,'Checked',0);
        
        set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
        set(handles.func_g,'String','-(3/4)*v-(9/2)*u'); set(handles.func_g,'BackgroundColor','w');
        set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
        set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
        set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
        set(handles.f0,'String','1'); set(handles.f0,'BackgroundColor','w');
        set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
        MyAtualizar(handles);
    
    case 6
        set(handles.ppendulo,'Checked',0);
        set(handles.mmsa,'Checked',0);
        set(handles.mmca,'Checked',0);
        set(handles.vfa,'Checked',0);
        set(handles.rm,'Checked',0);
        
    otherwise
        set(handles.ppendulo,'Checked',1);
        set(handles.mmsa,'Checked',0);
        set(handles.mmca,'Checked',0);
        set(handles.vfa,'Checked',0);
        set(handles.rm,'Checked',0);
        
        errordlg('Método não implementado','ERRO','modal');
        set(handles.ppdef,'Value',1);
end

% --- Executes during object creation, after setting all properties.
function ppdef_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ppdef (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --------------------------------------------------------------------
function mmsa_Callback(hObject, eventdata, handles)
% hObject    handle to mmsa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.mmsa,'Checked') == 0)
    set(handles.func_f,'Enable','off');
    set(handles.mmsa,'Checked',1);
    set(handles.ppendulo,'Checked',0);
    set(handles.mmca,'Checked',0);
    set(handles.vfa,'Checked',0);
    set(handles.rm,'Checked',0);
    set(handles.ppdef,'Value',2);
    
    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
    set(handles.func_g,'String','-16*u'); set(handles.func_g,'BackgroundColor','w');
    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
    set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
    set(handles.f0,'String','9'); set(handles.f0,'BackgroundColor','w');
    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
end


% --------------------------------------------------------------------
function mmca_Callback(hObject, eventdata, handles)
% hObject    handle to mmca (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.mmca,'Checked') == 0)
    set(handles.func_f,'Enable','off');
    set(handles.mmca,'Checked',1);
    set(handles.ppendulo,'Checked',0);
    set(handles.mmsa,'Checked',0);
    set(handles.vfa,'Checked',0);
    set(handles.rm,'Checked',0);
    set(handles.ppdef,'Value',3);
    
    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
    set(handles.func_g,'String','-10*v-25*u'); set(handles.func_g,'BackgroundColor','w');
    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
    set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
    set(handles.f0,'String','0'); set(handles.f0,'BackgroundColor','w');
    set(handles.g0,'String','-4'); set(handles.g0,'BackgroundColor','w');
end


% --------------------------------------------------------------------
function vfa_Callback(hObject, eventdata, handles)
% hObject    handle to vfa (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(get(handles.vfa,'Checked') == 0)
    set(handles.func_f,'Enable','off');
    set(handles.vfa,'Checked',1);
    set(handles.ppendulo,'Checked',0);
    set(handles.mmsa,'Checked',0);
    set(handles.mmca,'Checked',0);
    set(handles.rm,'Checked',0);
    set(handles.ppdef,'Value',4);
    
    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
    set(handles.func_g,'String','-(3/4)*v-(9/2)*u'); set(handles.func_g,'BackgroundColor','w');
    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w'); 
    set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
    set(handles.f0,'String','1'); set(handles.f0,'BackgroundColor','w');
    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
end


% --------------------------------------------------------------------
function rm_Callback(hObject, eventdata, handles)
% hObject    handle to rm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function user_guide_Callback(hObject, eventdata, handles)
% hObject    handle to user_guide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
winopen('files/guia_utilizador/GuiaUtilizador.pdf');
