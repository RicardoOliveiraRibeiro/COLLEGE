%PROBLEMAPENDULO  Problema do p�ndulo
%
%INPUT:
%   f, g - fun��es do 2.� membro das Equa��es Diferenciais
%   [a, b] - extremos do intervalo da vari�vel independente t
%   n - n�mero de subintervalos ou itera��es do m�todo
%   u0, v0 - condi��es iniciais t=a -> u=u0 e v=v0
%CHAMADA DE FUN��ES: 
%   NEulerSED
%
%   27/03/2020 - Arm�nioCorreia .: armenioc@isec.pt

function ProblemaPendulo(f,g,a,b,n,u0,v0)
if ~nargin
    strF='v';
    f=@(t,u,v) eval(vectorize(strF));
    strG='-sin(u)-0.3*v';
    g=@(t,u,v) eval(vectorize(strG));   
    a=0;
    b=15;
    n=100;
    u0=pi/2;
    v0=0;
end
[t,u,v]=NEulerSED(f,g,a,b,n,u0,v0);
tabela=[t.',u.',v.'];
disp(tabela)
Filename='pendulo.xlsx';
xlswrite(Filename,tabela);
winopen(Filename)

plot(t,u,'r')
hold on
plot(t,v,'b')
hold off
grid on
legend('deslocamento','velocidade')







