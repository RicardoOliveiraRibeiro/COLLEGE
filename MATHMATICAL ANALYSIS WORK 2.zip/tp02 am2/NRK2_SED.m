%Trabalho elaborado por:
%Ricardo Ribeiro :2019130901
%João Cunha : 2019126187

%NRK2  Método de NRK2 para ED/PVI.
%   y = NRK2(f,a,b,n,y0) Método numérico para a resolução de um PVI
%   y'= f(t,y) com t=[a, b] e y(a)=y0 condição inicial  
%
%INPUT:
%   f - função do 2.º membro da Equação Diferencial
%   [a, b] - extremos do intervalo da variável independente t
%   n - número de subintervalos ou iterações do método
%   y0 - condição inicial t=a -> y=y0
%OUTPUT: 
%   y - vector das soluções aproximações
%   y(i+1) = y(i)+(1/2)*(k1+k2) , i =0,1,...,n-1
%

function [u,v] = NRK2_SED(f,g,a,b,n,u0,v0)
    h = (b-a)/n; %cálculo da distância h entre dois pontos num intervalo [a,b] com n sub-intervalos
    t = a:h:b; %vetor com valores de t num intervalo [a,b] com passo h
    u = zeros(1,n+1);
    v = zeros(1,n+1);
    u(1) = u0; %associar o valor u0 (condição inicial) a u(1) 
    v(1) = v0; %associar o valor v0 (condição inicial) a v(1)
    
    for i=1:n
        uk1 = f(t(i), u(i), v(i));
        vk1 = g(t(i), u(i), v(i));
        uk2 = f(t(i)+h, u(i)+h*uk1, v(i)+h*vk1);
        vk2 = g(t(i)+h, u(i)+h*uk1, v(i)+h*vk1);

        u(i+1) = u(i)+(h/2)*(uk1+uk2);
        v(i+1) = v(i)+(h/2)*(vk1+vk2);
    end
end