classdef GUI_App_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        figure1        matlab.ui.Figure
        pdef           matlab.ui.container.Menu
        ppendulo       matlab.ui.container.Menu
        mmsa           matlab.ui.container.Menu
        mmca           matlab.ui.container.Menu
        vfa            matlab.ui.container.Menu
        rm             matlab.ui.container.Menu
        sair           matlab.ui.container.Menu
        Func_Area      matlab.ui.container.Panel
        func_f         matlab.ui.control.EditField
        fty_texto      matlab.ui.control.Label
        a_text         matlab.ui.control.Label
        a              matlab.ui.control.EditField
        text4          matlab.ui.control.Label
        text5          matlab.ui.control.Label
        b              matlab.ui.control.EditField
        text_n         matlab.ui.control.Label
        f0             matlab.ui.control.EditField
        n              matlab.ui.control.EditField
        func_g         matlab.ui.control.EditField
        text9          matlab.ui.control.Label
        text10         matlab.ui.control.Label
        g0             matlab.ui.control.EditField
        metodosNum     matlab.ui.container.ButtonGroup
        rb_Euler       matlab.ui.control.RadioButton
        rb_EulerV2     matlab.ui.control.RadioButton
        rb_NRK2        matlab.ui.control.RadioButton
        rb_NRK4        matlab.ui.control.RadioButton
        rb_Todos       matlab.ui.control.RadioButton
        uiTabela       matlab.ui.control.Table
        uipanel3       matlab.ui.container.Panel
        ppdef          matlab.ui.control.DropDown
        btn_Atualizar  matlab.ui.control.Button
        reset_values   matlab.ui.control.Button
        graph          matlab.ui.control.UIAxes
    end

    
    methods (Access = private)
        function MyAtualizar(~, handles)
            
            set(handles.a,'BackgroundColor','w');
            
            strG=get(handles.func_g,'String');
            g   =@(t,u,v) eval(vectorize(strG));
            
            strF=get(handles.func_f,'String');
            f   =@(t,u,v) eval(vectorize(strF));
            
            app.a   = str2double(get(handles.a,'String'));
            app.b   = str2double(get(handles.b,'String'));
            app.n   = str2double(get(handles.n,'String'));
            app.f0  = str2double(get(handles.f0,'String'));
            app.g0  = str2double(get(handles.g0,'String'));
            finalError = {};
            
            escolhabg=get(handles.metodosNum,'SelectedObject');
            escolha=find([handles.rb_Euler,...
                          handles.rb_EulerV2,...
                          handles.rb_NRK2,...
                          handles.rb_NRK4,...
                          handles.rb_Todos]==escolhabg);
            EULER=1;
            EULERM=2;
            RK2=3;
            RK4=4;
            TODOS=5;
            
            try
                %Verificação das funções para ver se estas são válidas (funções em t, u e v)
                try
                    gTeste=g(sym('t'),sym('u'),sym('v'));
                catch
                    finalError = [finalError {'G tem de ser uma função em t, u e v'}];
                    set(handles.func_g,'BackgroundColor','r');
                end
            
                try
                    fTeste=f(sym('t'),sym('u'),sym('v'));
                catch
                    finalError = [finalError {'F tem de ser uma função em t, u e v'}];
                    set(handles.func_f,'BackgroundColor','r');
                end
                %--------------------------------------------------------------------
            
                %verificar se o valor introduzido é escalar e real (não complexo)
                if ~(isscalar(app.a) && isreal(app.a))
                    finalError = [finalError {'O valor de A tem de ser um número real'}];
                    set(handles.a,'BackgroundColor','r');
                end
                %---------------------------------------------------------------------
            
                %verificar se o valor introduzido é escalar e real (não complexo)
                if ~(isscalar(app.b) && isreal(app.b))
                    finalError = [finalError {'O valor de B tem de ser um número real'}];
                    set(handles.b,'BackgroundColor','r');
                end
                %----------------------------------------------------------------------
            
                %verificar se o valor de a é maior que b, se for dá erro pois o valor de
                %a tem de ser inferior ao valor de b
                if (app.a > app.b)
                    finalError = [finalError {'O valor de A tem de ser inferior a B'}];
                    set(handles.b,'BackgroundColor','r');
                    set(handles.a,'BackgroundColor','y');
                end
                %-----------------------------------------------------------------------
            
                %verificar se o valor introduzido é maior que zero, se for menor dá
                %erro pois não existem intervalos negativos.
                if ~(app.n > 0)
                    finalError = [finalError {'Valor de N inválido! Não podem existir intervalos negativos!'}];
                    set(handles.n,'BackgroundColor','r');
                end
                %------------------------------------------------------------------------
            
                %verificar se o valor introduzido é escalar e real (não complexo)
                if ~(isscalar(app.n) && isreal(app.n))
                    finalError = [finalError {'Valor de N inválido! N tem de ser um número real positivo.'}];
                    set(handles.n,'BackgroundColor','r');
                end
                %------------------------------------------------------------------------
            
                %verificar se o valor introduzido é um número inteiro
                if ~(app.n==round(app.n, 0)) %se o valor do campo for igual ao seu valor arredondado então n é inteiro
                    finalError = [finalError {'Valor de N inválido! Não existe um número decimal de sub-intervalos'}];
                    set(handles.n,'BackgroundColor','r');
                end
                %---------------------------------------------------------------------
            
                %verificar se o valor introduzido é escalar e real (não complexo)
                if ~(isscalar(app.f0) && isreal(app.f0))
                    finalError = [finalError {'Valor de f0 inválido! Tem de introduzir um valor real!'}];
                    set(handles.f0,'BackgroundColor','r');
                end
            
                if ~(isscalar(app.g0) && isreal(app.g0))
                    finalError = [finalError {'Valor de g0 inválido! Tem de introduzir um valor real!'}];
                    set(handles.g0,'BackgroundColor','r');
                end
                %----------------------------------------------------------------------
            
                %cálculo da distância h entre dois pontos num intervalo [a,b] com n sub-intervalos
                h = (app.b-app.a)/app.n;
            
                %Valores que t pode tomar num intervalo [a,b], com distância h
                t=app.a:h:app.b;
            
                set(handles.figure1,'CurrentAxes',handles.graph);
            
                %PROBLEMA DO PÊNDULO
                if (get(handles.ppdef,'Value')==1)
            
                    %caso haja algum erro, mostra todos os erros numa errordlg em vez de
                    %mostrar diversas mensagens de erro separadas
                    if ~isempty(finalError)
                        waitfor(errordlg(finalError,'ERRO','modal'));
                    end
                    %----------------------------------------------------------------------
            
                    switch (escolha)
                        case 1
                            [u,v]=NEulerSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            hold on
                            plot(t , v , 'r' , 'linewidth' , 2);
                            hold off
                            legend('Deslocamento','Velocidade');
                            tabela=[t.',u.',v.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Deslocamento'},{'Velocidade'}]);
            
                        case 2
                            [u,v]=NEuler_MSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            hold on
                            plot(t , v , 'r' , 'linewidth' , 2);
                            hold off
                            legend('Deslocamento','Velocidade');
                            tabela=[t.',u.',v.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Deslocamento'},{'Velocidade'}]);
            
                        case 3
                            [u,v] = NRK2_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            hold on
                            plot(t , v , 'r' , 'linewidth' , 2);
                            hold off
                            legend('Deslocamento','Velocidade');
                            tabela=[t.',u.',v.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Deslocamento'},{'Velocidade'}]);
            
                        case 4
                            [u,v] = NRK4_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            hold on
                            plot(t , v , 'r' , 'linewidth' , 2);
                            hold off
                            legend('Deslocamento','Velocidade');
                            tabela=[t.',u.',v.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Deslocamento'},{'Velocidade'}]);
            
                        case 5
                            [uE,vE] = NEulerSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
                            [uEM,vEM] = NEuler_MSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
                            [uRK2,vRK2] = NRK2_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
                            [uRK4,vRK4] = NRK4_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , uE , '-+' , 'linewidth' , 2, 'Color', [0.4660 0.6740 0.1880]);
                            hold on
                            plot(t , vE , '-*' , 'linewidth' , 2, 'Color', [0.4660 0.6740 0.1880]);
                            hold on
            
                            plot(t , uEM , '-+' , 'linewidth' , 2, 'Color', [0.6350 0.0780 0.1840]);
                            hold on
                            plot(t , vEM , '-*' , 'linewidth' , 2, 'Color', [0.6350 0.0780 0.1840]);
                            hold on
            
                            plot(t , uRK2 , '-b+' , 'linewidth' , 2);
                            hold on
                            plot(t , vRK2 , '-b*' , 'linewidth' , 2);
                            hold on
            
                            plot(t , uRK4 , '-+' , 'linewidth' , 2, 'color', [0.4940 0.1840 0.5560]);
                            hold on
                            plot(t , vRK4 , '-*' , 'linewidth' , 2, 'color', [0.4940 0.1840 0.5560]);
                            hold on
            
                            hold off
                            legend('Desloc. Euler','Vel. Euler','Desloc. EulerM','Vel. EulerM','Desloc. NRK2','Vel. NRK2','Desloc. NRK4','Vel. NRK4');
                            tabela=[t.',uE.',vE.',uEM.',vEM.',uRK2.',vRK2.',uRK4.',vRK4.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Desloc. Euler'},{'Vel. Euler'},{'Desloc. EulerM'},{'Vel. EulerM'},{'Desloc. NRK2'},{'Vel. NRK2'},{'Desloc. NRK4'},{'Vel. NRK4'}]);
                    end
                %----------------------------------------------------------------------
                %outros problemas
                else
                    %caso haja algum erro, mostra todos os erros numa errordlg em vez de
                    %mostrar diversas mensagens de erro separadas
                    if ~isempty(finalError)
                        waitfor(errordlg(finalError,'ERRO','modal'));
                    end
                    %----------------------------------------------------------------------
            
                    switch (escolha)
                        case 1
                            [u,~]=NEulerSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            legend('Euler');
                            tabela=[t.',u.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Euler'}]);
            
                        case 2
                            [u,~]=NEuler_MSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            legend('Euler Melhorado');
                            tabela=[t.',u.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Euler Melhorado'}]);
            
                        case 3
                            [u,~] = NRK2_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            legend('NRK2');
                            tabela=[t.',u.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'NRK2'}]);
            
                        case 4
                            [u,~] = NRK4_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , u , 'm' , 'linewidth' , 2);
                            legend('NRK4');
                            tabela=[t.',u.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'NRK4'}]);
            
                        case 5
                            [uE,~] = NEulerSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
                            [uEM,~] = NEuler_MSED(f,g,app.a,app.b,app.n,app.f0,app.g0);
                            [uRK2,~] = NRK2_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
                            [uRK4,~] = NRK4_SED(f,g,app.a,app.b,app.n,app.f0,app.g0);
            
                            plot(t , uE , '-+' , 'linewidth' , 2, 'Color', [0.4660 0.6740 0.1880]);
                            hold on
            
                            plot(t , uEM , '-+' , 'linewidth' , 2, 'Color', [0.6350 0.0780 0.1840]);
                            hold on
            
                            plot(t , uRK2 , '-b+' , 'linewidth' , 2);
                            hold on
            
                            plot(t , uRK4 , '-+' , 'linewidth' , 2, 'color', [0.4940 0.1840 0.5560]);
                            hold on
            
                            hold off
                            legend('Euler','Euler Melhorado','NRK2','NRK4');
                            tabela=[t.',uE.',uEM.',uRK2.',uRK4.'];
                            set(handles.uiTabela,'Data',num2cell(tabela));
                            set(handles.uiTabela,'ColumnName',...
                              [{'t'},{'Euler'},{'Euler Melhorado'},{'NRK2'},{'NRK4'}]);
                    end
                    %set(handles.func_f,'Enable','off');
                end
            
            
               
            
            catch Me
                errordlg(Me.message,'ERRO','modal');
            end
        end
        
        function legend_onoff_OffCallback(~, ~, ~, handles)
     
            
            %ativar a legenda do gráfico
            legend on; set(handles.legend_onoff, 'state',1);
        end
        
        function sair_Callback_2(~, ~, ~, handles)
 
            
            %função de verificação de saída
            op=questdlg('Tem a certeza que quer sair?','SAIR','Sim','Não','Sim');
            if strcmp(op,'Não')
                return;
            end
            delete(handles.figure1); Home(); a2019132875_a2019132858_AM2TP;
        end
        
        function sair_Callback_3(~, ~, ~, handles)
     
            
            %função de verificação de saída
            op=questdlg('Tem a certeza que quer sair?','SAIR','Sim','Não','Sim');
            if strcmp(op,'Não')
                return;
            end
            delete(handles.figure1); Home();
        end
        
        function txt_interface_Callback(app, ~, ~, handles)
     
            
            %chamada da função de verificação de saída
            sair_Callback_2(app, [], [], handles);
        end
        
        function value_h_CreateFcn(~, hObject, ~, ~)
          
            
            % Hint: edit controls usually have a white background on Windows.
            %       See ISPC and COMPUTER.
            if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
                set(hObject,'BackgroundColor','white');
            end
        end
        
        function resetInteractions(app, event)
           
            interactiveTools = [app.lupa_zoom, app.uitoggletool3, app.uitoggletool2, app.uitoggletool4];
            interactiveTools(event.Source == interactiveTools) = [];
             
            % Set the state of the tools to 'off'.
            [interactiveTools.State] = deal('off');
             
            % Set figure interactions to 'off'.
            datacursormode(app.figure1, 'off')
            rotate3d(app.figure1, 'off');
            pan(app.figure1, 'off');
            zoom(app.figure1,'off');
        end
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Code that executes after component creation
        function GUI_OpeningFcn(app, varargin)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app); %#ok<ASGLU>
            
           
            
            % Choose default command line output for GUI
            handles.output = hObject;
            
            % Update handles structure
            guidata(hObject, handles);
            MyAtualizar(app, handles);
            
            grid on;
            
            
           
        end

        % Value changed function: a
        function a_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to a (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of a as text
            %        str2double(get(hObject,'String')) returns contents of a as a double
            set(handles.a,'BackgroundColor','w');
        end

        % Value changed function: b
        function b_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to b (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of b as text
            %        str2double(get(hObject,'String')) returns contents of b as a double
            set(handles.b,'BackgroundColor','w');
        end

        % Button pushed function: btn_Atualizar
        function btn_Atualizar_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to btn_Atualizar (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            MyAtualizar(app, handles);
        end

        % Value changed function: f0
        function f0_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to f0 (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of f0 as text
            %        str2double(get(hObject,'String')) returns contents of f0 as a double
            set(handles.f0,'BackgroundColor','w');
        end

        % Close request function: figure1
        function figure1_CloseRequestFcn(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to figureMaquinaEDO1 (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hint: delete(hObject) closes the figure
            %delete(hObject);
            
            %chamada da função de verificação de saída
%             sair_Callback([], [], handles);
        end

        % Value changed function: func_f
        function func_f_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to func_f (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of func_f as text
            %        str2double(get(hObject,'String')) returns contents of func_f as a double
            set(handles.func_f,'BackgroundColor','w');
        end

        % Callback function
        function matlab_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to matlab (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            %abrir a página web de ajuda do Matlab
            web('http://www.mathworks.com/products/matlab/examples.html?file=/products/demos/shipping/matlab/odedemo.html', '-browser')
        end

        % Callback function
        function menu_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to menu (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            %chamada da função de verificação de saída
            sair_Callback_3(app, [], [], handles);
        end

        % Menu selected function: mmca
        function mmca_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to mmca (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            if(get(handles.mmca,'Checked') == 0)
                set(handles.func_f,'Enable','off');
                set(handles.mmca,'Checked',1);
                set(handles.ppendulo,'Checked',0);
                set(handles.mmsa,'Checked',0);
                set(handles.vfa,'Checked',0);
                set(handles.rm,'Checked',0);
                set(handles.ppdef,'Value',3);
            
                set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                set(handles.func_g,'String','-10*v-25*u'); set(handles.func_g,'BackgroundColor','w');
                set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
                set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                set(handles.f0,'String','0'); set(handles.f0,'BackgroundColor','w');
                set(handles.g0,'String','-4'); set(handles.g0,'BackgroundColor','w');
            end
        end

        % Menu selected function: mmsa
        function mmsa_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to mmsa (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            if(get(handles.mmsa,'Checked') == 0)
                set(handles.func_f,'Enable','off');
                set(handles.mmsa,'Checked',1);
                set(handles.ppendulo,'Checked',0);
                set(handles.mmca,'Checked',0);
                set(handles.vfa,'Checked',0);
                set(handles.rm,'Checked',0);
                set(handles.ppdef,'Value',2);
            
                set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                set(handles.func_g,'String','-16*u'); set(handles.func_g,'BackgroundColor','w');
                set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
                set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                set(handles.f0,'String','9'); set(handles.f0,'BackgroundColor','w');
                set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
            end
        end

        % Value changed function: n
        function n_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to n (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: get(hObject,'String') returns contents of n as text
            %        str2double(get(hObject,'String')) returns contents of n as a double
            set(handles.n,'BackgroundColor','w');
        end

        % Value changed function: ppdef
        function ppdef_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to ppdef (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            % Hints: contents = cellstr(get(hObject,'String')) returns ppdef contents as cell array
            %        contents{get(hObject,'Value')} returns selected item from ppdef
            
            switch(get(handles.ppdef,'Value'))
                case 1
                    set(handles.ppendulo,'Checked',1);
                    set(handles.mmsa,'Checked',0);
                    set(handles.mmca,'Checked',0);
                    set(handles.vfa,'Checked',0);
                    set(handles.rm,'Checked',0);
            
                    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                    set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
                    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                    set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
                    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                    set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
                    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
                    MyAtualizar(app, handles);
            
                case 2
                    set(handles.ppendulo,'Checked',0);
                    set(handles.mmsa,'Checked',1);
                    set(handles.mmca,'Checked',0);
                    set(handles.vfa,'Checked',0);
                    set(handles.rm,'Checked',0);
            
                    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                    set(handles.func_g,'String','-16*u'); set(handles.func_g,'BackgroundColor','w');
                    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                    set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
                    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                    set(handles.f0,'String','9'); set(handles.f0,'BackgroundColor','w');
                    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
                    MyAtualizar(app, handles);
            
                case 3
                    set(handles.ppendulo,'Checked',0);
                    set(handles.mmsa,'Checked',0);
                    set(handles.mmca,'Checked',1);
                    set(handles.vfa,'Checked',0);
                    set(handles.rm,'Checked',0);
            
                    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                    set(handles.func_g,'String','-10*v-25*u'); set(handles.func_g,'BackgroundColor','w');
                    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                    set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
                    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                    set(handles.f0,'String','0'); set(handles.f0,'BackgroundColor','w');
                    set(handles.g0,'String','-4'); set(handles.g0,'BackgroundColor','w');
                    MyAtualizar(app, handles);
            
                case 4
                    set(handles.ppendulo,'Checked',0);
                    set(handles.mmsa,'Checked',0);
                    set(handles.mmca,'Checked',0);
                    set(handles.vfa,'Checked',1);
                    set(handles.rm,'Checked',0);
            
                    set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                    set(handles.func_g,'String','-(3/4)*v-(9/2)*u'); set(handles.func_g,'BackgroundColor','w');
                    set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                    set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
                    set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                    set(handles.f0,'String','1'); set(handles.f0,'BackgroundColor','w');
                    set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
                    MyAtualizar(app, handles);
            
                case 6
                    set(handles.ppendulo,'Checked',0);
                    set(handles.mmsa,'Checked',0);
                    set(handles.mmca,'Checked',0);
                    set(handles.vfa,'Checked',0);
                    set(handles.rm,'Checked',0);
            
                otherwise
                    set(handles.ppendulo,'Checked',1);
                    set(handles.mmsa,'Checked',0);
                    set(handles.mmca,'Checked',0);
                    set(handles.vfa,'Checked',0);
                    set(handles.rm,'Checked',0);
            
                    errordlg('Método não implementado','ERRO','modal');
                    set(handles.ppdef,'Value',1);
            end
        end

        % Menu selected function: ppendulo
        function ppendulo_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to ppendulo (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            if(get(handles.ppendulo,'Checked') == 0)
                set(handles.ppendulo,'Checked',1);
                set(handles.mmsa,'Checked',0);
                set(handles.mmca,'Checked',0);
                set(handles.vfa,'Checked',0);
                set(handles.rm,'Checked',0);
                set(handles.ppdef,'Value',1);
            
                set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
                set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
                set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
                set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
                MyAtualizar(app, handles);
            end
        end

        % Button pushed function: reset_values
        function reset_values_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to reset_values (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            %reset dos valores e propriedades ao clicar no botão de reset
            if(get(handles.ppendulo,'Checked') == 1)
                set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
                set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
                set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
                set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
            
            else
                set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                set(handles.func_g,'String','-sin(u)-0.3*v'); set(handles.func_g,'BackgroundColor','w');
                set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                set(handles.b,'String','15'); set(handles.b,'BackgroundColor','w');
                set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                set(handles.f0,'String','pi/2'); set(handles.f0,'BackgroundColor','w');
                set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
            
                questdlg('Foram colocados por defeito os valores correspondentes ao Problema do Pêndulo','RESET GUI','Ok','Ok');
            
                set(handles.ppendulo,'Checked',1);
                set(handles.mmsa,'Checked',0);
                set(handles.mmca,'Checked',0);
                set(handles.vfa,'Checked',0);
                set(handles.rm,'Checked',0);
            
                set(handles.ppdef,'Value',1);
            end
            
            set(handles.metodosNum , 'SelectedObject' , '');
            
            set(handles.rb_Euler , 'value' , 1);
            
            MyAtualizar(app, handles);
        end

        % Menu selected function: sair
        function sair_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to sair (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            
            %função de verificação de saída
            op=questdlg('Tem a certeza que quer sair?','SAIR','Sim','Não','Sim');
            if strcmp(op,'Não')
                return;
            end
            delete(handles.figure1);
        end

        % Menu selected function: vfa
        function vfa_Callback(app, event)
            % Create GUIDE-style callback args - Added by Migration Tool
            [hObject, eventdata, handles] = convertToGUIDECallbackArguments(app, event); %#ok<ASGLU>
            
            % hObject    handle to vfa (see GCBO)
            % eventdata  reserved - to be defined in a future version of MATLAB
            % handles    structure with handles and user data (see GUIDATA)
            if(get(handles.vfa,'Checked') == 0)
                set(handles.func_f,'Enable','off');
                set(handles.vfa,'Checked',1);
                set(handles.ppendulo,'Checked',0);
                set(handles.mmsa,'Checked',0);
                set(handles.mmca,'Checked',0);
                set(handles.rm,'Checked',0);
                set(handles.ppdef,'Value',4);
            
                set(handles.func_f,'String','v'); set(handles.func_f,'BackgroundColor','w');
                set(handles.func_g,'String','-(3/4)*v-(9/2)*u'); set(handles.func_g,'BackgroundColor','w');
                set(handles.a,'String','0'); set(handles.a,'BackgroundColor','w');
                set(handles.b,'String','5'); set(handles.b,'BackgroundColor','w');
                set(handles.n,'String','100'); set(handles.n,'BackgroundColor','w');
                set(handles.f0,'String','1'); set(handles.f0,'BackgroundColor','w');
                set(handles.g0,'String','0'); set(handles.g0,'BackgroundColor','w');
            end
        end

        % Callback function
        function uitoggletool4_ClickedCallback(app, event)
            % Reset the states of interactive tools and reset all figure
            % interactions.
            app.resetInteractions(event);
             
            % Enable or disable rotation based on the
            % tool's current state.
            state = app.uitoggletool4.State;
            rotate3d(app.figure1, char(state));
        end

        % Callback function
        function uitoggletool2_ClickedCallback(app, event)
            % Reset the states of interactive tools and reset all figure
            % interactions.
            app.resetInteractions(event);
             
            % Enable or disable pan based on the
            % tool's current state.
            state = app.uitoggletool2.State;
            pan(app.figure1, char(state));
        end

        % Callback function
        function uitoggletool3_ClickedCallback(app, event)
            % Reset the states of interactive tools and reset all figure
            % interactions.
            app.resetInteractions(event);
             
            % Enable or disable zoom-out based on the
            % tool's current state.
            state = app.uitoggletool3.State;
            zoomModeObject = zoom(app.figure1);
            if state
                zoomModeObject.Direction = 'out';
                zoomModeObject.Enable = 'on';
            else
                zoomModeObject.Enable = 'off';
            end
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create figure1 and hide until all components are created
            app.figure1 = uifigure('Visible', 'off');
            app.figure1.Color = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.figure1.Position = [684 269 1370 701];
            app.figure1.Name = 'Interface Gráfica by Ricardo Ribeiro e João Cunha';
            app.figure1.CloseRequestFcn = createCallbackFcn(app, @figure1_CloseRequestFcn, true);
            app.figure1.HandleVisibility = 'callback';
            app.figure1.Tag = 'figure1';

            % Create pdef
            app.pdef = uimenu(app.figure1);
            app.pdef.Text = 'Problemas Pré-definidos';
            app.pdef.Tag = 'pdef';

            % Create ppendulo
            app.ppendulo = uimenu(app.pdef);
            app.ppendulo.MenuSelectedFcn = createCallbackFcn(app, @ppendulo_Callback, true);
            app.ppendulo.Text = 'Problema do Pêndulo';
            app.ppendulo.Tag = 'ppendulo';

            % Create mmsa
            app.mmsa = uimenu(app.pdef);
            app.mmsa.MenuSelectedFcn = createCallbackFcn(app, @mmsa_Callback, true);
            app.mmsa.Text = 'Sistema Mola-Massa S/ Amortecimento';
            app.mmsa.Tag = 'mmsa';

            % Create mmca
            app.mmca = uimenu(app.pdef);
            app.mmca.MenuSelectedFcn = createCallbackFcn(app, @mmca_Callback, true);
            app.mmca.Text = 'Sistema Mola-Massa C/ Amortecimento';
            app.mmca.Tag = 'mmca';

            % Create vfa
            app.vfa = uimenu(app.pdef);
            app.vfa.MenuSelectedFcn = createCallbackFcn(app, @vfa_Callback, true);
            app.vfa.Text = 'Circuito elétrico';
            app.vfa.Tag = 'vfa';

            % Create rm
            app.rm = uimenu(app.pdef);
            app.rm.Enable = 'off';
            app.rm.Text = 'Ressonância Mecânica ';
            app.rm.Tag = 'rm';

            % Create sair
            app.sair = uimenu(app.figure1);
            app.sair.MenuSelectedFcn = createCallbackFcn(app, @sair_Callback, true);
            app.sair.Text = 'Sair';
            app.sair.Tag = 'sair';

            % Create Func_Area
            app.Func_Area = uipanel(app.figure1);
            app.Func_Area.Title = 'Dados da Função';
            app.Func_Area.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.Func_Area.Tag = 'Func_Area';
            app.Func_Area.FontSize = 11;
            app.Func_Area.Position = [1040 225 301 462];

            % Create func_f
            app.func_f = uieditfield(app.Func_Area, 'text');
            app.func_f.ValueChangedFcn = createCallbackFcn(app, @func_f_Callback, true);
            app.func_f.Tag = 'func_f';
            app.func_f.HorizontalAlignment = 'center';
            app.func_f.FontSize = 16;
            app.func_f.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.func_f.Position = [100 402 193 39];
            app.func_f.Value = 'v';

            % Create fty_texto
            app.fty_texto = uilabel(app.Func_Area);
            app.fty_texto.Tag = 'fty_texto';
            app.fty_texto.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.fty_texto.VerticalAlignment = 'top';
            app.fty_texto.WordWrap = 'on';
            app.fty_texto.FontSize = 16;
            app.fty_texto.Position = [26 411 68 21];
            app.fty_texto.Text = 'F(t,u,v) =';

            % Create a_text
            app.a_text = uilabel(app.Func_Area);
            app.a_text.Tag = 'a_text';
            app.a_text.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.a_text.HorizontalAlignment = 'center';
            app.a_text.VerticalAlignment = 'top';
            app.a_text.WordWrap = 'on';
            app.a_text.FontSize = 16;
            app.a_text.Position = [42 296 74 37];
            app.a_text.Text = 'A';

            % Create a
            app.a = uieditfield(app.Func_Area, 'text');
            app.a.ValueChangedFcn = createCallbackFcn(app, @a_Callback, true);
            app.a.Tag = 'a';
            app.a.HorizontalAlignment = 'center';
            app.a.FontSize = 21;
            app.a.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.a.Position = [41 271 78 39];
            app.a.Value = '0';

            % Create text4
            app.text4 = uilabel(app.Func_Area);
            app.text4.Tag = 'text4';
            app.text4.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.text4.HorizontalAlignment = 'center';
            app.text4.VerticalAlignment = 'top';
            app.text4.WordWrap = 'on';
            app.text4.FontSize = 16;
            app.text4.Position = [178 296 72 37];
            app.text4.Text = 'B';

            % Create text5
            app.text5 = uilabel(app.Func_Area);
            app.text5.Tag = 'text5';
            app.text5.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.text5.HorizontalAlignment = 'center';
            app.text5.VerticalAlignment = 'top';
            app.text5.WordWrap = 'on';
            app.text5.FontSize = 16;
            app.text5.Position = [41 169 73 44];
            app.text5.Text = 'F(a)';

            % Create b
            app.b = uieditfield(app.Func_Area, 'text');
            app.b.ValueChangedFcn = createCallbackFcn(app, @b_Callback, true);
            app.b.Interruptible = 'off';
            app.b.Tag = 'b';
            app.b.HorizontalAlignment = 'center';
            app.b.FontSize = 21;
            app.b.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.b.Position = [177 271 78 39];
            app.b.Value = '15';

            % Create text_n
            app.text_n = uilabel(app.Func_Area);
            app.text_n.Tag = 'text_n';
            app.text_n.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.text_n.HorizontalAlignment = 'center';
            app.text_n.VerticalAlignment = 'top';
            app.text_n.WordWrap = 'on';
            app.text_n.FontSize = 19;
            app.text_n.Position = [81 82 116 42];
            app.text_n.Text = 'Valor de N';

            % Create f0
            app.f0 = uieditfield(app.Func_Area, 'text');
            app.f0.ValueChangedFcn = createCallbackFcn(app, @f0_Callback, true);
            app.f0.Tag = 'f0';
            app.f0.HorizontalAlignment = 'center';
            app.f0.FontSize = 21;
            app.f0.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.f0.Position = [40 149 78 39];
            app.f0.Value = 'pi/2';

            % Create n
            app.n = uieditfield(app.Func_Area, 'text');
            app.n.ValueChangedFcn = createCallbackFcn(app, @n_Callback, true);
            app.n.Tag = 'n';
            app.n.HorizontalAlignment = 'center';
            app.n.FontSize = 21;
            app.n.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.n.Position = [79 64 119 33];
            app.n.Value = '100';

            % Create func_g
            app.func_g = uieditfield(app.Func_Area, 'text');
            app.func_g.Tag = 'func_g';
            app.func_g.HorizontalAlignment = 'center';
            app.func_g.FontSize = 16;
            app.func_g.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.func_g.Position = [100 353 193 39];
            app.func_g.Value = '-sin(u)-0.3*v';

            % Create text9
            app.text9 = uilabel(app.Func_Area);
            app.text9.Tag = 'text9';
            app.text9.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.text9.VerticalAlignment = 'top';
            app.text9.WordWrap = 'on';
            app.text9.FontSize = 16;
            app.text9.Position = [26 362 68 21];
            app.text9.Text = 'G(t,u,v) =';

            % Create text10
            app.text10 = uilabel(app.Func_Area);
            app.text10.Tag = 'text10';
            app.text10.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.text10.HorizontalAlignment = 'center';
            app.text10.VerticalAlignment = 'top';
            app.text10.WordWrap = 'on';
            app.text10.FontSize = 16;
            app.text10.Position = [178 170 73 43];
            app.text10.Text = 'G(a)';

            % Create g0
            app.g0 = uieditfield(app.Func_Area, 'text');
            app.g0.Tag = 'g0';
            app.g0.HorizontalAlignment = 'center';
            app.g0.FontSize = 21;
            app.g0.BackgroundColor = [0.941176470588235 0.941176470588235 0.941176470588235];
            app.g0.Position = [177 150 78 39];
            app.g0.Value = '0';

            % Create metodosNum
            app.metodosNum = uibuttongroup(app.figure1);
            app.metodosNum.Title = 'Métodos Numéricos';
            app.metodosNum.BackgroundColor = [0.956862745098039 0.956862745098039 0.956862745098039];
            app.metodosNum.Tag = 'metodosNum';
            app.metodosNum.FontSize = 11;
            app.metodosNum.Position = [32 285 250 311];

            % Create rb_Euler
            app.rb_Euler = uiradiobutton(app.metodosNum);
            app.rb_Euler.Tag = 'rb_Euler';
            app.rb_Euler.Text = 'Método de Euler';
            app.rb_Euler.FontSize = 16;
            app.rb_Euler.Position = [15 253 146 27];
            app.rb_Euler.Value = true;

            % Create rb_EulerV2
            app.rb_EulerV2 = uiradiobutton(app.metodosNum);
            app.rb_EulerV2.Tag = 'rb_EulerV2';
            app.rb_EulerV2.Text = 'Método de Euler Melhorado';
            app.rb_EulerV2.FontSize = 16;
            app.rb_EulerV2.Position = [14 194 224 27];

            % Create rb_NRK2
            app.rb_NRK2 = uiradiobutton(app.metodosNum);
            app.rb_NRK2.Tag = 'rb_NRK2';
            app.rb_NRK2.Text = 'Método Runge-Kutta 2';
            app.rb_NRK2.FontSize = 16;
            app.rb_NRK2.Position = [15 136 186 27];

            % Create rb_NRK4
            app.rb_NRK4 = uiradiobutton(app.metodosNum);
            app.rb_NRK4.Tag = 'rb_NRK4';
            app.rb_NRK4.Text = 'Método Runge-Kutta 4';
            app.rb_NRK4.FontSize = 16;
            app.rb_NRK4.Position = [15 76 186 27];

            % Create rb_Todos
            app.rb_Todos = uiradiobutton(app.metodosNum);
            app.rb_Todos.Tag = 'rb_Todos';
            app.rb_Todos.Text = 'Todos';
            app.rb_Todos.FontSize = 16;
            app.rb_Todos.Position = [15 18 146 27];

            % Create uiTabela
            app.uiTabela = uitable(app.figure1);
            app.uiTabela.Tag = 'uiTabela';
            app.uiTabela.FontSize = 11;
            app.uiTabela.Position = [32 11 1296 195];

            % Create uipanel3
            app.uipanel3 = uipanel(app.figure1);
            app.uipanel3.Title = 'Problemas Pré-definidos';
            app.uipanel3.Tag = 'uipanel3';
            app.uipanel3.FontSize = 11;
            app.uipanel3.Position = [31 601 251 88];

            % Create ppdef
            app.ppdef = uidropdown(app.uipanel3);
            app.ppdef.Items = {'Problema do Pêndulo', 'Sistema Mola-Massa S/ Amortecimento', 'Sistema Mola-Massa C/ Amortecimento', 'Circuito elétrico', 'Ressonância Mecânica', 'Selecione uma das opções'};
            app.ppdef.ValueChangedFcn = createCallbackFcn(app, @ppdef_Callback, true);
            app.ppdef.Tag = 'ppdef';
            app.ppdef.FontSize = 16;
            app.ppdef.BackgroundColor = [1 1 1];
            app.ppdef.Position = [15 18 219 35];
            app.ppdef.Value = 'Problema do Pêndulo';

            % Create btn_Atualizar
            app.btn_Atualizar = uibutton(app.figure1, 'push');
            app.btn_Atualizar.ButtonPushedFcn = createCallbackFcn(app, @btn_Atualizar_Callback, true);
            app.btn_Atualizar.Tag = 'btn_Atualizar';
            app.btn_Atualizar.BackgroundColor = [1 1 1];
            app.btn_Atualizar.FontSize = 19;
            app.btn_Atualizar.Position = [30 229 122 46];
            app.btn_Atualizar.Text = 'Atualizar';

            % Create reset_values
            app.reset_values = uibutton(app.figure1, 'push');
            app.reset_values.ButtonPushedFcn = createCallbackFcn(app, @reset_values_Callback, true);
            app.reset_values.Tag = 'reset_values';
            app.reset_values.BackgroundColor = [1 1 1];
            app.reset_values.FontSize = 19;
            app.reset_values.Position = [184 229 98 46];
            app.reset_values.Text = 'Reset';

            % Create graph
            app.graph = uiaxes(app.figure1);
            app.graph.FontSize = 13;
            app.graph.GridColor = [0.301960784313725 0.745098039215686 0.933333333333333];
            app.graph.NextPlot = 'replace';
            app.graph.Tag = 'graph';
            app.graph.Position = [299 223 716 466];

            % Show the figure after all components are created
            app.figure1.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = GUI_App_exported(varargin)

            runningApp = getRunningApp(app);

            % Check for running singleton app
            if isempty(runningApp)

                % Create UIFigure and components
                createComponents(app)

                % Register the app with App Designer
                registerApp(app, app.figure1)

                % Execute the startup function
                runStartupFcn(app, @(app)GUI_OpeningFcn(app, varargin{:}))
            else

                % Focus the running singleton app
                figure(runningApp.figure1)

                app = runningApp;
            end

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.figure1)
        end
    end
end