% DerivadaExata Deriva��o Anal�tica
% Deriva��o Anal�tica pela fun��o diff
% 
% INPUT:  strF - fun��o f em formato string
%
% OUTPUT: h - derivada exata da fun�ao f
% 
% --- 16/06/2021  Ricardo Ribeiro 2019130901 
% --- 16/06/2021  Jo�o Cunha 2019126187 
%%

function f = DerivadaExata(strF)

syms x                                      % cria a vari�vel simb�lica x
h = @(x) eval(vectorize(strF));

f = matlabFunction(diff(h(x)));             % Calcula, atrav�s da fun��o diff, a derivada exata