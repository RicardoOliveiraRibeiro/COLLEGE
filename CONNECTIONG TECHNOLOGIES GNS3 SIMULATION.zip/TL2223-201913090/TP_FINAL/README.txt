Project: 'FINAL PROJECT V18' created on 2023-01-05
Author: Ricardo Ribeiro <a2019130901@isec.pt>

Just in case :)