//
// Created by BigRic3D on 06/01/2022.
//
#include "trabalhador.h"
#include <string>
#include <time.h>

#include <iostream>
using namespace std;

trabalhador::trabalhador(string tipo, int custo, int id, int dia_contratado, int probDemissao){
    _tipo=tipo;
    _custo=custo;
    _id=id;
    _dia_contratado=dia_contratado;
    _dias=0;
    _probDemissao=probDemissao;
}
int trabalhador::returnId() {
    return _id;
}
string trabalhador::returnTipo() {
    return _tipo;
}
int trabalhador::returnProbDemiss() {
    return _probDemissao;
}
int trabalhador::returnDias(){
    return _dias;
}
int trabalhador::return_dia_contratado(){
    return _dia_contratado;
}
int trabalhador::returnCusto(){
    return _custo;
}
void trabalhador::ApresentaTrabalhador(){
    cout << "ID: " << _id << "\n" << "TIPO: " << _tipo << "\n" << "--------" << "\n";
}
bool trabalhador::demissao(int incProbDemissao){
    srand(time(NULL));
    int prob=rand() % 100 + 1;
    if(prob<=_probDemissao+incProbDemissao){return true;}
    else{return false;}
}

void trabalhador::baixaProbDemissao(){
    if(_probDemissao>0){
        _probDemissao=_probDemissao-1;
    }
}

operario::operario(string tipo, int custo, int id, int dia_contratado, int probDemissao): trabalhador(tipo,custo,id,dia_contratado,probDemissao) {
    _dia_de_demissao=10;
}
lenhador::lenhador(string tipo, int custo, int id, int dia_contratado, int probDemissao): trabalhador(tipo,custo,id,dia_contratado,probDemissao) {
    _descanso=0;
    }
mineiro::mineiro(string tipo, int custo, int id, int dia_contratado, int probDemissao): trabalhador(tipo,custo,id,dia_contratado,probDemissao){
    _dia_de_demissao=2;
}