//
// Created by BigRic3D on 26/12/2021.
//
#include <string>


class zona;
class ilha;

using namespace std;
#ifndef ILHA_CPP_EDIFICIO_H
#define ILHA_CPP_EDIFICIO_H
class edificio{
string _tipo;
//int _preco_venda;
bool _estado;
int _nivel;
public:
    edificio(string tipo,int preco_venda);
    string devolveTipo();
    void desligaED();
    void ligaED();
    bool returnEstado();
    //float returnPreco_venda();
    int returnNivel();
    void incNivel();
    virtual void recolhaRecursos(int nTrab,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual)=0;
    virtual void incEletricidadeNaBateria();
    virtual float * returnPtrCarvao();
    virtual float * returnPtrFerro();
    virtual int* returnPtrVigas();
    virtual int* returnPTRaco();
    virtual int* returnPTReletr();
    virtual void convertToMoney(ilha* ILHATUAL)=0;
    ~edificio();


};

class minaf:public edificio{
    float _ferro;
    //int _probDesabar;
public:
    minaf(string tipo,int preco_venda);
    void recolhaRecursos(int nMineiros,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual);
    float* returnPtrFerro();
    ~minaf();
    void convertToMoney(ilha* ILHATUAL);
};

class minac:public edificio{
    float _carvao;
    //int _probDesabar;
public:
    minac(string tipo,int preco_venda);
    void recolhaRecursos(int nMineiros,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual);
    float* returnPtrCarvao();
    ~minac();
    void convertToMoney(ilha* ILHATUAL);
};

class central:public edificio{
    float _carvao;
public:
    central(string tipo,int preco_venda);
    void recolhaRecursos(int nOperarios,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual);
    float* returnPtrCarvao();
    ~central();
    void convertToMoney(ilha* ILHATUAL);
};

class bat:public edificio{
    int _eletricidade;
public:
    bat(string tipo,int preco_venda);
    void recolhaRecursos(int zero,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual);
    void incEletricidadeNaBateria();
    int* returnPTReletr();
    ~bat();
    void convertToMoney(ilha* ILHATUAL);
};

class fund:public edificio{
    int _aco;
public:
    fund(string tipo,int preco_venda);
    void recolhaRecursos(int nOperarios,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual);
    int* returnPTRaco();
    ~fund();
    void convertToMoney(ilha* ILHATUAL);
};

class znz:public edificio{
    int _vigas;
public:
    znz(string tipo,int preco_venda);
    void recolhaRecursos(int nLenhadores,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual);
    int* returnPtrVigas();
    ~znz();
    void convertToMoney(ilha* ILHATUAL);
};

#endif //ILHA_CPP_EDIFICIO_H
