//
// Created by BigRic3D on 13/12/2021.
//

#include <iostream>
#include "zona.h"
#include <vector>
#include "edificio.h"
using namespace std;

#ifndef TP02_ILHA_H
#define TP02_ILHA_H
class ilha{
    float _dinheiro;
    int _linhas ;
    int _colunas;
    zona** arraydezonas;
    int _dias;
    int _count_trabalhador_id;
public:
    ilha(int linha, int coluna);
    void apresentaIlha();
    int returnLinhaTotal();
    int returnColunaTotal();
    void constroiED(string tipo, int linha, int coluna);
    void contratarTrabalhador(string tipo,int dias,int id);
    void updateIdTrab(){_count_trabalhador_id++;}
    int returnIdTrab(){return _count_trabalhador_id;}
    int returnDias(){return _dias;}
    void addDinheiro(int montante){_dinheiro=_dinheiro+montante;}
    void decDinheiro(int montante){_dinheiro=_dinheiro-montante;}
    void incDias(){_dias++;}
    void ligaED(int linha, int coluna){arraydezonas[(linha-1)*(_colunas+1)+(coluna-1)]->ligaED();}
    void desligaED(int linha, int coluna){arraydezonas[(linha-1)*(_colunas+1)+(coluna-1)]->desligaED();}
    float returnDinheiro(){return _dinheiro;}
    void recolhaRecursos();
    void efeitosZonas();
    void apresentaZona(int linha, int coluna);
    int moveTrabalhador(int ID, int linha, int coluna);
    zona** returnArrayDeZonas(){return arraydezonas;}
    void apagaTrabalhador(int ID);
    int upgradeED(int linhas, int colunas);



};
#endif //TP02_ILHA_H
