//
// Created by BigRic3D on 13/12/2021.
//

#include "ilha.h"
#include <string>
#include <vector>

#include <iostream>

ilha::ilha(int linha, int coluna) {
    _linhas = linha - 1;
    _colunas = coluna - 1;
    _dias = 0;
    _count_trabalhador_id = 0;
    _dinheiro=100;

    //-----------------------------------------------------
    /*
    vetordezonas.clear();

    int k = 0;
    int randIndex;
    const string arrayTipos[6] = {"mnt ", "dsr ", "pas ", "flr ", "pnt ", "znz "};
    for (int i = 0; i <= this->_linhas; i++) {
        for (int j = 0; j <= this->_colunas; j++) {
            if (k <= 5) {
                //zona aux(arrayTipos[k],i,j);  // construtor
                vetordezonas.push_back(zona(arrayTipos[k], i, j));
                k++;
            } else {
                int p = rand() % 5 + 0;
                //zona aux(arrayTipos[randIndex], i, j);
                //this->vetordezonas.push_back(aux);
                vetordezonas.push_back(zona(arrayTipos[p], i, j));
            }
        }
    }
     */
//----------------------------------------------------------------------------------


    srand(time(NULL));
    arraydezonas=new zona*[linha*coluna];
    for(int i=0;i<=5;i++) {
        switch (i) {
            case 0: {
                arraydezonas[i]=(new mnt("mnt "));
                break;
            }
            case 1: {
                arraydezonas[i]=(new dsr("dsr "));
                break;
            }
            case 2:{
                arraydezonas[i]=(new pas("pas "));
                break;
            }
            case 3:{
                arraydezonas[i]=(new flr("flr "));
                break;
            }
            case 4:{
                arraydezonas[i]=(new pnt("pnt "));
                break;
            }
            case 5:{
                arraydezonas[i]=(new Zznz("znz "));
                break;
            }
        }
    }
    for(int i=6;i<(linha*coluna);i++){

        int p = rand() % 5 + 0;
        switch (p) {
            case 0: {
                arraydezonas[i]=(new mnt("mnt "));
                break;
            }
            case 1: {
                arraydezonas[i]=(new dsr("dsr "));
                break;
            }
            case 2:{
                arraydezonas[i]=(new pas("pas "));
                break;
            }
            case 3:{
                arraydezonas[i]=(new flr("flr "));
                break;
            }
            case 4:{
                arraydezonas[i]=(new pnt("pnt "));
                break;
            }
            case 5:{
                arraydezonas[i]=(new Zznz("znz "));
                break;
            }
        }
    }



}
void ilha::apresentaIlha() {

    cout << ".";
    for (int i = 0; i <= this->_colunas; i++) {
        cout << ".....";
    }

    cout << "\n";
    cout << "|";

    for(int j=0;j<=_linhas;j++) {
        for (int i = 0; i <= _colunas; i++) {
            cout << arraydezonas[j*(_colunas+1)+i]->devolveTipo();
            cout << "|";
        }
        cout << "\n";
        cout << "|";
        for(int i=0; i<=_colunas;i++) {
            cout << arraydezonas[j*(_colunas+1)+i]->devolveTipoEd();
            cout << "|";
        }
        cout << "\n";
        cout << "|";
        for(int i=0;i<=_colunas;i++) {
            cout << "    ";
            cout << "|";
        }
        cout << "\n";
        cout << "|";
        for(int i=0;i<=_colunas;i++) {
            cout << arraydezonas[j*(_colunas+1)+i]->devolveTamArrayTrab();
            cout << "   ";
            cout << "|";
        }
        cout << "\n";

        cout << ".";
        for (int i = 0; i <= this->_colunas; i++) {
            cout << ".....";
        }

        cout << "\n";

        if(j<_linhas) {
            cout << "|";
        }
    }
}
int ilha::returnColunaTotal() {
    return _colunas;
}
int ilha::returnLinhaTotal() {
    return _linhas;
}
void ilha::contratarTrabalhador(string tipo,int dias,int id) {
    arraydezonas[2]->contratarTrabalhador(tipo,dias,id);
}
void ilha::recolhaRecursos(){
    zona* Zcima;
    zona* Zbaixo;
    zona* Zdireita;
    zona* Zesquerda;

    float a=0;
    float col=_colunas;


    for(int i=0; i<((_colunas+1)*(_linhas+1));i++){
        //zona cima
        if(i-(_colunas+1)<0){Zcima= nullptr;}
        else{Zcima=arraydezonas[i-(_colunas+1)];}

        //zona baixo
        if(i+(_colunas+1)>((_linhas+1)*(_colunas+1))-1){Zbaixo= nullptr;}
        else{Zbaixo=arraydezonas[i+(_colunas+1)];}

        //zona direita
        float direita=(a+1)/(col+1);
        float is_direita=direita-(int)direita; //É uma zona da direita se este valor for 0
        if(is_direita==0){Zdireita= nullptr;}
        else{Zdireita=arraydezonas[i+1];}

        //zona esquerda
        float esquerda=a/(col+1);
        float is_esquerda=esquerda-(int)esquerda; //É uma zona da esquerda se este valor for 0
        if(is_esquerda==0){Zesquerda= nullptr;}
        else{Zesquerda=arraydezonas[i-1];}

        arraydezonas[i]->recolhaRecursos(Zcima,Zbaixo,Zdireita,Zesquerda);
        a=a+1;
    }
}
void ilha::efeitosZonas() {
    for(int i=0;i<(_colunas+1)*(_linhas+1);i++){
        arraydezonas[i]->efeitosZonas(0);
    }
}
void ilha::apresentaZona(int linha, int coluna) {
    arraydezonas[(linha-1)*(_colunas+1)+(coluna-1)]->apresentaZona();
}
int ilha::moveTrabalhador(int ID, int linha, int coluna) {

    trabalhador* aux= nullptr;
    //PROCURA TRABALHADOR EM TODOS OS ARRAYS DE TRABALHADORES DE TODAS AS ZONAS
    for (int i = 0; i < (_linhas + 1) * (_colunas + 1); i++) {

        if(arraydezonas[i]->moveTrabalhador(ID)!=nullptr) {
            aux = arraydezonas[i]->moveTrabalhador(ID);
            arraydezonas[i]->eraseTrab(aux);
            break;
        }
    }
    //SE NAO ENCONTRAR
    if(aux==nullptr){return 1;}
    //SE ENCONTRAR -> COLOCA-O NA NOVA ZONA
    arraydezonas[(linha-1)*(_colunas+1)+(coluna-1)]->addTrabalhador(aux);

    return 0;

}
void ilha::apagaTrabalhador(int ID){
    trabalhador* aux= nullptr;
    //PROCURA TRABALHADOR EM TODOS OS ARRAYS DE TRABALHADORES DE TODAS AS ZONAS
    for (int i = 0; i < (_linhas + 1) * (_colunas + 1); i++) {

        if(arraydezonas[i]->moveTrabalhador(ID)!=nullptr) {
            arraydezonas[i]->eraseTrab(aux);
            delete aux;
            break;
        }
    }
}
void ilha::constroiED(string tipo, int linha, int coluna) {
    arraydezonas[(linha-1)*(_colunas+1)+(coluna-1)]->constroiED(tipo);
}
int ilha::upgradeED(int linhas, int colunas) {
    if (this->returnDinheiro() >= 50) {
        arraydezonas[(linhas - 1) * (_colunas + 1) + (colunas - 1)]->returnEDptr()->incNivel();
        return 0;
    }
    else{return 6;}
}