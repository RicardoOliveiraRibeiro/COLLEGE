
#include "ilha.h"
#include "userInterf.h"
using namespace std;


int main() {

    //NOVO JOGO
    jogar();

    //CARREGAR JOGO

    //GUARDAR JOGO

    return 0;
}
