//
// Created by BigRic3D on 13/12/2021.
//

#ifndef ILHA_H_TRABALHADOR_H
#define ILHA_H_TRABALHADOR_H
#include <string>
#include <iostream>
using namespace std;


class trabalhador {
    string _tipo;
    int _custo;
    int _id;
    int _dia_contratado;
    int _dias;
    int _probDemissao;
public:
    trabalhador(string tipo, int custo, int id, int dia_contratado, int probDemissao);
    int returnDias();
    string returnTipo();
    int return_dia_contratado();
    int returnCusto();
    int returnId();
    int returnProbDemiss();
    void ApresentaTrabalhador();
    bool demissao(int incProbDemissao);
    void baixaProbDemissao();
};


class operario : public trabalhador {
    int _dia_de_demissao;
public:
    operario(string tipo, int custo, int id, int dia_contratado, int probDemissao);
};

class lenhador : public trabalhador{
    int _descanso;
public:
    lenhador(string tipo, int custo, int id, int dia_contratado, int probDemissao);
};

class mineiro : public trabalhador{
    int _dia_de_demissao;
public:
    mineiro(string tipo, int custo, int id, int dia_contratado, int probDemissao);
};

#endif //ILHA_H_TRABALHADOR_H
