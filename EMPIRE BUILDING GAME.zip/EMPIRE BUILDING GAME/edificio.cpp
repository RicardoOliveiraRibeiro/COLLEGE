//
// Created by BigRic3D on 06/01/2022.
//
#include <string>
#include "zona.h"
#include "edificio.h"
#include "ilha.h"

edificio::edificio(string tipo, int preco_venda){
    _tipo=tipo;
    //_preco_venda = preco_venda;
    _estado=true;
    _nivel=0;
}

string edificio::devolveTipo(){
    return _tipo;
}
void edificio::desligaED(){
    _estado=false;
}
void edificio::ligaED(){
    _estado=true;
}
bool edificio::returnEstado(){
    return _estado;
}

int edificio::returnNivel(){
    return _nivel;
}
void edificio::incNivel(){
    _nivel++;
}
void edificio::incEletricidadeNaBateria() {
    return;
}
float * edificio::returnPtrCarvao(){
    return 0;
}
float * edificio::returnPtrFerro() {
    return 0;
}
int* edificio::returnPtrVigas(){
    return 0;
}
int* edificio::returnPTRaco() {
    return 0;
}
int* edificio::returnPTReletr() {
    return 0;
}
edificio::~edificio() {

}



minaf::minaf(string tipo,int preco_venda): edificio(tipo,preco_venda){
    _ferro=0;
    //_probDesabar=15;
}
void minaf::recolhaRecursos(int nMineiros,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual) {
    if(nMineiros>0 && returnEstado()) {

        float deserto=1;
        int montanha=1;
        if(atual->devolveTipo()=="dsr "){
            deserto=0.5;
        }
        if(atual->devolveTipo()=="mnt "){
            montanha=2;
        }

        if (_ferro <= 100 + (10 * returnNivel())) {
            _ferro = _ferro + (2 + (returnNivel()))*deserto*montanha;
        }
        if(_ferro>100+(10*returnNivel())){
            _ferro=100+(10*returnNivel());
        }
    }
}
float*minaf::returnPtrFerro() {
    return &_ferro;
}
void minaf::convertToMoney(ilha* ILHATUAL){
    ILHATUAL->addDinheiro(_ferro);
}
minaf::~minaf(){delete this;}


minac::minac(string tipo,int preco_venda) : edificio(tipo,preco_venda){
    _carvao=0;
    //_probDesabar=10;
}
void minac::recolhaRecursos(int nMineiros,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona* atual) {
    if(nMineiros>0 && returnEstado()) {

        float deserto=1;
        float montanha=1;
        if(atual->devolveTipo()=="dsr "){
            deserto=0.5;
        }

        if(atual->devolveTipo()=="mnt "){
            montanha=2;
        }

        if (_carvao < 100 + (10 * returnNivel())) {
            _carvao = _carvao + (2 + (returnNivel()))*deserto*montanha;
        }
        if(_carvao>100+(10*returnNivel())){
            _carvao=100+(10*returnNivel());
        }
    }
}
float* minac::returnPtrCarvao(){
    return &_carvao;
}
void minac::convertToMoney(ilha* ILHATUAL){
    ILHATUAL->addDinheiro(_carvao);
}
minac::~minac(){delete this;}

central::central(string tipo,int preco_venda) : edificio(tipo,preco_venda){
    _carvao=0;
}
void central::recolhaRecursos(int nOperarios,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual){
    if(_carvao>100){_carvao=100;}
    if(nOperarios>0 && returnEstado()) {
        _carvao++;
        if(_carvao>100){_carvao=100;}


        if(cima!=NULL) {
            if (cima->devolveTipo() == "flr ") {
                if (*(cima->devolveMadeiraFloresta()) > 0) {
                    (*(cima->devolveMadeiraFloresta()))--;
                    if (cima->returnEDptr() != nullptr) {
                        if (cima->returnEDptr()->devolveTipo() == "bat ") {
                            cima->returnEDptr()->incEletricidadeNaBateria();
                            return;
                        }
                    }
                    if(baixo!=NULL) {
                        if (baixo->returnEDptr() != nullptr) {
                            if (baixo->returnEDptr()->devolveTipo() == "bat ") {
                                baixo->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }
                    }
                    if(direita!=NULL) {
                        if (direita->returnEDptr() != nullptr) {
                            if (direita->returnEDptr()->devolveTipo() == "bat ") {
                                direita->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }
                    }
                    if(esquerda!=NULL) {
                        if (esquerda->returnEDptr() != nullptr) {
                            if (esquerda->returnEDptr()->devolveTipo() == "bat ") {
                                esquerda->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }
                    }
                    return;
                }

            }
        }

        if(baixo!=NULL) {
            if (baixo->devolveTipo() == "flr ") {
                if (cima != NULL) {
                    if (*(cima->devolveMadeiraFloresta()) > 0) {
                        (*(cima->devolveMadeiraFloresta()))--;
                        if (cima->returnEDptr() != nullptr) {
                            if (cima->returnEDptr()->devolveTipo() == "bat ") {
                                cima->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }

                        if (baixo->returnEDptr() != nullptr) {
                            if (baixo->returnEDptr()->devolveTipo() == "bat ") {
                                baixo->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }

                        if(direita!=NULL) {
                            if (direita->returnEDptr() != nullptr) {
                                if (direita->returnEDptr()->devolveTipo() == "bat ") {
                                    direita->returnEDptr()->incEletricidadeNaBateria();
                                    return;
                                }
                            }
                        }
                        if(esquerda!=NULL) {
                            if (esquerda->returnEDptr() != nullptr) {
                                if (esquerda->returnEDptr()->devolveTipo() == "bat ") {
                                    esquerda->returnEDptr()->incEletricidadeNaBateria();
                                    return;
                                }
                            }
                        }
                        return;
                    }

                }
            }
        }

        if(direita!=NULL) {
            if (direita->devolveTipo() == "flr ") {
                if(cima!=NULL) {
                    if (*(cima->devolveMadeiraFloresta()) > 0) {
                        (*(cima->devolveMadeiraFloresta()))--;
                        if (cima->returnEDptr() != nullptr) {
                            if (cima->returnEDptr()->devolveTipo() == "bat ") {
                                cima->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }
                        if(baixo!=NULL) {
                            if (baixo->returnEDptr() != nullptr) {
                                if (baixo->returnEDptr()->devolveTipo() == "bat ") {
                                    baixo->returnEDptr()->incEletricidadeNaBateria();
                                    return;
                                }
                            }
                        }

                        if (direita->returnEDptr() != nullptr) {
                            if (direita->returnEDptr()->devolveTipo() == "bat ") {
                                direita->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }

                        if(esquerda!=NULL) {
                            if (esquerda->returnEDptr() != nullptr) {
                                if (esquerda->returnEDptr()->devolveTipo() == "bat ") {
                                    esquerda->returnEDptr()->incEletricidadeNaBateria();
                                    return;
                                }
                            }
                        }
                        return;
                    }
                }

            }
        }

        if(esquerda!=NULL) {
            if (esquerda->devolveTipo() == "flr ") {
                if(cima!=NULL) {
                    if (*(cima->devolveMadeiraFloresta()) > 0) {
                        (*(cima->devolveMadeiraFloresta()))--;
                        if (cima->returnEDptr() != nullptr) {
                            if (cima->returnEDptr()->devolveTipo() == "bat ") {
                                cima->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }
                        if(baixo!=NULL) {
                            if (baixo->returnEDptr() != nullptr) {
                                if (baixo->returnEDptr()->devolveTipo() == "bat ") {
                                    baixo->returnEDptr()->incEletricidadeNaBateria();
                                    return;
                                }
                            }
                        }
                        if(direita!=NULL) {
                            if (direita->returnEDptr() != nullptr) {
                                if (direita->returnEDptr()->devolveTipo() == "bat ") {
                                    direita->returnEDptr()->incEletricidadeNaBateria();
                                    return;
                                }
                            }
                        }

                        if (esquerda->returnEDptr() != nullptr) {
                            if (esquerda->returnEDptr()->devolveTipo() == "bat ") {
                                esquerda->returnEDptr()->incEletricidadeNaBateria();
                                return;
                            }
                        }

                        return;
                    }
                }

            }
        }

        _carvao--;
        return;
    }


}
float* central::returnPtrCarvao(){
    return &_carvao;
}
void central::convertToMoney(ilha* ILHATUAL){
    ILHATUAL->addDinheiro(_carvao);
}
central::~central(){delete this;}

bat::bat(string tipo,int preco_venda): edificio(tipo,preco_venda){
    _eletricidade=0;
}
void bat::recolhaRecursos(int zero,zona* cima,zona*baixo,zona*direita,zona*esquerda,zona*atual){
    if(_eletricidade>100+(10*returnNivel())){
         _eletricidade=100+(10*returnNivel());
    }
}
void bat::incEletricidadeNaBateria() {
    _eletricidade++;
}
int* bat::returnPTReletr() {
    return &_eletricidade;
}
void bat::convertToMoney(ilha* ILHATUAL){
    ILHATUAL->addDinheiro(1.5*_eletricidade);
}
bat::~bat(){delete this;}

fund::fund(string tipo,int preco_venda): edificio(tipo,preco_venda){
    _aco=0;
}
void fund::recolhaRecursos(int nOperarios, zona *cima, zona *baixo, zona *direita, zona *esquerda,zona*atual) {
    if (_aco > 100) {
        _aco = 100;
        return;
    }
    if (nOperarios > 0) {

        //se uma das zonas for uma mina de ferro e tiver 1.5 de ferro ou mais
        if (cima != NULL) {
            if (cima->returnEDptr()->devolveTipo() == "mnf " && (*(cima->returnEDptr()->returnPtrFerro())) >= 1.5) {
                if (baixo != NULL) {
                    if ((baixo->returnEDptr()->devolveTipo() == "mnc " ||
                         baixo->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(baixo->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(baixo->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(cima->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if (direita != NULL) {
                    if ((direita->returnEDptr()->devolveTipo() == "mnc " ||
                         direita->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(direita->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(direita->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(cima->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if (esquerda != NULL) {
                    if ((esquerda->returnEDptr()->devolveTipo() == "mnc " ||
                         esquerda->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(esquerda->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(esquerda->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(cima->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
            }
        }

        if (baixo != NULL) {
            if (baixo->returnEDptr()->devolveTipo() == "mnf " && (*(baixo->returnEDptr()->returnPtrFerro())) >= 1.5) {
                if (cima != NULL) {
                    if ((cima->returnEDptr()->devolveTipo() == "mnc " ||
                         cima->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(cima->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(cima->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(baixo->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if (esquerda != NULL) {
                    if ((esquerda->returnEDptr()->devolveTipo() == "mnc " ||
                         esquerda->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(esquerda->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(esquerda->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(baixo->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if (direita != NULL) {
                    if ((direita->returnEDptr()->devolveTipo() == "mnc " ||
                         direita->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(direita->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(direita->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(baixo->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
            }
        }

        if (direita != NULL) {
            if (direita->returnEDptr()->devolveTipo() == "mnf " &&
                (*(direita->returnEDptr()->returnPtrFerro())) >= 1.5) {
                if (cima != NULL) {
                    if ((cima->returnEDptr()->devolveTipo() == "mnc " ||
                         cima->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(cima->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(cima->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(direita->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if (esquerda != NULL) {
                    if ((esquerda->returnEDptr()->devolveTipo() == "mnc " ||
                         esquerda->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(esquerda->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(esquerda->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(direita->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if (baixo != NULL) {
                    if ((baixo->returnEDptr()->devolveTipo() == "mnc " ||
                         baixo->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(baixo->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(baixo->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(direita->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
            }
        }

        if (esquerda != NULL) {
            if (esquerda->returnEDptr()->devolveTipo() == "mnf " &&
                (*(esquerda->returnEDptr()->returnPtrFerro())) >= 1.5) {
                if(cima!=NULL) {
                    if ((cima->returnEDptr()->devolveTipo() == "mnc " ||
                         cima->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(cima->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(cima->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(esquerda->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if(direita!=NULL) {
                    if ((direita->returnEDptr()->devolveTipo() == "mnc " ||
                         direita->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(direita->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(direita->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(esquerda->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
                if(baixo!=NULL) {
                    if ((baixo->returnEDptr()->devolveTipo() == "mnc " ||
                         baixo->returnEDptr()->devolveTipo() == "cnt ") &&
                        (*(baixo->returnEDptr()->returnPtrCarvao())) >= 0.5) {
                        _aco += 1;
                        (*(baixo->returnEDptr()->returnPtrCarvao())) -= 0.5;
                        (*(esquerda->returnEDptr()->returnPtrFerro())) -= 1.5;
                        return;
                    }
                }
            }
        }
    }
}
int* fund::returnPTRaco() {
    return &_aco;
}
void fund::convertToMoney(ilha* ILHATUAL){
    ILHATUAL->addDinheiro(2*_aco);
}
fund::~fund() {delete this;}

znz::znz(string tipo, int preco_venda) : edificio(tipo,preco_venda){
    _vigas=0;
}
void znz::recolhaRecursos(int nLenhadores, zona *cima, zona *baixo, zona *direita, zona *esquerda,zona*atual) {
    if(nLenhadores<=0){return;}
    if(_vigas>100){_vigas=100; return;}

    if(cima!=NULL) {
        if (cima->devolveTipo() == "flr" && (*(cima->devolveMadeiraFloresta())) >= 2) {
            (*(cima->devolveMadeiraFloresta())) -= 2;
            _vigas += 1;
            return;
        }
    }

    if(baixo!=NULL) {
        if (baixo->devolveTipo() == "flr" && (*(baixo->devolveMadeiraFloresta())) >= 2) {
            (*(baixo->devolveMadeiraFloresta())) -= 2;
            _vigas += 1;
            return;
        }
    }

    if(direita!=NULL) {
        if (direita->devolveTipo() == "flr" && (*(direita->devolveMadeiraFloresta())) >= 2) {
            (*(direita->devolveMadeiraFloresta())) -= 2;
            _vigas += 1;
            return;
        }
    }

    if(esquerda!=NULL) {
        if (esquerda->devolveTipo() == "flr" && (*(esquerda->devolveMadeiraFloresta())) >= 2) {
            (*(esquerda->devolveMadeiraFloresta())) -= 2;
            _vigas += 1;
            return;
        }
    }

    if(atual->devolveTipo()=="flr"&&(*(atual->devolveMadeiraFloresta())>=2)){
        (*(atual->devolveMadeiraFloresta())) -= 2;
        _vigas +=1;
        return;
    }
}
int* znz::returnPtrVigas(){
    return &_vigas;
}
void znz::convertToMoney(ilha* ILHATUAL){
    ILHATUAL->addDinheiro(2*_vigas);
}
znz::~znz() {delete this;}


