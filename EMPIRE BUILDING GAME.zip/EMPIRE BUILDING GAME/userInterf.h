//
// Created by BigRic3D on 13/12/2021.
//
#include "ilha.h"
#ifndef ILHA_H_USERINTERF_H
#define ILHA_H_USERINTERF_H
using namespace std;
#include <string>
#include <sstream>
#include <iosfwd>
#include <sstream>
#include "edificio.h"
#include <iostream>
#include <fstream>

//MEIO DIA(2)
int execComandos(const string &comandos,ilha *ILHATUAL) {
    istringstream iss(comandos);
    string val;
    iss >> val;

    //CONSTRUIR EDIFICIOS
    if (val == "cons") {
        iss >> val;
        string ed = val;


        if (ed != "minaf") {
            if (ed != "minac") {
                if (ed != "central") {
                    if (ed != "bat") {
                        if (ed != "fund") {
                            if (ed != "serr") {
                                return 1;
                            }
                        }
                    }
                }
            }
        }

        iss >> val;
        stringstream intLinha(val);
        int linhaCons = 0;
        intLinha >> linhaCons;

        iss >> val;
        stringstream intColuna(val);
        int colunaCons = 0;
        intColuna >> colunaCons;

        if (colunaCons < 1 || colunaCons > ILHATUAL->returnColunaTotal() + 1) { return 1; }
        if (linhaCons < 1 || linhaCons > ILHATUAL->returnLinhaTotal() + 1) { return 1; }

        vector<int *> VigasNaIlha;
        int VigasTotais = 0;
        zona **aux = ILHATUAL->returnArrayDeZonas();
        edificio* auxED;
        for (int i = 0; i < ((ILHATUAL->returnColunaTotal() + 1) * (ILHATUAL->returnLinhaTotal() + 1)); i++) {
            auxED=aux[i]->returnEDptr();
            if(auxED!=NULL) {
                VigasNaIlha.push_back(auxED->returnPtrVigas());
            }
        }
        for (int i = 0; i < VigasNaIlha.size(); i++) {
            if (VigasNaIlha[i] != NULL) {
                VigasTotais += (*(VigasNaIlha[i]));
            }
        }

        int vigasAUtilizar;
        int dinheiroAutilizar;
        int montanha=1;
        if(ILHATUAL->returnArrayDeZonas()[(linhaCons-1)*(ILHATUAL->returnColunaTotal()+1)+colunaCons-1]->devolveTipo()=="mnt "){
            montanha=2;
        }

        if (ed == "minaf") {
            cout << "\nEsta construcao custa 10 vigas substituiveis por 10 euros cada\n";
            cout << "Quantas vigas pretenda utilizar nesta contrucao? [ILHA TEM " << VigasTotais << " Vigas]\n";
            cin >> vigasAUtilizar;
            if (vigasAUtilizar > VigasTotais) {
                cout << "Nao tem tantas vigas\n";
                return 1;
            }
            cout << "Quanto dinheiro pretende utilizar nesta construcao? [ILHA TEM " << ILHATUAL->returnDinheiro()
                 << " euros]\n";
            cin >> dinheiroAutilizar;
            dinheiroAutilizar=dinheiroAutilizar*montanha;
            if (dinheiroAutilizar > ILHATUAL->returnDinheiro()) {
                cout << "Nao tem tanto dinheiro\n";
                return 6;
            }
            if (vigasAUtilizar * 10 + dinheiroAutilizar != 100) {
                cout << "Preco a pagar errado, tente novamente\n";
                return 1;
            }


            if (vigasAUtilizar > 0) {
                for (int i = 0; i < VigasNaIlha.size(); i++) {
                    if ((*(VigasNaIlha[i])) >= vigasAUtilizar) {
                        (*(VigasNaIlha[i])) -= vigasAUtilizar;
                        vigasAUtilizar = 0;
                        ILHATUAL->decDinheiro(dinheiroAutilizar);
                        ILHATUAL->constroiED(ed, linhaCons, colunaCons);
                        return 0;
                    }
                }

                for (int i = 0; i < VigasNaIlha.size(); i++) {
                    if(vigasAUtilizar != 0) {
                        if (vigasAUtilizar > (*(VigasNaIlha[i]))) {
                            vigasAUtilizar -= (*(VigasNaIlha[i]));
                            (*(VigasNaIlha[i])) = 0;
                        } else {
                            (*(VigasNaIlha[i])) -= vigasAUtilizar;
                            vigasAUtilizar = 0;
                        }
                    }
                }
                ILHATUAL->decDinheiro(dinheiroAutilizar);
                ILHATUAL->constroiED(ed, linhaCons, colunaCons);
                return 0;

            } else {
                ILHATUAL->decDinheiro(dinheiroAutilizar);
                ILHATUAL->constroiED(ed, linhaCons, colunaCons);
                return 0;
            }
        }

        if (ed == "minac") {
            cout << "\nEsta construcao custa 10 vigas substituiveis por 10 euros cada\n";
            cout << "Quantas vigas pretenda utilizar nesta contrucao? [ILHA TEM " << VigasTotais << "Vigas]\n";
            cin >> vigasAUtilizar;
            if (vigasAUtilizar > VigasTotais) {
                cout << "Nao tem tantas vigas\n";
                return 1;
            }
            cout << "Quanto dinheiro pretende utilizar nesta construcao? [ILHA TEM " << ILHATUAL->returnDinheiro()
                 << "euros]\n";
            cin >> dinheiroAutilizar;
            dinheiroAutilizar=dinheiroAutilizar*montanha;
            if (dinheiroAutilizar > ILHATUAL->returnDinheiro()) {
                cout << "Nao tem tanto dinheiro\n";
                return 6;
            }
            if (vigasAUtilizar * 10 + dinheiroAutilizar != 100) {
                cout << "Preco a pagar errado, tente novamente\n";
                return 1;
            }


            if (vigasAUtilizar > 0) {
                for (int i = 0; i < VigasNaIlha.size(); i++) {
                    if ((*(VigasNaIlha[i])) >= vigasAUtilizar) {
                        (*(VigasNaIlha[i])) -= vigasAUtilizar;
                        vigasAUtilizar = 0;
                        ILHATUAL->decDinheiro(dinheiroAutilizar);
                        ILHATUAL->constroiED(ed, linhaCons, colunaCons);
                        return 0;
                    }
                }

                for (int i = 0; i < VigasNaIlha.size(); i++) {
                    if (vigasAUtilizar != 0) {
                        if (vigasAUtilizar > (*(VigasNaIlha[i]))) {
                            vigasAUtilizar -= (*(VigasNaIlha[i]));
                            (*(VigasNaIlha[i])) = 0;
                        } else {
                            (*(VigasNaIlha[i])) -= vigasAUtilizar;
                            vigasAUtilizar = 0;
                        }
                    }

                }
                ILHATUAL->decDinheiro(dinheiroAutilizar);
                ILHATUAL->constroiED(ed, linhaCons, colunaCons);
                return 0;

            } else {
                ILHATUAL->decDinheiro(dinheiroAutilizar);
                ILHATUAL->constroiED(ed, linhaCons, colunaCons);
                return 0;
            }


        }
        if(ed=="central" && ILHATUAL->returnDinheiro()>=15*montanha) {
            ILHATUAL->constroiED(ed, linhaCons, colunaCons);
            ILHATUAL->decDinheiro(15*montanha);
            return 0;
        }
        if(ed=="bat")  {
            cout << "\nEsta construcao custa 10 vigas e 10 euros\n";
            vigasAUtilizar=10;
            if (vigasAUtilizar > VigasTotais) {
                cout << "Nao tem tantas vigas\n";
                return 1;
            }
            dinheiroAutilizar=10*montanha;
            if (dinheiroAutilizar > ILHATUAL->returnDinheiro()) {
                cout << "Nao tem tanto dinheiro\n";
                return 6;
            }




            for (int i = 0; i < VigasNaIlha.size(); i++) {
                if ((*(VigasNaIlha[i])) >= vigasAUtilizar) {
                    (*(VigasNaIlha[i])) -= vigasAUtilizar;
                    vigasAUtilizar = 0;
                    ILHATUAL->decDinheiro(dinheiroAutilizar);
                    ILHATUAL->constroiED(ed, linhaCons, colunaCons);
                    return 0;
                }
            }

            for (int i = 0; i < VigasNaIlha.size(); i++) {
                if (vigasAUtilizar != 0) {
                    if (vigasAUtilizar > (*(VigasNaIlha[i]))) {
                        vigasAUtilizar -= (*(VigasNaIlha[i]));
                        (*(VigasNaIlha[i])) = 0;
                    } else {
                        (*(VigasNaIlha[i])) -= vigasAUtilizar;
                        vigasAUtilizar = 0;
                    }
                }

            }
            ILHATUAL->decDinheiro(dinheiroAutilizar);
            ILHATUAL->constroiED(ed, linhaCons, colunaCons);
            return 0;

        }
        if(ed=="fund" && ILHATUAL->returnDinheiro()>=10*montanha) {
            ILHATUAL->constroiED(ed, linhaCons, colunaCons);
            ILHATUAL->decDinheiro(10*montanha);
            return 0;
        }
        if(ed=="serr" && ILHATUAL->returnDinheiro()>=10*montanha) {
            ILHATUAL->constroiED(ed, linhaCons, colunaCons);
            ILHATUAL->decDinheiro(10*montanha);
            return 0;
        }

        cout<<"\nDinheiro Not enought\n";
        return 1;
    }

    //CONTRATAR TRABALHADORES
    if(val=="cont"){
        iss>>val;

        if(val!="oper"){if(val!="len"){if(val!="miner"){return 1;}}}

        if(val=="oper"&&ILHATUAL->returnDinheiro()>=15) {
            ILHATUAL->decDinheiro(15);
            ILHATUAL->contratarTrabalhador(val, ILHATUAL->returnDias(), ILHATUAL->returnIdTrab());
            ILHATUAL->updateIdTrab();
            return 0;
        }
        if(val=="len"&&ILHATUAL->returnDinheiro()>=20){
            ILHATUAL->decDinheiro(20);
            ILHATUAL->contratarTrabalhador(val, ILHATUAL->returnDias(), ILHATUAL->returnIdTrab());
            ILHATUAL->updateIdTrab();
            return 0;
        }
        if(val=="miner"&&ILHATUAL->returnDinheiro()>=10){
            ILHATUAL->decDinheiro(10);
            ILHATUAL->contratarTrabalhador(val, ILHATUAL->returnDias(), ILHATUAL->returnIdTrab());
            ILHATUAL->updateIdTrab();
            return 0;
        }
        return 6;
    }

    //EXECUTA FICHEIRO
    if(val=="exec"){
        return 2;
    }

    //LIGA EDIFICIO
    if(val=="liga"){
        iss>>val;
        stringstream intLinha(val);
        int linhaLiga=0;
        intLinha >> linhaLiga;

        iss>>val;
        stringstream intColuna(val);
        int colunaLiga=0;
        intColuna >> colunaLiga;

        if(colunaLiga<1 || colunaLiga > ILHATUAL->returnColunaTotal()+1){return 1;}
        if(linhaLiga<1 || linhaLiga > ILHATUAL->returnLinhaTotal()+1){return 1;}

        ILHATUAL->ligaED(linhaLiga,colunaLiga);

        return 0;
    }

    //DESLIGA EDIFICIO
    if(val=="des"){
        iss>>val;
        stringstream intLinha(val);
        int linhaDesliga=0;
        intLinha >> linhaDesliga;

        iss>>val;
        stringstream intColuna(val);
        int colunaDesliga=0;
        intColuna >> colunaDesliga;

        if(colunaDesliga<1 || colunaDesliga > ILHATUAL->returnColunaTotal()+1){return 1;}
        if(linhaDesliga<1 || linhaDesliga > ILHATUAL->returnLinhaTotal()+1){return 1;}

        ILHATUAL->desligaED(linhaDesliga,colunaDesliga);
        return 0;
    }

    //MOVER UM TRABALHADOR
    if(val=="move"){
        iss>>val;
        stringstream intID(val);
        int ID=0;
        intID >> ID;

        iss>>val;
        stringstream intLinha(val);
        int linhaMove=0;
        intLinha >> linhaMove;

        iss>>val;
        stringstream intColuna(val);
        int colunaMove=0;
        intColuna >> colunaMove;

        if(colunaMove<1 || colunaMove > ILHATUAL->returnColunaTotal()+1){return 1;}
        if(linhaMove<1 || linhaMove > ILHATUAL->returnLinhaTotal()+1){return 1;}

        int ver=ILHATUAL->moveTrabalhador(ID,linhaMove,colunaMove);
        if(ver==1){return 1;}

        return 0;}

    //VENDER RECURSOS
    if(val=="vendeR") {
        iss >> val;
        string rec = val;
        if (rec != "ferro") {
            if (rec != "aco") {
                if (rec != "carvao") {
                    if (rec != "madeira") {
                        if (rec != "vigas") {
                            if (rec != "eletricidade") {
                                return 1;
                            }
                        }
                    }
                }
            }
        }

        iss >> val;
        stringstream quantidades(val);
        int quantidade = 0;
        quantidades >> quantidade;


        if (rec == "ferro") {
            vector<float *> ferroNaIlha;
            float ferroTotal = 0;
            zona **aux = ILHATUAL->returnArrayDeZonas();

            for (int i = 0; i < ((ILHATUAL->returnColunaTotal() + 1) * (ILHATUAL->returnLinhaTotal() + 1)); i++) {
                ferroNaIlha.push_back(aux[i]->returnPTRferro());
            }
            for (int i = 0; i < ferroNaIlha.size(); i++) {
                if (ferroNaIlha[i] != NULL) {
                    ferroTotal += (*(ferroNaIlha[i]));
                }
            }
            if (quantidade > ferroTotal) { return 1; }

            ILHATUAL->addDinheiro(quantidade);
            int i = 0;
            while (quantidade != 0) {
                if (ferroNaIlha[i] != NULL) {
                    if ((*(ferroNaIlha[i])) < quantidade) {
                        quantidade -= (*(ferroNaIlha[i]));
                        (*(ferroNaIlha[i])) = 0;
                    }
                    if ((*(ferroNaIlha[i])) >= quantidade) {
                        (*(ferroNaIlha[i])) -= quantidade;
                        quantidade = 0;
                    }
                }
                i++;
            }
            return 0;
        } //check
        if (rec == "aco") {
            vector<int *> acoNaIlha;
            float acoTotal = 0;
            zona **aux = ILHATUAL->returnArrayDeZonas();
            edificio *auxED;
            for (int i = 0; i < ((ILHATUAL->returnColunaTotal() + 1) * (ILHATUAL->returnLinhaTotal() + 1)); i++) {
                auxED = aux[i]->returnEDptr();
                if (auxED != NULL) {
                    acoNaIlha.push_back(auxED->returnPTRaco());
                }
            }
            for (int i = 0; i < acoNaIlha.size(); i++) {
                if (acoNaIlha[i] != NULL) {
                    acoTotal += (*(acoNaIlha[i]));
                }
            }
            if (quantidade > acoTotal) { return 1; }

            ILHATUAL->addDinheiro(2 * quantidade);
            int i = 0;
            while (quantidade != 0) {
                if (acoNaIlha[i] != NULL) {
                    if ((*(acoNaIlha[i])) < quantidade) {
                        quantidade -= (*(acoNaIlha[i]));
                        (*(acoNaIlha[i])) = 0;
                    }
                    if ((*(acoNaIlha[i])) >= quantidade) {
                        (*(acoNaIlha[i])) -= quantidade;
                        quantidade = 0;
                    }
                }
                i++;
            }
            return 0;
        }
        if (rec == "carvao") {
            vector<float *> carvaoNailha;
            float carvaoTotal = 0;
            zona **aux = ILHATUAL->returnArrayDeZonas();
            edificio *auxED;
            for (int i = 0; i < ((ILHATUAL->returnColunaTotal() + 1) * (ILHATUAL->returnLinhaTotal() + 1)); i++) {
                auxED = aux[i]->returnEDptr();
                if (auxED != NULL) {
                    carvaoNailha.push_back(auxED->returnPtrCarvao());
                }
            }
            for (int i = 0; i < carvaoNailha.size(); i++) {
                if (carvaoNailha[i] != NULL) {
                    carvaoTotal += (*(carvaoNailha[i]));
                }
            }
            if (quantidade > carvaoTotal) { return 1; }

            ILHATUAL->addDinheiro(quantidade);
            int i = 0;
            while (quantidade != 0) {
                if (carvaoNailha[i] != NULL) {
                    if ((*(carvaoNailha[i])) < quantidade) {
                        quantidade -= (*(carvaoNailha[i]));
                        (*(carvaoNailha[i])) = 0;
                    }
                    if ((*(carvaoNailha[i])) >= quantidade) {
                        (*(carvaoNailha[i])) -= quantidade;
                        quantidade = 0;
                    }
                }
                i++;
            }
            return 0;
        }
        if (rec == "madeira") {
            vector<int *> madeiraNaIlha;
            int madeiraTotal = 0;
            zona **aux = ILHATUAL->returnArrayDeZonas();
            int i;
            for (i = 0; i < ((ILHATUAL->returnColunaTotal() + 1) * (ILHATUAL->returnLinhaTotal() + 1)); i++) {
                madeiraNaIlha.push_back(aux[i]->devolveMadeiraFloresta());
            }
            for (i = 0; i < madeiraNaIlha.size(); i++) {
                if ((madeiraNaIlha[i]) != NULL) {
                    madeiraTotal += (*(madeiraNaIlha[i]));
                }
            }
            if (quantidade > madeiraTotal) { return 1; }

            ILHATUAL->addDinheiro(quantidade);
            i = 0;
            while (quantidade != 0) {
                if (madeiraNaIlha[i] != NULL) {
                    if ((*(madeiraNaIlha[i])) < quantidade) {
                        quantidade -= (*(madeiraNaIlha[i]));
                        (*(madeiraNaIlha[i])) = 0;
                    }
                    if ((*(madeiraNaIlha[i])) >= quantidade) {
                        (*(madeiraNaIlha[i])) -= quantidade;
                        quantidade = 0;
                        return 0;
                    }

                }
                i++;
            }
            return 0;
        } //check
        if (rec == "vigas") {
            vector<int *> vigasNailha;
            float vigasTotal = 0;
            zona **aux = ILHATUAL->returnArrayDeZonas();
            edificio *auxED;
            for (int i = 0; i < ((ILHATUAL->returnColunaTotal() + 1) * (ILHATUAL->returnLinhaTotal() + 1)); i++) {
                auxED = aux[i]->returnEDptr();
                if (auxED != NULL) {
                    vigasNailha.push_back(auxED->returnPtrVigas());
                }
            }
            for (int i = 0; i < vigasNailha.size(); i++) {
                if (vigasNailha[i] != NULL) {
                    vigasTotal += (*(vigasNailha[i]));
                }
            }
            if (quantidade > vigasTotal) { return 1; }

            ILHATUAL->addDinheiro(2 * quantidade);
            int i = 0;
            while (quantidade != 0) {
                if (vigasNailha[i] != NULL) {
                    if ((*(vigasNailha[i])) < quantidade) {
                        quantidade -= (*(vigasNailha[i]));
                        (*(vigasNailha[i])) = 0;
                    } else {
                        (*(vigasNailha[i])) -= quantidade;
                        quantidade = 0;
                        return 0;
                    }

                }
                i++;
            }
        }


        if (rec == "eletricidade") {
            vector<int *> eletrNailha;
            float eletrTotal = 0;
            zona **aux = ILHATUAL->returnArrayDeZonas();
            edificio *auxED;
            for (int i = 0; i < ((ILHATUAL->returnColunaTotal() + 1) * (ILHATUAL->returnLinhaTotal() + 1)); i++) {
                auxED = aux[i]->returnEDptr();
                if (auxED != NULL) {
                    eletrNailha.push_back(auxED->returnPTReletr());
                }
            }
            for (int i = 0; i < eletrNailha.size(); i++) {
                eletrTotal += (*(eletrNailha[i]));
            }
            if (quantidade > eletrTotal) { return 1; }

            ILHATUAL->addDinheiro(1.5 * quantidade);
            int i = 0;
            while (quantidade != 0) {
                if ((*(eletrNailha[i])) < quantidade) {
                    quantidade -= (*(eletrNailha[i]));
                    (*(eletrNailha[i])) = 0;
                }
                if ((*(eletrNailha[i])) >= quantidade) {
                    (*(eletrNailha[i])) -= quantidade;
                    quantidade = 0;
                }
                i++;
            }
            return 0;
        }
        return 1;
    }

    //LISTAR ZONA
    if(val=="list"){
        cout << "Dinheiro: " << ILHATUAL->returnDinheiro() << "\n";
        ILHATUAL->apresentaIlha();
        iss>>val;
        stringstream intLinha(val);
        int linhaApresenta=0;
        intLinha >> linhaApresenta;

        iss>>val;
        stringstream intColuna(val);
        int colunaApresenta=0;
        intColuna >> colunaApresenta;

        if(colunaApresenta<1 || colunaApresenta > ILHATUAL->returnColunaTotal()+1){return 1;}
        if(linhaApresenta<1 || linhaApresenta > ILHATUAL->returnLinhaTotal()+1){return 1;}

        ILHATUAL->apresentaZona(linhaApresenta,colunaApresenta);

        return 0;
    }

    //VENDE EDFIFICIO
    if(val=="vende"){
        iss>>val;
        stringstream intvendelinha(val);
        int linhavende=0;
        intvendelinha >> linhavende;

        iss>>val;
        stringstream intvendecoluna(val);
        int colunavende=0;
        intvendecoluna >> colunavende;

        if(colunavende<1 || colunavende > ILHATUAL->returnColunaTotal()+1){return 1;}
        if(linhavende<1 || linhavende > ILHATUAL->returnLinhaTotal()+1){return 1;}

        zona**aux;
        aux=ILHATUAL->returnArrayDeZonas();
        edificio* auxED = aux[linhavende*(ILHATUAL->returnColunaTotal()+1)+colunavende]->returnEDptr();

        if(auxED!= nullptr){
            auxED->convertToMoney(ILHATUAL);
            aux[linhavende*(ILHATUAL->returnColunaTotal()+1)+colunavende]->deleteED();
            return 0;
        }
        return 1;
    }

    //NEXT DAY
    if(val=="next"){
        ILHATUAL->incDias();
        return 5;
    }

    //SAVE GAME
    if(val=="save"){return 0;}

    //LOAD GAME
    if(val=="load"){return 0;}

    //APAGA UM JOGO
    if(val=="apaga"){return 0;}

    //CONFIG FILE
    if(val=="config"){return 0;}

    //CHEAT + MONEY
    if(val=="debcash"){
        iss>>val;
        stringstream intMontante(val);
        int montante=0;
        intMontante >> montante;
        ILHATUAL->addDinheiro(montante);
        return 0;
    }

    //CHEAT ADD ED 0 COST
    if(val=="debed"){
        iss>>val;
        string ed = val;



        if(ed!="minaf"){
            if(ed!="minac"){
                if(ed!="central"){
                    if(ed!="bat"){
                        if(ed!="fund"){
                            return 1;
                        }
                    }
                }
            }
        }

        iss>>val;
        stringstream intLinha(val);
        int linhaCons=0;
        intLinha >> linhaCons;

        iss>>val;
        stringstream intColuna(val);
        int colunaCons=0;
        intColuna >> colunaCons;

        if(colunaCons<1 || colunaCons > ILHATUAL->returnColunaTotal()+1){return 1;}
        if(linhaCons<1 || linhaCons > ILHATUAL->returnLinhaTotal()+1){return 1;}

        ILHATUAL->constroiED(ed,linhaCons,colunaCons);

        return 0;

    }

    //KILL TRABALHADOR
    if(val=="debkill"){
        iss>>val;
        stringstream intID(val);
        int ID=0;
        intID >> ID;

        ILHATUAL->apagaTrabalhador(ID);

        return 0;
    }

    //PARAR DE JOGAR
    if(val=="over"){
        return 3;
    }

    //LVL UP ED
    if(val=="upgrade"){
        iss >> val;
        stringstream intLinha(val);
        int linhaupgrade = 0;
        intLinha >> linhaupgrade;

        iss >> val;
        stringstream intColuna(val);
        int colunaupgrade = 0;
        intColuna >> colunaupgrade;

        if (colunaupgrade < 1 || colunaupgrade > ILHATUAL->returnColunaTotal() + 1) { return 1; }
        if (linhaupgrade < 1 || linhaupgrade > ILHATUAL->returnLinhaTotal() + 1) { return 1; }

        int ver=ILHATUAL->upgradeED(linhaupgrade,colunaupgrade);
        return ver;
    }

    else{return 1;}

}

int askComados(ilha *ILHATUAL){
    string comandos;
    int Val;


    cout << "Introduza Jogada\n";
    getline(cin, comandos);

    Val=execComandos(comandos,ILHATUAL);
    if(Val==5){return 5;} //NEXT DAY, END O COMMANDS
    if(Val==0){printf("\n JOGADA VALIDA E REALIZADA\n"); return 0;}
    if(Val==1){printf("\n JOGADA INVALIDA TENTE NOVAMENTE\n"); return 1;}
    if(Val==6){printf("\n NO MONEY FOR THAT PLAY\n"); return 6;}
    if(Val==2){
        string nome;
        istringstream iss(comandos);
        iss>>nome;
        iss >>nome;
        ifstream MyReadFile(nome);
        while (getline (MyReadFile, comandos)) {
            execComandos(comandos,ILHATUAL);
        }
        ILHATUAL->apresentaIlha();
        return 0;
    } //JOGADAS DUM FICHEIRO
    if(Val==3){return 3;} //ACABOU O JOGO

return 0;
}

void GAMEPLAY(ilha ILHATUAL) {
    //DECORRER DO JOGO
    int continuar;
    cin.ignore();
    do {

        //ALTURA DO DIA 1

        ILHATUAL.efeitosZonas();

        //ALTURA DO DIA 2

        do {
            continuar = askComados(&ILHATUAL);
        } while (continuar ==1 || continuar ==2 || continuar == 6  || continuar ==0);
        ILHATUAL.apresentaIlha();

        //ALTURA DO DIA 3

        ILHATUAL.recolhaRecursos();
        cout << "\nRecursos recolhidos \n";


    }while (continuar != 3);
}

void jogar(){
    //SETUP ILHA
    int linhas;
    int colunas;
    do {
        cout<<"quantas linhas na ilha?\n";
        cin >> linhas;
    }while(linhas<3 || linhas >8);
    do{
        cout << "quantas colunas na ilha?\n";
        cin>>colunas;
    }while(colunas<3 || colunas >16);

    ilha ILHATUAL(linhas, colunas);
    ILHATUAL.apresentaIlha();


    GAMEPLAY(ILHATUAL);

}

#endif //ILHA_H_USERINTERF_H

