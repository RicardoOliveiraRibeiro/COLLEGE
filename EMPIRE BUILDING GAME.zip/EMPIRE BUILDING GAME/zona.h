//
// Created by BigRic3D on 13/12/2021.
//

#ifndef ILHA_H_ZONA_H
#define ILHA_H_ZONA_H

#include "trabalhador.h"
#include <string>
#include <vector>
#include "edificio.h"
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <stdio.h>
#include "zona.h"


using namespace std;

class zona{
    string _tipo;
    edificio* _ed;
    vector<trabalhador*>_arrayDeTrabalhadores;

public:
    zona(string tipo);
    string devolveTipo();
    string devolveTipoEd();
    int devolveTamArrayTrab()const;
    void constroiED(const string &tipo);
    void contratarTrabalhador(const string &tipo,int dias, int id);
    void ligaED();
    void desligaED();
    int returnSizeVecTrab();
    edificio* returnEDptr();
    //vector<trabalhador *> returnVecTrab();
    int returnNOP();
    int returnNLEN();
    int returnNMINER();
    void addTrabalhador(trabalhador* aux);
    trabalhador* moveTrabalhador(int ID);
    virtual void apresentaZona() const;
    virtual void recolhaRecursos(zona *cima, zona *baixo, zona *direita, zona *esquerda)=0;
    void eraseTrab(trabalhador *t);
    virtual int* devolveMadeiraFloresta();
    virtual float* returnPTRferro();
    virtual void deleteED();
    virtual void efeitosZonas(int incProbDemissao);
    void baixaProbDemissao();


};

class mnt : public zona {
    float _ferro;
public:
    mnt(string tipo);

    void recolhaRecursos(zona *cima, zona *baixo, zona *direita, zona *esquerda);

    void apresentaZona()const;

    float* returnPTRferro();

    void efeitosZonas(int incProbDemissao);
};

class dsr : public zona {
public:
    dsr(string tipo);

    void recolhaRecursos(zona *cima, zona *baixo, zona *direita, zona *esquerda);

    void apresentaZona()const;

    void efeitosZonas(int incProbDemissao);
};

class pas:public zona {
public:
    pas(string tipo);

    void recolhaRecursos(zona *cima, zona *baixo, zona *direita, zona *esquerda);

    void apresentaZona()const;

    void efeitosZonas(int incProbDemissao);
};

class flr:public zona {
    int _madeira;
    int _arvores;
public:
    flr(string tipo);

    void recolhaRecursos(zona *cima, zona *baixo, zona *direita, zona *esquerda);

    void apresentaZona()const;

    int* devolveMadeiraFloresta();

    void efeitosZonas(int incProbDemissao);
};

class pnt:public zona {
    int _afundar;
public:
    pnt(string tipo);

    void recolhaRecursos(zona *cima, zona *baixo, zona *direita, zona *esquerda);

    void apresentaZona()const;

    void efeitosZonas(int incProbDemissao);
};

class Zznz:public zona {

public:
    Zznz(string tipo);

    void recolhaRecursos(zona *cima, zona *baixo, zona *direita, zona *esquerda);

    void apresentaZona()const;

    void efeitosZonas(int incProbDemissao);
};


#endif //ILHA_H_ZONA_H
