//
// Created by BigRic3D on 13/12/2021.
//
#include "trabalhador.h"
#include <string>
#include "edificio.h"
#include "zona.h"

#include <cstdlib>
#include <ctime>
#include <iostream>
#include <stdio.h>


using namespace std;

string zona::devolveTipo() {
    return _tipo;
}
zona::zona(string tipo) {
    _tipo=tipo;
    _ed=nullptr;
}
string zona::devolveTipoEd() {
    if (_ed == nullptr) { return "    "; }
    else {
        return _ed->devolveTipo();
    }
}
int zona::devolveTamArrayTrab()const{
   return _arrayDeTrabalhadores.size();
}
void zona::constroiED(const string &tipo) {
    if (tipo == "minaf") {_ed = new minaf("mnf ", 0);}
    if (tipo == "minac") { _ed = new minac("mnc ",0);}
    if (tipo == "central") { _ed = new central("cnt ",15);}
    if (tipo == "bat") { _ed = new bat("bat ",10);}
    if (tipo == "fun") { _ed = new fund("fund",10);}
    if (tipo == "serr") {_ed = new znz("serr",10);}
}
void zona::contratarTrabalhador(const string &tipo,int dias,int id) {
    if(tipo=="oper"){_arrayDeTrabalhadores.push_back(new operario("oper",15,id,dias,5));}
    if(tipo=="miner"){_arrayDeTrabalhadores.push_back(new mineiro("miner",10,id,dias,10));}
    if(tipo=="len"){_arrayDeTrabalhadores.push_back(new lenhador("len",20,id,dias,10));}
}
int zona::returnNLEN() {
    int nLEN=0;
    for(int i=0; i < _arrayDeTrabalhadores.size(); i++){
        if(_arrayDeTrabalhadores[i]->returnTipo()=="len"){
            nLEN++;
        }
    }
    return nLEN;
}
int zona::returnNOP() {
    int nOP=0;
    for(int i=0; i < _arrayDeTrabalhadores.size(); i++){
        if(_arrayDeTrabalhadores[i]->returnTipo()=="oper"){
            nOP++;
        }
    }
    return nOP;
}
int zona::returnNMINER() {
    int nMiner=0;
    for(int i=0; i < _arrayDeTrabalhadores.size(); i++){
        if(_arrayDeTrabalhadores[i]->returnTipo()=="miner"){
            nMiner++;
        }
    }
    return nMiner;
}
void zona::ligaED(){
    if(_ed!=nullptr) {
        _ed->ligaED();
    }
}
void zona::desligaED() {
    if (_ed == nullptr) {
        _ed->desligaED();
    }
}
int zona::returnSizeVecTrab(){
    return (int)_arrayDeTrabalhadores.size();
}
edificio* zona::returnEDptr(){
    return _ed;
}

void zona::addTrabalhador(trabalhador* aux){
    _arrayDeTrabalhadores.push_back(aux);
}
trabalhador* zona::moveTrabalhador(int ID){
    for(int i = 0; i < _arrayDeTrabalhadores.size(); i++){
        if(_arrayDeTrabalhadores[i]->returnId()==ID){
            return _arrayDeTrabalhadores[i];
        }
    }
    return nullptr;
}
void zona::eraseTrab(trabalhador* t){
    int a=0;
    for (auto i = _arrayDeTrabalhadores.begin(); i != _arrayDeTrabalhadores.end(); ++i){
        if(_arrayDeTrabalhadores[a]->returnId()==t->returnId()){
            _arrayDeTrabalhadores.erase(i);
            break;
        }
        a++;
    }
}
void zona::apresentaZona()const{
    cout << "\nTipo da Zona: " << _tipo << "\n";
    if(_ed!= nullptr) {
        cout << "Edificio na zona: " << _ed->devolveTipo() << "\n";
    }
    if(_ed== nullptr){
        cout << "No building na zona\n";
    }
    cout << "Numero de trabalhadores na zona: "<< this->devolveTamArrayTrab() << "\n";

    int a=0;
    for (auto i = _arrayDeTrabalhadores.begin(); i != _arrayDeTrabalhadores.end(); ++i){
        _arrayDeTrabalhadores[a]->ApresentaTrabalhador();
        a++;
    }
}
int *zona::devolveMadeiraFloresta() {
    return 0;
}
float* zona::returnPTRferro() {
    return 0;
}
void zona::deleteED() {
    delete _ed;
}
void zona::efeitosZonas(int incProbDemissao) {
    if(this->devolveTipo()!="pas"){
        int a=0;
        for(auto i=_arrayDeTrabalhadores.begin(); i<_arrayDeTrabalhadores.end();i++){
            bool demite=_arrayDeTrabalhadores[a]->demissao(incProbDemissao);
            if(demite){
                delete _arrayDeTrabalhadores[a];
                _arrayDeTrabalhadores.erase(i);
            }
            a++;
        }
    }
}
void zona::baixaProbDemissao(){
    for(int i=0;_arrayDeTrabalhadores.size();i++){
        _arrayDeTrabalhadores[i]->baixaProbDemissao();
    }
}



mnt::mnt(string tipo):zona(tipo){
    _ferro=0;
}
void mnt::recolhaRecursos(zona* cima, zona* baixo, zona* direita, zona* esquerda) {
    _ferro = _ferro + (returnSizeVecTrab() * 0.1);
    edificio *aux = returnEDptr();
    if (aux != nullptr) {
        if(aux->devolveTipo()=="mnf "||aux->devolveTipo()=="mnc ") {
            aux->recolhaRecursos(returnNMINER(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="cnt "||aux->devolveTipo()=="fund"){
            aux->recolhaRecursos(returnNOP(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="serr"){
            aux->recolhaRecursos(returnNLEN(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="bat "){
            aux->recolhaRecursos(0,cima, baixo, direita, esquerda,this);
        }
    }
}
void mnt::apresentaZona()const {
    zona::apresentaZona();
    cout << "\nQuantidade de ferro: " << _ferro << "\n";
}
float* mnt::returnPTRferro() {
    return &_ferro;
}
void mnt::efeitosZonas(int incProbDemissao) {
    zona::efeitosZonas(5);
}

dsr::dsr(string tipo):zona(tipo){}
void dsr::recolhaRecursos(zona* cima, zona* baixo, zona* direita, zona* esquerda) {
    edificio *aux = returnEDptr();
    if (aux != nullptr) {
        if(aux->devolveTipo()=="mnf "||aux->devolveTipo()=="mnc ") {
            aux->recolhaRecursos(returnNMINER(),cima, baixo, direita, esquerda, this);
        }
        if(aux->devolveTipo()=="cnt "||aux->devolveTipo()=="fund"){
            aux->recolhaRecursos(returnNOP(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="serr"){
            aux->recolhaRecursos(returnNLEN(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="bat "){
            aux->recolhaRecursos(0,cima, baixo, direita, esquerda,this);
        }
    }
}
void dsr::apresentaZona()const {
zona::apresentaZona();
}
void dsr::efeitosZonas(int incProbDemissao) {
    zona::efeitosZonas(incProbDemissao);
}

pas::pas(string tipo):zona(tipo){}
void pas::recolhaRecursos(zona* cima, zona* baixo, zona* direita, zona* esquerda) {
    edificio *aux = returnEDptr();
    if (aux != nullptr) {
        if(aux->devolveTipo()=="mnf "||aux->devolveTipo()=="mnc ") {
            aux->recolhaRecursos(returnNMINER(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="cnt "||aux->devolveTipo()=="fund"){
            aux->recolhaRecursos(returnNOP(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="serr"){
            aux->recolhaRecursos(returnNLEN(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="bat "){
            aux->recolhaRecursos(0,cima, baixo, direita, esquerda,this);
        }
    }
}
void pas::apresentaZona()const {
zona::apresentaZona();
}
void pas::efeitosZonas(int incProbDemissao) {
    zona::efeitosZonas(incProbDemissao);  //??????????????
}

flr::flr(string tipo):zona(tipo){
    _madeira=0;
    srand (time(NULL));
    _arvores=rand() % 40 + 20;
}
void flr::recolhaRecursos(zona* cima, zona* baixo, zona* direita, zona* esquerda) {

    _madeira=_madeira+(returnNLEN()); //INCREMENTA 1 DE MADEIRA POR CADA LENHADOR CONTADO

    edificio *aux = returnEDptr();
    if (aux != nullptr) {
        if(aux->devolveTipo()=="mnf "||aux->devolveTipo()=="mnc ") {
            aux->recolhaRecursos(returnNMINER(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="cnt "||aux->devolveTipo()=="fund"){
            aux->recolhaRecursos(returnNOP(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="serr"){
            aux->recolhaRecursos(returnNLEN(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="bat "){
            aux->recolhaRecursos(0,cima, baixo, direita, esquerda,this);
        }
    }
}
void flr::apresentaZona()const {
zona::apresentaZona();
cout << "Numero de arvores: "<<_arvores << "\n";
cout << "Quantidade de madeira: " << _madeira << "\n";
}
int* flr::devolveMadeiraFloresta() {return &_madeira;}
void flr::efeitosZonas(int incProbDemissao) {
    zona::efeitosZonas(incProbDemissao);
    if(this->returnEDptr()==nullptr){
        if(_arvores<100) {
            _arvores = _arvores + 1;
        }
    }
    else{
        if(_arvores>0){
            _arvores=_arvores-1;
        }
    }

}

pnt::pnt(string tipo):zona(tipo){
    _afundar=0;
}
void pnt::recolhaRecursos(zona* cima, zona* baixo, zona* direita, zona* esquerda) {
    edificio *aux = returnEDptr();
    if (aux != nullptr) {
        if(aux->devolveTipo()=="mnf "||aux->devolveTipo()=="mnc ") {
            aux->recolhaRecursos(returnNMINER(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="cnt "||aux->devolveTipo()=="fund"){
            aux->recolhaRecursos(returnNOP(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="serr"){
            aux->recolhaRecursos(returnNLEN(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="bat "){
            aux->recolhaRecursos(0,cima, baixo, direita, esquerda,this);
        }
    }
}
void pnt::apresentaZona()const {
zona::apresentaZona();
cout << "Quantos dias para afundar edificio: " << 10 - _afundar;
}
void pnt::efeitosZonas(int incProbDemissao) {
    zona::efeitosZonas(incProbDemissao);
    if(_afundar==10){
        deleteED();
        _afundar=0;
    }
    else{
        if(returnEDptr()!= nullptr)
        _afundar++;
    }
}

Zznz::Zznz(string tipo):zona(tipo){

}
void Zznz::recolhaRecursos(zona* cima, zona* baixo, zona* direita, zona* esquerda) {
    edificio *aux = returnEDptr();
    if (aux != nullptr) {
        if(aux->devolveTipo()=="mnf "||aux->devolveTipo()=="mnc ") {
            aux->recolhaRecursos(returnNMINER(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="cnt "||aux->devolveTipo()=="fund"){
            aux->recolhaRecursos(returnNOP(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="serr"){
            aux->recolhaRecursos(returnNLEN(),cima, baixo, direita, esquerda,this);
        }
        if(aux->devolveTipo()=="bat "){
            aux->recolhaRecursos(0,cima, baixo, direita, esquerda,this);
        }
    }
}
void Zznz::apresentaZona()const {
zona::apresentaZona();
}
void Zznz::efeitosZonas(int incProbDemissao) {
    zona::efeitosZonas(0);
    zona::baixaProbDemissao();
}

