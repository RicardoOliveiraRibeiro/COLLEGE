#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_COLUNAS 9 //tamanho max do tabuleiro (linhas e colunas) 
#include <time.h>

typedef struct Jogada { //estrutura jogada 
	int jogador; //jogador atual
	int escolha; //esscolha de jogada 
	char tabela[82]; //tabuleiro
	int n_linhas; //linhas da jogada
	int n_colunas; //colunas da jogada 
	int linhasJ2; //linhas do J2 usadas
	int linhasJ1; //linhas do J1 usadas
	int colunasJ2; //colunas do J2 usadas
	int colunasJ1; //colunas do J1 usadas
	int pedraJ1, pedraJ2; //numero de pedras disponiveis do J1 e J2 
	Jogada* prox; //ponteiro para a proxima jogada 

} Jogada; //nome da variavel ao criar uma estrutura



void initRandom() {
	srand(time(NULL));
}
//fun��es do stor
int intUniformRnd(int a, int b) {
	return a + rand() % (b - a + 1);
}



int xy(int linha, int coluna) { //fun��o que recebe uma linha e coluna e devolve uma casa dum array unidimensional (tabuleiro)
	return linha * MAX_COLUNAS + coluna;
}

int apresentar(Jogada jogada_atual,FILE* destino){ //apresnta a jogada (tanto para um ficheiro caso destino aponte para um ficheiro ou para a consola caso o destino aponte para stdout)
	for (int i = 0; i < jogada_atual.n_linhas; i++) { //percorre linhas
			for (int p = 0; p < jogada_atual.n_colunas; p++) { //percorre colunas
				fprintf(destino,"|%c", jogada_atual.tabela[xy(i,p)]); //apresnta a pe�a no espa�o com uma barra de separa��o atras "|"
			}

			/*
			int colunas_int = (int)i / n_colunas;
			float colunas_dec = i / n_colunas - colunas_int;          =    i % n_colunas  linha 15
			*/

		fprintf(destino,"|"); //no final de cada linha coloca outra barra 
		fprintf(destino,"\n"); // e um enter
		
			
		
	}
	return 0;
}

Jogada jogada(Jogada jogada_atual,Jogada *lista, int* interrupt) { //jogada do jogador humano
	int linha, coluna;
	char escolha_texto[100];
	int escolha;
	char peca;
	int contagem = 0;
	int K;
	int contador = 0;
	Jogada* primeiro = lista;

Escolha: //LABEL MAIS IMPORTANTE (PE�O DESCULPA PROFESSOR)

	printf("\n:::::: JOGADOR %d :::::\n", jogada_atual.jogador); //jogador a jogar
	printf("\n Escolha a sua jogada: \n (1) Adicionar peca \n (2) Colocar Pedra \n (3) Adicionar linha \n (4) Adicinar Coluna \n (5) Ver Jogadas \n (6) Terminar jogo"); //escolha da jogada
	scanf_s("%s", escolha_texto,100); //escolha da jogada entra nesta variavel
	escolha = atoi(escolha_texto); //converte esta variavel em inteiro
	if (escolha > 6 || escolha < 1) { //se for uma escolha de jogada invalida
		printf("\nERRO: escolha um numero de 1 a 6\n"); //escolhe outro
		goto Escolha; //e volta pra escolha
	}
	//senao:

	switch (escolha) {
	case 1://coloca pe�a
		printf("\n coordenadas (linha:coluna) :\n");
		scanf_s("%d:%d", &linha, &coluna); //obtem a linha e coluna da pe�a separadas por um ":"
	
		if (linha > jogada_atual.n_linhas || coluna > jogada_atual.n_colunas) { //se a linha e coluna sairem do tabuleiro da erro e volta para a escolha de jogada
			printf("\n ERRO: OFF LIMITS \n");
			goto Escolha;
		}
		peca= jogada_atual.tabela[xy(linha - 1, coluna - 1)];   //senao busca atravez da fun�ao xy as coordenada dessa posi��o linha coluna 
		if (peca == ' ') {
			jogada_atual.tabela[xy(linha-1,coluna-1)] = 'G'; //se colocar pe�a em casa vazia fica G
		}
		if (peca == 'P') {
			printf("\n PECA COM PEDRA \n"); //se colocar pe�a em casa com pedra da erro e volta pra escolha de jogada
			goto Escolha;
		}
		if (peca == 'G') {
			jogada_atual.tabela[xy(linha - 1, coluna - 1)] = 'Y'; //se colocar pe�a numa casa com G fica Y
		}
		if (peca == 'Y') {
			jogada_atual.tabela[xy(linha - 1, coluna - 1)] = 'R'; //se colocar pe�a numa casa com Y fica R
		}
		if (peca == 'R') {
		
			printf("\n ERRO: SELECIONOU PECA VERMELHA \n"); //se colocar pe�a numa casa com R da erro e volta para a escolha de jogada
			goto Escolha;
		}


		break;

	case 2: //coloca��o de pedra

		//verifica se o jogador atual tem pedras pra colocar
		if (jogada_atual.jogador == 1 && jogada_atual.pedraJ1 == 0) {
			printf("\nNO ROCK\n");
			goto Escolha;
		}
		if (jogada_atual.jogador == 2 && jogada_atual.pedraJ2 == 0) {
			printf("\nNO ROCK\n");
			goto Escolha;
		}
		
		
		
		//se tiver pede a linha e coluna da pedra
		printf("\nCoordenada da pedra:\n");
		scanf_s("%d:%d", &linha, &coluna);
		printf("%d %d\n", linha, coluna);

		if (linha > jogada_atual.n_linhas || coluna > jogada_atual.n_colunas) { //se a linha e coluna ultrapassar as linhas e colunas atuais da erro e volta para a escolha de jogada
			printf("\n ERRO: OFF LIMITS \n");
			goto Escolha;
		}
		peca = jogada_atual.tabela[xy(linha-1,coluna-1)]; //obtem coordenadas da pe�a atravez da linha e coluna
		if (peca == ' ') {
			jogada_atual.tabela[xy(linha - 1, coluna - 1)] = 'P'; //se nao houver nada na casa escolhida coloca a pedra e decrementa-a da sua variavel para n�o voltar a colocar mais nenhuma
			if (jogada_atual.jogador == 1 && jogada_atual.pedraJ1 == 1) {
				jogada_atual.pedraJ1 = 0;
			}
			if (jogada_atual.jogador == 2 && jogada_atual.pedraJ2 == 1) {
				jogada_atual.pedraJ2 = 0;
			}
		}
		else {
			printf("\n ERRO: CASA COM PECA \n"); //se a casa nao estiver vazia da erro e volta para a escolha da jogada
			goto Escolha;
		}
		break;

	case 3://coloca��o de linhas
		//verifica��o se o jogador atual ainda tem linhas para colocar e se tiver incrementa o numero de linhas colocadas
		if (jogada_atual.jogador == 1) {
			if (jogada_atual.linhasJ1 < 2) {
				jogada_atual.n_linhas = jogada_atual.n_linhas + 1;
				(jogada_atual.linhasJ1)++;
			}
			else {
				printf("ERRO: todas as linhas usadas"); //sem linhas, volta a escolha de jogada
				goto Escolha;
			}
		}
		if (jogada_atual.jogador == 2) {
			if (jogada_atual.linhasJ2 < 2) {
				jogada_atual.n_linhas = jogada_atual.n_linhas + 1;
				(jogada_atual.linhasJ2)++;
			}
			else {
				printf("ERRO: todas as linhas usadas");   //sem linhas, volta a escolha de jogada
				goto Escolha;
			}
		}

		break;

	case 4://coloca��o de colunas
			//verifica��o se o jogador atual ainda tem colunas para colocar e se tiver incrementa o numero de colunas colocadas
		if (jogada_atual.jogador == 1) {
			if (jogada_atual.colunasJ1 < 2) {
				jogada_atual.n_colunas = jogada_atual.n_colunas + 1;
				(jogada_atual.colunasJ1)++;
			}
			else {
				printf("ERRO: todas as colunas usadas");   //sem colunas, volta a escolha de jogada
				goto Escolha;
			}
		}
		if (jogada_atual.jogador == 2) {
			if (jogada_atual.colunasJ2 < 2) {
				jogada_atual.n_colunas = jogada_atual.n_colunas + 1;
				(jogada_atual.colunasJ2)++;
			}
			else {
				printf("ERRO: todas as colunas usadas");   //sem colunas, volta a escolha de jogada
				goto Escolha;
			}
		}

	case 5://visualizar jogadas
		
		printf("\n Quantas Jogadas quer ver?\n");
		scanf_s("%d", &K); //numero de jogadas a ver
		

		if (lista == NULL) { //se nao houver jogadas ainda erro e volta para a escolha de jogada
			printf("NO plays");
			goto Escolha;
		}
		if (K <= 0) { //se selecionar 0 jogadas pra ver erro e volta pra escolha de jogada
			printf("No value");
			goto Escolha;
		}

		
		//contagem de quantas jogadas existem
		while (lista->prox != NULL) {
			contagem++;
			lista = lista->prox;
		}
		lista = primeiro;

		//ponteiro lista passa de jogada em jogada ate chegar ao numero de jogadas menos o numero de jogadas a ver
		for (int i = 0; i <= contagem - K; i++) {
			lista = lista->prox;
			
		}
		//se o jogador quiser ver mais jogadas do que existem da erro e volta a escolha de jogada
		if (K > contagem+1) {
			printf("N jogadas a ver > N jogadas existentes\n");
			lista = primeiro;
			goto Escolha;
		}
		
		while (lista != NULL) { //apresenta as jogadas ate ao final
			
			printf("->Jogada %d\n", contagem-K+contador+2); //numero da jogada a partir da jogada (total de jogadas-n� de jogadas a ver)
			apresentar(*lista,stdout); //apresenta as jogadas
			printf("\n");
			lista = lista->prox;
			contador++;
			
		}
		contador = 0;
		contagem = 0;
		lista = primeiro;
		//esta op�ao de jogada n�o retira a ver ao jogador logo volta sempre para a escolha de jogada
		goto Escolha;
		

	case 6://terminar o jogo a meio
		printf("\n (1) Tem a certeza que deseja terminar (2) cancelar \n");
		int check = 0;

		while (check < 1 || check > 2) { //valida��o da op��o do jogador (terminar/cancelar)

			scanf_s("%d", &check);

			if (check == 1) {
				*interrupt = 1; //se quiser terminar coloca 1 no espa�o de memoria apontada por este ponteiro
				break;
			}
			else if (check == 2) { //se quiser cancelar volta a escolha de jogada
				goto Escolha;
			}
			else {
				printf("\nopcao invalido, Escolha uma opcao\n"); //se escolher uma op��o invalida obriga a escolher uma valida
				check = 0;
			}
		
		}
		break;
	}

	return jogada_atual;

}

 
Jogada* guardar(Jogada* lista,Jogada jogada_atual) { //guardar jogada na lista ligada

	if (lista == NULL) { //se ainda n�o existir lista
		lista = (Jogada*)malloc(sizeof(Jogada)); //aloca espa�o para a primeira jogada
		*lista = jogada_atual; //ponteiro lista passa a apontar para essa primeira jogada
		lista->prox = NULL; //coloca o ponteiro "prox" dessa jogada a null pois ainda n�o ha jogada seguintes
		return lista; //devolve a lista pois agora ja existe jogada e n�o � mais um ponteiro null
	}
	else { //se ja houver jogadas
		Jogada* primeiro = lista; //guarda a primeira jogada na variavel primeiro
		while (lista->prox != NULL) { //percorre a lista
			lista = lista->prox;      // at� ao ultimo elemento
		}
		
		lista->prox= (Jogada*)malloc(sizeof(Jogada)); //aloca memoria a partir do ultimo elemento para a proxima jogada
		lista = lista->prox; //lista passa a apontar para essa nova memoria
		*lista = jogada_atual; //coloca a nova jogada nessa memoria
		lista->prox = NULL; //e coloca o ponteiro "prox" dessa nova jogada a null 
		return primeiro; //e devolve o ponteiro para a primeira jogada novamente para mais tarde repetir o processo
	}


		
}


void guardarF(Jogada* lista, int modo_de_jogo) {  //guardar jogo ficheiro de texto
	char nome[100]; //nome do ficheiro
	int contador = 1; //cria��o contador
	printf("\nNome ficheiro\n");
	scanf_s("%s", nome, 100); //busca nome ficheiro
	FILE* ficheiro; //cria��o ficheiro variavel
	fopen_s(&ficheiro, nome, "w"); //abrir ficheiro
	fprintf(ficheiro, "Modo de jogo: %d\n", modo_de_jogo); //escrever modo de jogo
	while (lista != NULL) { //enquanto houver jogada seguintes
		fprintf(ficheiro, "\nJogador: %d\n", lista->jogador); //escreve jogador da jogada
		fprintf(ficheiro, "Jogada: %d\n", contador); //escreve numero da jogada
		contador++; //incrementa a jogada
		apresentar(*lista, ficheiro); //escreve no ficheiro a jogada
		
		lista = lista->prox; //segue para a jogada seguinte
	}

	fclose(ficheiro); //fecha o ficheiro
}

void guardarFB(Jogada* lista,int modo_de_jogo) {  //guardar jogo ficheiro de texto
	char nome[100]="jogo.bin" ; //nome do ficheiro
	FILE* ficheiro; //cria��o ficheiro variavel
	fopen_s(&ficheiro, nome, "wb"); //abrir ficheiro
	fwrite(&modo_de_jogo, sizeof(int), 1, ficheiro);
	while (lista != NULL) { //enquanto houver jogada seguintes
		fwrite(lista, sizeof(Jogada), 1, ficheiro); //escrita da jogada
		lista = lista->prox; //segue para a jogada seguinte
	}
	fclose(ficheiro); //fecha o ficheiro
}

Jogada* carregaFB(int* modo_de_jogo) {
	char nome[30] = "jogo.bin"; //nome do ficheiro
	int contador = 1; //cria��o contador
	FILE* ficheiro; //cria��o ficheiro variavel
	fopen_s(&ficheiro, nome, "rb"); //abrir ficheiro
	Jogada* lista = NULL; 
	Jogada atual;
	fread(modo_de_jogo, sizeof(int), 1, ficheiro);
	while (contador != 0) {
		contador = fread(&atual, sizeof(Jogada), 1, ficheiro);
		if (contador != 0) {
			lista = guardar(lista, atual);
		}
	}

	fclose(ficheiro); //fecha o ficheiro
	return lista;
}







int verifica(Jogada jogada_atual) {
	//LINHAS
	for (int i = 0; i < jogada_atual.n_linhas; i++) { //percorre as linhas
		int q = 0;
		for (int p = 0; p < jogada_atual.n_colunas - 1; p++) { //percorre as colunas de cada linha
			if (jogada_atual.tabela[xy(i,p)] == ' ') { //se houver 1 ' ' ja n�o ganha nessa linha
				break;
			}
			else if (jogada_atual.tabela[xy(i, p)] == jogada_atual.tabela[xy(i, p+1)]) {
				q++;  //se a coluna anterior dessa linha for igual a coluna seguinte incrementa q
			}
			else {   //se n�o for igual n�o ganha nessa linha
				break;
			}

			if (q == jogada_atual.n_colunas - 1) {
				return 1;  //se q no final for igual ao numero de colunas todas as colunas t�m a mesma pe�a e o jogador ganha
				
			}
		}
	}
	//COLUNAS
	for (int i = 0; i < jogada_atual.n_colunas; i++) {  //percorre todas as colunas
		int q = 0;
		for (int p = 0; p < jogada_atual.n_linhas - 1; p++) {  //percorre todas as linhas de cada coluna
			if (jogada_atual.tabela[xy(p, i)] == ' ') { //se houver 1 ' ' ja n�o ganha nessa coluna
				break;
			}
			else if (jogada_atual.tabela[xy(p, i)] == jogada_atual.tabela[xy(p+1, i)]) {
				q++;   //se a linha anterior dessa coluna for igual a linha seguinte da mesma coluna incrementa q
			}
			else {   //se n�o for igual n�o ganha nessa coluna
				break;
			}

			if (q == jogada_atual.n_linhas - 1) {
				return 1;   // se q no final for igual ao numero de linhas todas as linhas dessa coluna t�m a mesma pe�a e o jogador ganha
			}
		}
	}



	//DIAGONAIS
	if (jogada_atual.n_linhas == jogada_atual.n_colunas) {  //so � possivel ganhar diagonalmente se o n� de colunas for igual ao n� de linhas
		int q = 0;
		for (int i = 0; i < jogada_atual.n_linhas - 1; i++) {
			if (jogada_atual.tabela[xy(i, i)] == ' ') { //se alguma casa diagonal tiver um ' ' ja n�o � possivel ganhar diagonalmente
				break;
			}
			else if (jogada_atual.tabela[xy(i, i)] == jogada_atual.tabela[xy(i+1, i+1)]) {
				q++;  //se o valor duma casa for igual ao valor da casa na linha e coluna seguinte incrementa q
			}
			else {   //sen�o n�o � possivel ganhar diagonalmente
				break;
			}
			if (q == jogada_atual.n_linhas - 1) { //se q for igual ao n� de linhas quer dizer que ha uma diagonal cheia e o jogador ganha
				return 1;
			}
		}
		int t = 0;           //Tudo igual mas para a diagonal contraria
		for (int i = 0; i < jogada_atual.n_linhas - 1; i++) {
			if (jogada_atual.tabela[xy(i, jogada_atual.n_colunas-1-i)] == ' ') {
				break;
			}
			else if (jogada_atual.tabela[xy(i, jogada_atual.n_colunas - 1 - i)] == jogada_atual.tabela[xy(i + 1, jogada_atual.n_colunas - 1 - i - 1)]) {
				t++;
			}
			else {
				break;
			}

			if (t == jogada_atual.n_colunas - 1) {
				return 1;
			}
		}
	}
	return 0;



}

Jogada jogadaBot(Jogada jogada_atual,Jogada* lista){
	
	int terminado = 0; // se alguma vez for 1 o bot fez uma jogada valida e termina a sua jogada
	do{
		int escolha = intUniformRnd(1, 4); //escolhe uma op��o ao calhas de jogada
		int linha = intUniformRnd(0, jogada_atual.n_linhas - 1); //busca uma linha ao calhas dentro das possiveis
		int coluna = intUniformRnd(0, jogada_atual.n_colunas - 1);  //busca uma coluna ao calhas dentro das possiveis
		int pos = xy(linha, coluna);  //coordenadas xy obtidas atravez da linha e coluna
		char peca = jogada_atual.tabela[pos];  //coloca na variavel peca a posi��o do tableiro correspondeste as coordenadas
		switch (escolha){
		case 1:  //coloca pe�a
			if (peca == ' ') {
				jogada_atual.tabela[pos] = 'G';
			}
			if (peca == 'P') {
				continue; //salta direto pro proximo ciclo
			}
			if (peca == 'G') {
				jogada_atual.tabela[pos] = 'Y';
				
			}
			if (peca == 'Y') {
				jogada_atual.tabela[pos] = 'R';
				
			}
			if (peca == 'R') {
				continue; //salta direto pro proximo ciclo
			}
			break;

		case 2: //coloca pedra
			if (jogada_atual.pedraJ2 > 0 && peca == ' ') {
				jogada_atual.tabela[pos] = 'P';
				jogada_atual.pedraJ2--;
			}
			else {
				continue; //salta direto pro proximo ciclo
			}
			
			break;
		case 3: //coloca linha
			if (jogada_atual.linhasJ2 < 2) {
				jogada_atual.n_linhas = jogada_atual.n_linhas + 1;
				jogada_atual.linhasJ2++;
			}
			else {
				continue; //salta direto pro proximo ciclo
			}
			break;
		case 4: //coloca coluna
			if (jogada_atual.colunasJ2 < 2) {
				jogada_atual.n_colunas = jogada_atual.n_colunas + 1;
				jogada_atual.colunasJ2++;
			}
			else {
				continue; //salta direto pro proximo ciclo
			}
			break;
		}
		
		//se fizer uma jogada valida chega aqui e coloca terminado a 1

		terminado = 1;
	} while (terminado == 0);
	printf("\n JOGADA BOT\n");
	return jogada_atual;
}

int main(){

	int modo_de_jogo = 0;     //singleplayer ou multiplayer
	int retomar = 0;
	initRandom();  //chamar fun��es do stor
	int interrupt = 0;  // case 6 da fun��o jogada // terminar o jogo a meio
	int verificado = 0;  //return da fun��o verifica
	Jogada jogada_atual;      //cria��o de uma jogada

	
	
	Jogada* lista = NULL;    //cria��o dum ponteiro para a lista de jogadas
	FILE* jogo_binF;
	int existe_ficheiro = fopen_s(&jogo_binF, "jogo.bin", "r");
	
	

	if (existe_ficheiro == 0) {
		fclose(jogo_binF);
		printf("Retomar ultimo jogo (1) Iniciar novo jogo (2)");
		while (retomar == 0) {
			scanf_s("%d", &retomar);
			if (retomar == 1) {
				lista = carregaFB(&modo_de_jogo);

				
			}
			else if (retomar < 1 || retomar>2) {
				printf("Erro: op�ao invalida");
				retomar = 0;
			}
		}
	}



	if (existe_ficheiro != 0 || retomar == 2) {

		printf("\nMultiplayer(1) Singleplayer(2)\n");
		scanf_s("%d", &modo_de_jogo);
	
		
		jogada_atual.n_linhas = intUniformRnd(3, 5);
		jogada_atual.n_colunas = jogada_atual.n_linhas;
		jogada_atual.escolha = 0;
		jogada_atual.jogador = 0;
		jogada_atual.prox = NULL;
		jogada_atual.linhasJ2 = 0;
		jogada_atual.linhasJ1 = 0;
		jogada_atual.colunasJ2 = 0;
		jogada_atual.colunasJ1 = 0;
		jogada_atual.pedraJ1 = 1;
		jogada_atual.pedraJ2 = 1;

		// cria��o do tabuleiro inicial
		for (int i = 0; i < 81; i++) {
			jogada_atual.tabela[i] = ' ';
		}
	}
	else {
		Jogada* primeiro = lista;
		while (lista->prox != NULL) { //percorre a lista

			lista = lista->prox;      // at� ao ultimo elemento
		}
		jogada_atual = *lista;
		lista = primeiro;
	}



	do {     //desenvolvimento do jogo                 

		if (jogada_atual.jogador == 1) {    //troca de jogador apos cada jogada
			jogada_atual.jogador = 2;
		}
		else {
			jogada_atual.jogador = 1;
		}

		apresentar(jogada_atual,stdout);     // apresenta o tabuleiro

		if (modo_de_jogo == 1) {     //se for multiplayer
			jogada_atual = jogada(jogada_atual, lista, &interrupt);  
		}
		else {    //se for singleplayer
			if (jogada_atual.jogador == 1) {
				jogada_atual = jogada(jogada_atual, lista, &interrupt);  //jogada do jogador em modo singleplayer
			}
			else {
				jogada_atual = jogadaBot(jogada_atual,lista);    //jogada do bot em modo singleplayer
			}
		}

		if (interrupt == 0) {
			lista = guardar(lista, jogada_atual);  //guarda a jogada na lista (lista ligada)
			verificado = verifica(jogada_atual);     // verifica a ultima jogada (se alguem ganhar recebe 1)
		}

	} while (verificado == 0 && interrupt == 0);

	

	if (interrupt == 0) {  //so mostra o jogador vencedor se alguem ganhar e n�o se o jogo for interrompido
		remove("jogo.bin");
		apresentar(jogada_atual, stdout); //quando o jogo acaba mostra a ultima jogada na mesma
		printf("\nJOGADOR VENCEDOR: JOGADOR %d\n", jogada_atual.jogador);
		printf("\nGuardar(1) Nao Guardar(2)\n"); //deseja guardar?
		int guardar;
		scanf_s("%d", &guardar, 15);
		if (guardar == 1) {  //se desejar guardar 
			guardarF(lista, modo_de_jogo);  //envia um ponteiro para o inicio da lista ligada para a fun��o guardarF (guardar em ficheiro)
		}

	}
	else {
		printf("\nGuardar(1) Nao Guardar(2)\n"); //deseja guardar?
		int guardar;
		scanf_s("%d", &guardar, 15);
		if (guardar == 1) {  //se desejar guardar 
			guardarFB(lista, modo_de_jogo);  //envia um ponteiro para o inicio da lista ligada para a fun��o guardarF (guardar em ficheiro)
		}

	}


	

	return 0;

}

