#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_COLUNAS 9
#include <time.h>



void initRandom() {
	srand(time(NULL));
}

int intUniformRnd(int a, int b) {
	return a + rand() % (b - a + 1);
}



int xy(int linha, int coluna) {
	return linha * MAX_COLUNAS + coluna;
}

int apresentar(int n_colunas,int n_linhas, char tabela[]){
	for (int i = 0; i <= n_colunas*n_linhas -1 ; i++) {
			printf("|%c", tabela[i]);

			/*
			int colunas_int = (int)i / n_colunas;
			float colunas_dec = i / n_colunas - colunas_int;          =    i % n_colunas  linha 15
			*/

			if ((i+1) % n_colunas == 0) {
				printf("|");
				printf("\n");
				
			}
		
	}
	return 0;
}

int jogada(char* tabela,int jogador_atual, int *n_colunas, int *n_linhas,int *pedraJ1,int *pedraJ2,int *linhasJ1,int *linhasJ2) {
	int linha, coluna;
	char escolha_texto[100];
	int escolha;
	char peca;
Escolha:
	printf("\n:::::: JOGADOR %d :::::\n", jogador_atual);
	printf("\n Escolha a sua jogada: \n (1) Adicionar peca \n (2) Colocar Pedra \n (3) Adicionar linha \n (4) Adicinar Coluna");
	scanf_s("%s", escolha_texto,100);
	escolha = atoi(escolha_texto);
	if (escolha > 4 || escolha < 1) {
		printf("\nERRO: escolha um numero de 1 a 4\n");
		goto Escolha;
	}
	switch (escolha) {
	case 1:
		printf("\n coordenadas (linha:coluna) :\n");
		scanf_s("%d:%d", &linha, &coluna);
		printf("%d %d\n", linha, coluna);
		if (linha > *n_linhas || coluna > *n_colunas) {
			printf("\n ERRO: OFF LIMITS \n");
			goto Escolha;
		}
		peca=tabela[(linha - 1) * (*n_colunas) + (coluna - 1)];
		if (peca == ' ') {
			tabela[(linha - 1) * (*n_colunas) + (coluna - 1)] = 'G';
		}
		if (peca == 'P') {
			printf("\n PECA COM PEDRA \n");
			goto Escolha;
		}
		if (peca == 'G') {
			tabela[(linha - 1) * (*n_colunas) + (coluna - 1)] = 'Y';
		}
		if (peca == 'Y') {
			tabela[(linha - 1) * (*n_colunas) + (coluna - 1)] = 'R';
		}
		if (peca == 'R') {
		
			printf("\n ERRO: SELECIONOU PECA VERMELHA \n");
			goto Escolha;
		}


		break;
	case 2:
		if (jogador_atual == 1 && *pedraJ1 == 0) {
			printf("\nNO ROCK\n");
			goto Escolha;
		}
		if (jogador_atual == 2 && *pedraJ2 == 0) {
			printf("\nNO ROCK\n");
			goto Escolha;
		}
		if (jogador_atual == 1 && *pedraJ1 == 1) {
			*pedraJ1 = 0;
		}
		if (jogador_atual == 2 && *pedraJ2 == 1) {
			*pedraJ2 = 0;
		}
		
		

		printf("\nCoordenada da pedra:\n");
		scanf_s("%d:%d", &linha, &coluna);
		printf("%d %d\n", linha, coluna);
		if (linha > *n_linhas || coluna > *n_colunas) {
			printf("\n ERRO: OFF LIMITS \n");
			goto Escolha;
		}
		peca = tabela[xy(linha-1,coluna-1)];
		if (peca == ' ') {
			tabela[xy(linha - 1, coluna - 1)] = 'P';
		}
		else {
			printf("\n ERRO: CASA COM PECA \n");
			goto Escolha;
		}
		break;
	case 3:
		if (jogador_atual == 1) {
			if (*linhasJ1 < 2) {
				*n_linhas = *n_linhas + 1;
				(*linhasJ1)++;
			}
			else {
				printf("ERRO: todas as linhas usadas");
				goto Escolha;
			}
		}
		if (jogador_atual == 2) {
			if (*linhasJ2 < 2) {
				*n_linhas = *n_linhas + 1;
				(*linhasJ2)++;
			}
			else {
				printf("ERRO: todas as linhas usadas");
				goto Escolha;
			}
		}

		break;
	}
	

	

	return 0;

}



int verifica(char* tabela, int n_colunas, int n_linhas) {
	//LINHAS
	for (int i = 0; i < n_linhas; i++) {
		int q = 0;
		for (int p = 0; p < n_colunas - 1; p++) {
			if (tabela[xy(i,p)] == ' ') {
				break;
			}
			else if (tabela[xy(i, p)] == tabela[xy(i, p+1)]) {
				q++;
				printf("%d\n", q);
				printf("%d\n", n_colunas);
			}
			else {
				break;
			}

			if (q == n_colunas - 1) {
				return 1;
				
			}
		}
	}
	//COLUNAS
	for (int i = 0; i < n_colunas; i++) {
		int q = 0;
		for (int p = 0; p < n_linhas - 1; p++) {
			if (tabela[xy(p, i)] == ' ') {
				break;
			}
			else if (tabela[xy(p, i)] == tabela[xy(p+1, i)]) {
				q++;
			}
			else {
				break;
			}

			if (q == n_linhas - 1) {
				return 1;
			}
		}
	}



	//DIAGONAIS
	if (n_linhas == n_colunas) {
		int q = 0;
		for (int i = 0; i < n_linhas - 1; i++) {
			if (tabela[xy(i, i)] == ' ') {
				break;
			}
			else if (tabela[xy(i, i)] == tabela[xy(i+1, i+1)]) {
				q++;
			}
			else {
				break;
			}
			if (q == n_linhas - 1) {
				return 1;
			}
		}
		int t = 0;
		for (int i = 0; i < n_linhas - 1; i++) {
			if (tabela[xy(i, n_colunas-1-i)] == ' ') {
				break;
			}
			else if (tabela[xy(i, n_colunas - 1 - i)] == tabela[xy(i + 1, n_colunas - 1 - i - 1)]) {
				t++;
			}
			else {
				break;
			}

			if (t == n_colunas - 1) {
				return 1;
			}
		}
	}
	return 0;



}


int main(){

	initRandom();
	int jogador_atual=0;
	int verificado;
	int n_colunas = intUniformRnd(3, 5);
	int n_linhas = n_colunas;
	int tamanho_max = 81;
	char* tabela = (char*) malloc(tamanho_max+1);
	for (int i = 0; i <= tamanho_max; i++) { tabela[i] = ' '; }
	int linhasJ2 = 0;
	int linhasJ1 = 0;


	int pedraJ1 = 1, pedraJ2 = 1;

	do {

		if (jogador_atual == 1) {
			jogador_atual = 2;
		}
		else {
			jogador_atual = 1;
		}

		apresentar(n_colunas, n_linhas, tabela);
		jogada(tabela, jogador_atual,&n_colunas,&n_linhas,&pedraJ1,&pedraJ2,&linhasJ1,&linhasJ2);
		printf("auqiquasi %d %d\n\n", n_linhas, n_colunas);
		verificado=verifica(tabela,n_colunas,n_linhas);


		
	} while (verificado == 0);



	printf("\nJOGADOR VENCEDOR: JOGADOR %d\n", jogador_atual);

	free(tabela);
	return 0;

}

