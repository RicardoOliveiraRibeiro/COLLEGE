﻿namespace PWEB_TP_FINAL.ViewModels
{
    public class UserRolesViewModel
    {
        public string UserId { get; set; }
        public string PrimeiroNome { get; set; }
        public string UltimoNome { get; set; }
        public string UserName { get; set; }
        public IEnumerable<string> Roles { get; set; }
        public IEnumerable<string> AllRoles { get; set; }

        public string CurrentUserId { get; set; }
    }
}
