﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PWEB_TP_FINAL.Models
{
    public class Category
    {
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Display(Name = "Nome")]
        [Required(ErrorMessage = "O nome da categoria é obrigatório.")]
        [StringLength(100, ErrorMessage = "O nome da categoria não pode exceder 100 caracteres.")]
        public string Name { get; set; }

        [Display(Name = "Descrição")]
        [DataType(DataType.MultilineText)]
        [StringLength(500, ErrorMessage = "A descrição não pode exceder 500 caracteres.")]
        public string Description { get; set; }

        [Display(Name = "Ativa?")]
        public bool IsActive { get; set; }

        [Display(Name = "Moradias")]
        public ICollection<Moradia>? Moradias { get; set; }
    }
}