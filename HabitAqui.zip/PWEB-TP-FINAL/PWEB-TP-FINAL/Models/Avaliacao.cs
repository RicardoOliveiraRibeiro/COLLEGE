﻿using PWEB_TP_FINAL.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PWEB_TP_FINAL.Models
{
    public class Avaliacao
    {
        [Key]
        public int AvaliacaoId { get; set; }

        [ForeignKey("Moradia")]
        public int? MoradiaId { get; set; }
        public virtual Moradia? Moradia { get; set; }

        [ForeignKey("ApplicationUser")]
        public string? UserId { get; set; }
        public virtual ApplicationUser? ApplicationUser { get; set; }

        [Range(1, 5)]
        public int? Nota { get; set; }

        [StringLength(500)]
        public string? Comentario { get; set; }
    }
}