﻿namespace PWEB_TP_FINAL.Models
{
    public class RequestArrendamento
    {
        public int Id { get; set; }

        public string? ClienteUserId { get; set; }
        public virtual ApplicationUser? ClienteUser { get; set; }

        public int? MoradiaId { get; set; }
        public virtual Moradia? Moradia { get; set; }

        public bool? Aceite { get; set; } // Indicates whether the request is accepted
    }

}
