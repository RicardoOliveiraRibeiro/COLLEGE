﻿using System.ComponentModel.DataAnnotations;

namespace PWEB_TP_FINAL.Models
{
    public class Moradia
    {
        [Display(Name = "ID")]
        public int ID { get; set; }

        [Display(Name = "Nome")]
        [Required(ErrorMessage = "O nome da moradia é obrigatório.")]
        [StringLength(100, ErrorMessage = "O nome não pode exceder 100 caracteres.")]
        public string Name { get; set; }

        [Display(Name = "Ativa?")]
        public bool IsActive { get; set; }

        [Display(Name = "Descrição")]
        [DataType(DataType.MultilineText)]
        public string Descripcion { get; set; }

        [Display(Name = "Preço")]
        [Required(ErrorMessage = "O preço é obrigatório.")]
        [Range(0, int.MaxValue, ErrorMessage = "Por favor, insira um valor válido para o preço.")]
        [DataType(DataType.Currency)]
        public int Price { get; set; }

        public bool? IsArrendada { get; set; }

        [Display(Name = "Categoria")]
        public int? CategoriaId { get; set; }

        // Assuming you have a 'Category' class defined somewhere that 'Categoria' is referring to
        [Display(Name = "Categoria")]
        public Category? Categoria { get; set; }

        public virtual ICollection<Avaliacao>? Avaliacoes { get; set; }

        [Display(Name = "Criada Por")]
        public string? CreatedByUserId { get; set; }

        // Navigation property to represent the user who created the Moradia
        public ApplicationUser? CreatedByUser { get; set; }

        public virtual ICollection<ApplicationUser>? UsersQueAlugaram { get; set; }
    }
}
