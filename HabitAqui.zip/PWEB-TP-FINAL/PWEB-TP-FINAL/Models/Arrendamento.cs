﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using PWEB_TP_FINAL.Models;
namespace PWEB_TP_FINAL.Models
{
    public class Arrendamento
    {
        public int Id { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Data de Início")]
        public DateTime DataInicio { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Data de Fim")]
        public DateTime DataFim { get; set; }

        [Display(Name = "Duração em Anos")]
        public int DuracaoEmAnos { get; set; }

        [Display(Name = "Duração em Meses")]
        public int DuracaoEmMeses { get; set; }

        [DataType(DataType.Currency)]
        [Display(Name = "Preço")]
        public decimal Preco { get; set; }

        [DataType(DataType.DateTime)]
        [Display(Name = "Data e Hora do Pedido")]
        public DateTime DataHoraDoPedido { get; set; }

        // Foreign key property
        public int? MoradiaId { get; set; }

        // Navigation property for the related Moradia
        public Moradia? Moradia { get; set; }

        [ForeignKey("ApplicationUser")]
        public string? ApplicationUserId { get; set; }

        // Navigation property for ApplicationUser
        public ApplicationUser? ApplicationUser { get; set; }

        public ApplicationUser? Locador { get; set; }

        public string? Status { get; set; } = "Pending"; // Default to "Pending"

        public bool? isLocador { get; set; }


    }
}

