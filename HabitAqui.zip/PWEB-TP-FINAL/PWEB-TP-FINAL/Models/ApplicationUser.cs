﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PWEB_TP_FINAL.Models
{
    public class ApplicationUser : IdentityUser
    {
        [Required]
        [Display(Name = "Primeiro Nome")]
        public string PrimeiroNome { get; set; }

        [Required]
        [Display(Name = "Último Nome")]
        public string UltimoNome { get; set; }

        [Required(ErrorMessage = "Please enter a valid date.")]
        [DataType(DataType.Date)]
        [Display(Name = "Data de Nascimento")]
        public DateTime DataNascimento { get; set; }

        [Required]
        [Display(Name = "NIF")]
        public int NIF { get; set; }

        public virtual ICollection<Arrendamento> Arrendamentos { get; set; }

        public ICollection<Moradia>? CreatedMoradias { get; set; }

        public ICollection<Moradia>? AlugatedMoradia { get; set; }

    }
}