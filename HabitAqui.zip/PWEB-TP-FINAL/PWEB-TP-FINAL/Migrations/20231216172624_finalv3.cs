﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PWEB_TP_FINAL.Migrations
{
    public partial class finalv3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias");

            migrationBuilder.AlterColumn<string>(
                name: "CreatedByUserId",
                table: "Moradias",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias",
                column: "CreatedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias");

            migrationBuilder.AlterColumn<string>(
                name: "CreatedByUserId",
                table: "Moradias",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias",
                column: "CreatedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
