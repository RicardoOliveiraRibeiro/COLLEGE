﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PWEB_TP_FINAL.Migrations
{
    public partial class finalv2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "CreatedByUserId",
                table: "Moradias",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_Moradias_CreatedByUserId",
                table: "Moradias",
                column: "CreatedByUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias",
                column: "CreatedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias");

            migrationBuilder.DropIndex(
                name: "IX_Moradias_CreatedByUserId",
                table: "Moradias");

            migrationBuilder.DropColumn(
                name: "CreatedByUserId",
                table: "Moradias");
        }
    }
}
