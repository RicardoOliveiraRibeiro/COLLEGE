﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PWEB_TP_FINAL.Migrations
{
    public partial class users : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
