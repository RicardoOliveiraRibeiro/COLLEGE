﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PWEB_TP_FINAL.Migrations
{
    public partial class finalv6 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "LocadorId",
                table: "Arrendamento",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamento_LocadorId",
                table: "Arrendamento",
                column: "LocadorId");

            migrationBuilder.AddForeignKey(
                name: "FK_Arrendamento_AspNetUsers_LocadorId",
                table: "Arrendamento",
                column: "LocadorId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Arrendamento_AspNetUsers_LocadorId",
                table: "Arrendamento");

            migrationBuilder.DropIndex(
                name: "IX_Arrendamento_LocadorId",
                table: "Arrendamento");

            migrationBuilder.DropColumn(
                name: "LocadorId",
                table: "Arrendamento");
        }
    }
}
