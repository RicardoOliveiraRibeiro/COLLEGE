﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PWEB_TP_FINAL.Migrations
{
    public partial class finalv5 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Arrendamentos",
                columns: table => new
                {
                    AlugatedMoradiaID = table.Column<int>(type: "int", nullable: false),
                    UsersQueAlugaramId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Arrendamentos", x => new { x.AlugatedMoradiaID, x.UsersQueAlugaramId });
                    table.ForeignKey(
                        name: "FK_Arrendamentos_AspNetUsers_UsersQueAlugaramId",
                        column: x => x.UsersQueAlugaramId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Arrendamentos_Moradias_AlugatedMoradiaID",
                        column: x => x.AlugatedMoradiaID,
                        principalTable: "Moradias",
                        principalColumn: "ID",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Arrendamentos_UsersQueAlugaramId",
                table: "Arrendamentos",
                column: "UsersQueAlugaramId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Arrendamentos");
        }
    }
}
