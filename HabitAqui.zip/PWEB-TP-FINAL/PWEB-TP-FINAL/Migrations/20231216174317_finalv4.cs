﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PWEB_TP_FINAL.Migrations
{
    public partial class finalv4 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias");

            migrationBuilder.AddForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias",
                column: "CreatedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias");

            migrationBuilder.AddForeignKey(
                name: "FK_Moradias_AspNetUsers_CreatedByUserId",
                table: "Moradias",
                column: "CreatedByUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
