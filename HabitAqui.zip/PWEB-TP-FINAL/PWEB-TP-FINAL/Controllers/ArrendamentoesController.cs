﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PWEB_TP_FINAL.Data;
using PWEB_TP_FINAL.Models;

namespace PWEB_TP_FINAL.Controllers
{
    
    public class ArrendamentoesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public ArrendamentoesController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }


        // GET: Arrendamentoes
        [Authorize]
        public async Task<IActionResult> Index()
        {
            // Get the current user
            ApplicationUser currentUser = await _userManager.GetUserAsync(User);

            // Arrendamentos created by the current user
            var userArrendamentos = await _context.Arrendamento
                .Include(a => a.ApplicationUser)
                .Include(b => b.Moradia)
                .Include(c => c.Locador)
                .Where(a => a.ApplicationUserId == currentUser.Id)
                .ToListAsync();

            // Arrendamentos for the moradia that belongs to the current user
            var moradiaArrendamentos = await _context.Arrendamento
                .Include(d => d.ApplicationUser)
                .Include(e => e.Moradia)
                .Include(f => f.Locador)
                .Where(d => d.Moradia.CreatedByUserId == currentUser.Id)
                .ToListAsync();

            // Combine the two sets of arrendamentos into a single list
            var allArrendamentos = userArrendamentos.Concat(moradiaArrendamentos);

            //para cada arrendamento , verificar se o utilizador é o locador ou o cliente e introduzir no campo isLocador
            foreach (var arrendamento in allArrendamentos)
            {
                if (arrendamento.Locador != null && arrendamento.Locador == currentUser)
                {
                    arrendamento.isLocador = true;
                }
                else
                {
                    arrendamento.isLocador = false;
                }
            }



            // Pass a tuple to the view
            return View((allArrendamentos));
        }


        // GET: Arrendamentoes/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            // Include ApplicationUser and Moradia properties
            var arrendamento = await _context.Arrendamento
                .Include(a => a.ApplicationUser)
                .Include(a => a.Moradia)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (arrendamento == null)
            {
                return NotFound();
            }

            return View(arrendamento);
        }



        // GET: Arrendamentoes/Create
        public IActionResult Create(int? moradiaId)
        {
            if (!moradiaId.HasValue || _context.Moradias.Find(moradiaId) == null)
            {
                return NotFound();
            }

            ViewData["UserId"] = new SelectList(_context.ApplicationUser, "Id", "Id");
            ViewData["MoradiaId"] = moradiaId;
            ViewBag.MoradiaId = moradiaId;

            // Additional code to retrieve Moradia information and set it in the ViewBag if needed
            // For example:
            ViewBag.Moradia = _context.Moradias.Find(moradiaId);
            ViewBag.Moradias = new SelectList(_context.Moradias, "ID", "Name");

            return View();
        }


        // POST: Arrendamentoes/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Cliente,DataInicio,DataFim,Preco,DataHoraDoPedido,MoradiaId")] Arrendamento arrendamento)
        {
            // Check if a MoradiaId is provided
            if (!ModelState.IsValid || !MoradiaExists(arrendamento.MoradiaId))
            {
                // If not, add a model error and repopulate the MoradiaList
                ModelState.AddModelError("MoradiaId", "Please select a valid Moradia.");
                var availableMoradias = _context.Moradias.Where(m => m.IsArrendada == false).ToList();
                ViewBag.MoradiaList = new SelectList(availableMoradias, "ID", "Name");
                return View(arrendamento);
            }

            try
            {
                // Get the current user
                ApplicationUser currentUser = await _userManager.GetUserAsync(User);

                // Associate the user with the Arrendamento
                arrendamento.ApplicationUserId = currentUser.Id;

                // Get the selected Moradia
                var selectedMoradia = await _context.Moradias
                    .Include(m => m.CreatedByUser) // Include the CreatedByUser property
                    .FirstOrDefaultAsync(m => m.ID == arrendamento.MoradiaId);

                // Check if the Moradia and its CreatedByUser are not null
                if (selectedMoradia != null && selectedMoradia.CreatedByUser != null)
                {
                    // Set the Locador property based on the CreatedByUser of the Moradia
                    arrendamento.Locador = selectedMoradia.CreatedByUser;
                }
                else
                {
                    // Handle the case where the Locador cannot be determined
                    ModelState.AddModelError(string.Empty, "Unable to determine Locador information.");
                    return View(arrendamento);
                }

                // Update the Moradia properties
                selectedMoradia.IsArrendada = true;

                // Calculate DuracaoEmAnos and DuracaoEmMeses
                arrendamento.DuracaoEmAnos = (int)((arrendamento.DataFim - arrendamento.DataInicio).TotalDays / 365);
                arrendamento.DuracaoEmMeses = (int)((arrendamento.DataFim - arrendamento.DataInicio).TotalDays / 30);

                // Ensure DuracaoEmMeses is at least 1 to avoid division by zero when calculating Preco
                arrendamento.DuracaoEmMeses = Math.Max(arrendamento.DuracaoEmMeses, 1);

                // Set the Price based on the selectedMoradia.Price * duracaoEmMeses
                arrendamento.Preco = selectedMoradia.Price * arrendamento.DuracaoEmMeses;

                // Set DataHoraPedido to the current time
                arrendamento.DataHoraDoPedido = DateTime.Now;

                // Add the Arrendamento to the context
                _context.Add(arrendamento);

                // Save changes to the database
                await _context.SaveChangesAsync();

                // Redirect to the Index action
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                // Handle exceptions (e.g., database errors)
                ModelState.AddModelError(string.Empty, $"An error occurred: {ex.Message}");
                var availableMoradias = _context.Moradias.Where(m => m.IsArrendada == false).ToList();
                ViewBag.MoradiaList = new SelectList(availableMoradias, "ID", "Name");
                return View(arrendamento);
            }
        }

        [HttpPost]
        
        public async Task<IActionResult> AcceptArrendamento(int id)
        {
            var arrendamento = await _context.Arrendamento.FindAsync(id);

            if (arrendamento == null || arrendamento.Status == "Accepted")
            {
                return NotFound();
            }

            // Check if the logged-in user is the owner of the Moradia
            var currentUser = await _userManager.GetUserAsync(User);
            var moradiaCreatedByUser = await _context.Moradias
                .Where(m => m.ID == arrendamento.MoradiaId && m.CreatedByUserId == currentUser.Id)
                .FirstOrDefaultAsync();

            if (moradiaCreatedByUser == null)
            {
                // User is not the owner of the Moradia
                return Forbid();
            }

            // Update the status to "Accepted"
            arrendamento.Status = "Accepted";
            _context.Update(arrendamento);
            await _context.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }



        // GET: Arrendamentoes/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Arrendamento == null)
            {
                return NotFound();
            }

            var arrendamento = await _context.Arrendamento.FindAsync(id);
            if (arrendamento == null)
            {
                return NotFound();
            }
            return View(arrendamento);
        }

        // POST: Arrendamentoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Cliente,DataInicio,DataFim")] Arrendamento arrendamento)
        {
            if (id != arrendamento.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    // Retrieve the original arrendamento from the database
                    var originalArrendamento = await _context.Arrendamento.FindAsync(arrendamento.Id);

                    // Update the editable properties
                    //originalArrendamento.Cliente = arrendamento.Cliente;
                    originalArrendamento.DataInicio = arrendamento.DataInicio;
                    originalArrendamento.DataFim = arrendamento.DataFim;

                    // Recalculate the dependent properties
                    originalArrendamento.DuracaoEmAnos = (originalArrendamento.DataFim - originalArrendamento.DataInicio).Days / 365;
                    originalArrendamento.DuracaoEmMeses = (originalArrendamento.DataFim - originalArrendamento.DataInicio).Days / 30;

                    // Get the selected Moradia
                    var selectedMoradia = await _context.Moradias.FindAsync(originalArrendamento.MoradiaId);

                    // Set the Price based on the designatedMoradia.Price * duracaoEmMeses
                    originalArrendamento.Preco = selectedMoradia.Price * originalArrendamento.DuracaoEmMeses;

                    
                    // Update the database
                    _context.Update(originalArrendamento);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ArrendamentoExists(arrendamento.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(arrendamento);
        }


        // GET: Arrendamentoes/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Arrendamento == null)
            {
                return NotFound();
            }

            var arrendamento = await _context.Arrendamento
                .Include(a => a.Moradia) // Include Moradia in the query
                .FirstOrDefaultAsync(m => m.Id == id);

            if (arrendamento == null)
            {
                return NotFound();
            }

            return View(arrendamento);
        }

        // POST: Arrendamentoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Arrendamento == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Arrendamento' is null.");
            }

            var arrendamento = await _context.Arrendamento
                .Include(a => a.Moradia) // Include Moradia in the query
                .FirstOrDefaultAsync(m => m.Id == id);

            if (arrendamento != null)
            {
                // Set IsArrendada to false when Arrendamento is deleted
                if (arrendamento.Moradia != null)
                {
                    arrendamento.Moradia.IsArrendada = false;
                }

                _context.Arrendamento.Remove(arrendamento);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool MoradiaExists(int? id)
        {
            return id.HasValue && _context.Moradias.Any(e => e.ID == id.Value && e.IsArrendada == false);
        }


        private bool ArrendamentoExists(int id)
        {
          return (_context.Arrendamento?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
