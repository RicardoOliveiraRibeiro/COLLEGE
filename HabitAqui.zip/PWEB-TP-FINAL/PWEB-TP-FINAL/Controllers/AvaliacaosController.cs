﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PWEB_TP_FINAL.Data;
using PWEB_TP_FINAL.Models;

namespace PWEB_TP_FINAL.Controllers
{
    public class AvaliacoesController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public AvaliacoesController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: Avaliacaos
        public async Task<IActionResult> Index()
        {
            var avaliacoes = await _context.Avaliacao
                .Include(a => a.ApplicationUser)
                .Include(a => a.Moradia)
                .ToListAsync();

            return View(avaliacoes);
        }


        // GET: Avaliacaos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Avaliacao == null)
            {
                return NotFound();
            }

            var avaliacao = await _context.Avaliacao
                .Include(a => a.ApplicationUser)
                .Include(b => b.Moradia) // Explicitly include the Moradia property
                .FirstOrDefaultAsync(m => m.AvaliacaoId == id);

            if (avaliacao == null)
            {
                return NotFound();
            }

            return View(avaliacao);
        }


        public IActionResult Create(int? moradiaId)
        {
            if (!moradiaId.HasValue || _context.Moradias.Find(moradiaId) == null)
            {
                return NotFound();
            }

            ViewData["UserId"] = new SelectList(_context.ApplicationUser, "Id", "Id");
            ViewData["MoradiaId"] = moradiaId;
            ViewBag.MoradiaId = moradiaId;

            // Additional code to retrieve Moradia information and set it in the ViewBag if needed
            // For example:
            ViewBag.Moradia = _context.Moradias.Find(moradiaId);
            ViewBag.Moradias = new SelectList(_context.Moradias, "ID", "Name");

            return View();
        }




        /*[HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AvaliacaoId,MoradiaId,UserId,Nota,Comentario")] Avaliacao avaliacao)
        {
            if (ModelState.IsValid)
            {
                // Get the current user
                var currentUser = await _userManager.GetUserAsync(User);
                avaliacao.UserId = currentUser.Id; // Assign the user ID to the Avaliacao object

                // Set the MoradiaId from the ViewBag
                avaliacao.MoradiaId = ViewBag.MoradiaId;

                _context.Add(avaliacao);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["UserId"] = new SelectList(_context.ApplicationUser, "Id", "Id", avaliacao.UserId);
            ViewData["MoradiaId"] = ViewBag.MoradiaId;
            ViewBag.Moradias = new SelectList(_context.Moradias, "ID", "Name", avaliacao.MoradiaId);

            return View(avaliacao);
        }*/

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AvaliacaoId,MoradiaId,UserId,Nota,Comentario")] Avaliacao avaliacao)
        {
            if (ModelState.IsValid)
            {
                // Obter o usuário atual
                var currentUser = await _userManager.GetUserAsync(User);
                avaliacao.UserId = currentUser.Id; // Atribuir o ID do usuário ao objeto Avaliacao

                _context.Add(avaliacao);
                await _context.SaveChangesAsync();

                // Redirecionar para a página de detalhes da moradia ou para a lista de avaliações
                return RedirectToAction("Details", "Moradias", new { id = avaliacao.MoradiaId });
            }

            // Se houver um problema, recarregar a página de criação de avaliação com os dados submetidos
            return View(avaliacao);
        }

        // GET: Avaliacaos/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Avaliacao == null)
            {
                return NotFound();
            }

            var avaliacao = await _context.Avaliacao.FindAsync(id);
            if (avaliacao == null)
            {
                return NotFound();
            }
            ViewData["UserId"] = new SelectList(_context.ApplicationUser, "Id", "Id", avaliacao.UserId);
            ViewData["MoradiaId"] = new SelectList(_context.Moradias, "ID", "Name", avaliacao.MoradiaId);
            return View(avaliacao);
        }

        // POST: Avaliacaos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AvaliacaoId,MoradiaId,UserId,Nota,Comentario")] Avaliacao avaliacao)
        {
            if (id != avaliacao.AvaliacaoId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(avaliacao);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AvaliacaoExists(avaliacao.AvaliacaoId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["UserId"] = new SelectList(_context.ApplicationUser, "Id", "Id", avaliacao.UserId);
            ViewData["MoradiaId"] = new SelectList(_context.Moradias, "ID", "Name", avaliacao.MoradiaId);
            return View(avaliacao);
        }

        // GET: Avaliacaos/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Avaliacao == null)
            {
                return NotFound();
            }

            var avaliacao = await _context.Avaliacao
                .Include(a => a.ApplicationUser)
                .Include(a => a.Moradia)
                .FirstOrDefaultAsync(m => m.AvaliacaoId == id);
            if (avaliacao == null)
            {
                return NotFound();
            }

            return View(avaliacao);
        }

        // GET: Avaliacaos/ViewAvaliacao/5
        public async Task<IActionResult> ViewAvaliacao(int moradiaId)
        {
            var avaliacoes = await _context.Avaliacao
                .Include(a => a.ApplicationUser)
                .Include(a => a.Moradia) // Include the Moradia property
                .Where(a => a.MoradiaId == moradiaId)
                .ToListAsync();

            return View(avaliacoes);
        }



        // POST: Avaliacaos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Avaliacao == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Avaliacao'  is null.");
            }
            var avaliacao = await _context.Avaliacao.FindAsync(id);
            if (avaliacao != null)
            {
                _context.Avaliacao.Remove(avaliacao);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AvaliacaoExists(int id)
        {
          return (_context.Avaliacao?.Any(e => e.AvaliacaoId == id)).GetValueOrDefault();
        }
    }

}
