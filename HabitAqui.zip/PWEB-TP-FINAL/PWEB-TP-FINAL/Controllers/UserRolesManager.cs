﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PWEB_TP_FINAL.Data;
using PWEB_TP_FINAL.Models;
using PWEB_TP_FINAL.ViewModels;

namespace PWEB_TP_FINAL.Controllers
{
    public class UserRolesManagerController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;

        public UserRolesManagerController(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _userManager = userManager;
            _roleManager = roleManager;
        }

        public async Task<IActionResult> Index()
        {
            var users = await _userManager.Users.ToListAsync();
            var userRolesViewModel = new List<UserRolesViewModel>();

            foreach (var user in users)
            {
                var thisUserRoles = await GetUserRoles(user);
                var userRoleViewModel = new UserRolesViewModel
                {
                    UserId = user.Id,
                    PrimeiroNome = user.PrimeiroNome,
                    UltimoNome = user.UltimoNome,
                    UserName = user.UserName,
                    Roles = thisUserRoles
                };
                userRolesViewModel.Add(userRoleViewModel);
            }

            return View(userRolesViewModel);
        }

        private async Task<List<string>> GetUserRoles(ApplicationUser user)
        {
            return new List<string>(await _userManager.GetRolesAsync(user));
        }



        public async Task<IActionResult> Details(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return NotFound();
            }

            var userRoles = await GetUserRoles(user);
            var allRoles = await _roleManager.Roles.Select(r => r.Name).ToListAsync();
            var currentUserId = _userManager.GetUserId(User); // Get the ID of the currently logged-in user

            var model = new UserRolesViewModel
            {
                UserId = user.Id,
                UserName = user.UserName,
                Roles = userRoles,
                AllRoles = allRoles,
                CurrentUserId = currentUserId // Set the CurrentUserId property
            };

            return View(model);
        }



        [HttpPost]
        public async Task<IActionResult> UpdateUserRoles(string userId, List<string> selectedRoles)
        {
            var userBeingEdited = await _userManager.FindByIdAsync(userId);
            if (userBeingEdited == null)
            {
                return NotFound();
            }

            var currentUser = await _userManager.GetUserAsync(User);
            var currentUserRoles = await _userManager.GetRolesAsync(currentUser);

            // Check if the user being edited is the current user or if the user being edited has an 'Admin' role.
            if (currentUser.Id == userId || (await _userManager.GetRolesAsync(userBeingEdited)).Contains(Roles.Admin.ToString()))
            {
                TempData["ErrorMessage"] = currentUser.Id == userId ?
                    "You cannot modify your own roles." :
                    "Gestores cannot modify admin roles.";
                return RedirectToAction("Index");
            }

            // Proceed with the role update if the above conditions are not met
            var rolesToRemove = (await _userManager.GetRolesAsync(userBeingEdited)).Except(selectedRoles).ToList();
            var rolesToAdd = selectedRoles.Except(await _userManager.GetRolesAsync(userBeingEdited)).ToList();

            var removeRolesResult = await _userManager.RemoveFromRolesAsync(userBeingEdited, rolesToRemove);
            if (!removeRolesResult.Succeeded)
            {
                // Handle the case where the roles couldn't be removed
                // Add error handling and logging as needed
            }

            var addRolesResult = await _userManager.AddToRolesAsync(userBeingEdited, rolesToAdd);
            if (!addRolesResult.Succeeded)
            {
                // Handle the case where the roles couldn't be added
                // Add error handling and logging as needed
            }

            return RedirectToAction("Index");
        }


        [HttpPost]
        public async Task<IActionResult> DeleteUser(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
            {
                return NotFound();
            }

            var currentUser = await _userManager.GetUserAsync(User);
            if (user.Id == currentUser.Id)
            {
                TempData["ErrorMessage"] = "You cannot delete your own account.";
                return RedirectToAction(nameof(Index));
            }

            // Prevent deletion if the user is an admin
            var userRoles = await _userManager.GetRolesAsync(user);
            if (userRoles.Contains(Roles.Admin.ToString()))
            {
                TempData["ErrorMessage"] = "Cannot delete admin users.";
                return RedirectToAction(nameof(Index));
            }

            var result = await _userManager.DeleteAsync(user);
            if (result.Succeeded)
            {
                TempData["SuccessMessage"] = "User successfully deleted.";
                return RedirectToAction(nameof(Index));
            }
            else
            {
                TempData["ErrorMessage"] = "Error occurred while deleting the user.";
                return View("Index", await GetUsersViewModel());
            }
        }


        private async Task<IEnumerable<UserRolesViewModel>> GetUsersViewModel()
        {
            var users = await _userManager.Users.ToListAsync();
            var userRolesViewModel = new List<UserRolesViewModel>();

            foreach (var user in users)
            {
                var thisUserRoles = await GetUserRoles(user);
                var userRoleViewModel = new UserRolesViewModel
                {
                    UserId = user.Id,
                    UserName = user.UserName,
                    Roles = thisUserRoles
                };
                userRolesViewModel.Add(userRoleViewModel);
            }

            return userRolesViewModel;
        }


    }
}
