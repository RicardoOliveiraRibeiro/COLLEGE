﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PWEB_TP_FINAL.Data;
using PWEB_TP_FINAL.Models;

namespace PWEB_TP_FINAL.Controllers
{
    public class MoradiasController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;

        public MoradiasController(ApplicationDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }



        // GET: Moradias
        [HttpGet]
        public async Task<IActionResult> Index(string filter, string sortOrder)
        {
            IQueryable<Moradia> moradias = _context.Moradias.Include(m => m.Categoria); // Include category information

            // Get the current user
            ApplicationUser currentUser = await _userManager.GetUserAsync(User);
            // Filter moradias based on the current user's ID
            var userCreatedMoradia = await _context.Moradias
                .Include(a => a.CreatedByUser) // Include ApplicationUser
                .ToListAsync();

            // Apply sorting based on sortOrder
            if (!string.IsNullOrEmpty(sortOrder))
            {
                switch (sortOrder)
                {
                    case "asc":
                        moradias = moradias.OrderBy(m => m.Price);
                        break;
                    case "desc":
                        moradias = moradias.OrderByDescending(m => m.Price);
                        break;
                        // Add more cases if needed
                }
            }

            // Apply filter based on IsActive
            if (filter == "active")
            {
                moradias = moradias.Where(m => m.IsActive);
            }
            else if (filter == "inactive")
            {
                moradias = moradias.Where(m => !m.IsActive);
            }

            return View(moradias.ToList());
        }

        [HttpPost]
        public async Task<IActionResult> Index(string filter, string searchQuery, string sortOrder)
        {
            // Handle the form submission for searching
            if (!string.IsNullOrEmpty(searchQuery))
            {
                // Use LINQ query syntax to perform the search
                var searchResults = from moradia in _context.Moradias
                                    where moradia.Name.Contains(searchQuery) || moradia.Descripcion.Contains(searchQuery)
                                    select moradia;

                // Apply sorting based on sortOrder
                if (!string.IsNullOrEmpty(sortOrder))
                {
                    switch (sortOrder)
                    {
                        case "asc":
                            searchResults = searchResults.OrderBy(m => m.Price);
                            break;
                        case "desc":
                            searchResults = searchResults.OrderByDescending(m => m.Price);
                            break;
                            // Add more cases if needed
                    }
                }

                return View(searchResults.ToList());
            }

            // If searchQuery is empty, redirect to the main Index page with the filter and sortOrder
            return RedirectToAction(nameof(Index), new { filter, sortOrder });
        }




        // GET: Moradias/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Moradias == null)
            {
                return NotFound();
            }

            var moradia = await _context.Moradias
                .Include(a => a.Categoria) // Explicitly include the Moradia property
                .FirstOrDefaultAsync(m => m.ID == id);
            if (moradia == null)
            {
                return NotFound();
            }

            return View(moradia);
        }


        // GET: Moradias/Create
        [Authorize(Roles = "Admin, Funcionario")]
        public IActionResult Create()
        {
            ViewBag.Categories = new SelectList(_context.Categorias, "ID", "Name");
            return View();
        }

        // POST: Moradias/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,IsActive,Descripcion,Price,CategoriaId,CreatedByUserId")] Moradia moradia)
        {
            if (ModelState.IsValid)
            {
                // Set IsArrendada to false when creating a new Moradia
                moradia.IsArrendada = false;

                // Get the current user
                ApplicationUser currentUser = await _userManager.GetUserAsync(User);

                // Set the CreatedByUserId property to the ID of the current user
                moradia.CreatedByUserId = currentUser.Id;
                _context.Add(moradia);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(moradia);
        }


        // GET: Moradias/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Moradias == null)
            {
                return NotFound();
            }

            var moradia = await _context.Moradias.FindAsync(id);
            if (moradia == null)
            {
                return NotFound();
            }

            ViewBag.Categories = new SelectList(_context.Categorias, "ID", "Name", moradia.CategoriaId);
            return View(moradia);
        }

        // POST: Moradias/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin, Funcionario")]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,IsActive,Descripcion,Price,CategoriaId")] Moradia moradia)
        {
            if (id != moradia.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(moradia);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MoradiaExists(moradia.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(moradia);
        }

        // GET: Moradias/Delete/5
        [Authorize(Roles = "Admin, Funcionario")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Moradias == null)
            {
                return NotFound();
            }

            var moradia = await _context.Moradias
                .FirstOrDefaultAsync(m => m.ID == id);
            if (moradia == null)
            {
                return NotFound();
            }

            return View(moradia);
        }

        // POST: Moradias/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Moradias == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Moradias'  is null.");
            }
            var moradia = await _context.Moradias.FindAsync(id);
            if (moradia != null)
            {
                _context.Moradias.Remove(moradia);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MoradiaExists(int id)
        {
          return (_context.Moradias?.Any(e => e.ID == id)).GetValueOrDefault();
        }

        // GET: Moradias/Search
        public async Task<IActionResult> Search(string searchQuery)
        {
            ViewBag.SearchQuery = searchQuery; // Store the search query in the ViewBag to highlight the text in the view

            IQueryable<Moradia> searchResults;

            if (string.IsNullOrEmpty(searchQuery))
            {
                // If searchQuery is empty, redirect to the index page
                return RedirectToAction(nameof(Index));
            }
            else
            {
                // Search in both the Name and Description fields
                searchResults = _context.Moradias
                    .Include(m => m.Categoria)
                    .Where(m => EF.Functions.Like(m.Name, $"%{searchQuery}%") || EF.Functions.Like(m.Descripcion, $"%{searchQuery}%"));
            }

            var resultsList = await searchResults.ToListAsync();

            if (!resultsList.Any())
            {
                // No results found, set the message
                ViewBag.NoResultsMessage = "Não foi possível encontrar moradias com os dados introduzidos. Por favor, reveja a sua pesquisa.";
            }

            return View("Search", resultsList); // Return the Search view with the results
        }
       


    }
}
