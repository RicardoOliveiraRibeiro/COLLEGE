﻿using Microsoft.AspNetCore.Identity;
using PWEB_TP_FINAL.Models;
using System;
namespace PWEB_TP_FINAL.Data
{
    public enum Roles
    {
        Admin,
        Gestor,
        Funcionario,
        Cliente
    }
    public static class Inicializacao
    {
        public static async Task CriaDadosIniciais(UserManager<ApplicationUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            // Check if the 'Cliente' role exists
            var clienteRoleExists = await roleManager.RoleExistsAsync(Roles.Cliente.ToString());
            if (!clienteRoleExists)
            {
                // Create the 'Cliente' role
                await roleManager.CreateAsync(new IdentityRole(Roles.Cliente.ToString()));
            }
            //Adicionar default Roles
            await roleManager.CreateAsync(new IdentityRole(Roles.Admin.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Roles.Gestor.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Roles.Funcionario.ToString()));
            await roleManager.CreateAsync(new IdentityRole(Roles.Cliente.ToString()));
            //Adicionar Default User - Admin
            var defaultUser = new ApplicationUser
            {
                UserName = "admin@localhost.com",
                Email = "admin@localhost.com",
                PrimeiroNome = "Administrador",
                UltimoNome = "Local",
                EmailConfirmed = true,
                PhoneNumberConfirmed = true
            };
            var user = await userManager.FindByEmailAsync(defaultUser.Email);
            if (user == null)
            {
                await userManager.CreateAsync(defaultUser, "Is3C..00");
                await userManager.AddToRoleAsync(defaultUser,
                Roles.Admin.ToString());
            }
        }
    }
}
