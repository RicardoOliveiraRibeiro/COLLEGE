﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PWEB_TP_FINAL.Models;

namespace PWEB_TP_FINAL.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Moradia> Moradias { get; set; }
        public DbSet<Category> Categorias { get; set; } // Add DbSet for Categoria

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configure the 1-N relationship between Moradia and Categoria
            modelBuilder.Entity<Moradia>()
                .HasOne(m => m.Categoria)
                .WithMany(c => c.Moradias)
                .HasForeignKey(m => m.CategoriaId)
                .OnDelete(DeleteBehavior.Cascade);

            // Configure the N-1 relationship between Moradia and ApplicationUser (CreatedByUser)
            modelBuilder.Entity<Moradia>()
                .HasOne(m => m.CreatedByUser)
                .WithMany(u => u.CreatedMoradias)
                .HasForeignKey(m => m.CreatedByUserId)
                .IsRequired(false)  // Set to false to allow null values in CreatedByUserId
                .OnDelete(DeleteBehavior.Restrict); // or DeleteBehavior.Cascade based on your requirements

            modelBuilder.Entity<ApplicationUser>()
                .HasMany(u => u.AlugatedMoradia)
                .WithMany(m => m.UsersQueAlugaram)
                .UsingEntity(j => j.ToTable("Arrendamentos"));


            // Configuração do relacionamento entre Moradia e Avaliacao
            modelBuilder.Entity<Moradia>()
                .HasMany(m => m.Avaliacoes)
                .WithOne(a => a.Moradia)
                .HasForeignKey(a => a.MoradiaId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<ApplicationUser>()
                .HasMany(e => e.Arrendamentos)
                .WithOne(e => e.ApplicationUser)
                .HasForeignKey(e => e.ApplicationUserId)
                .IsRequired(); // Only if the foreign key is required
        }



        public DbSet<PWEB_TP_FINAL.Models.Arrendamento>? Arrendamento { get; set; }
        public DbSet<PWEB_TP_FINAL.Models.ApplicationUser>? ApplicationUser { get; set; }
        public DbSet<PWEB_TP_FINAL.Models.Avaliacao>? Avaliacao { get; set; }

    }
}